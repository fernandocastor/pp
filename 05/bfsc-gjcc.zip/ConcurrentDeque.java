import java.util.Deque;
import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ConcurrentDeque<E> {

	private Deque<E> leftDeque = new LinkedList<E>();
	private Lock leftLock = new ReentrantLock();
	
	private Deque<E> rightDeque = new LinkedList<E>();
	private Lock rightLock = new ReentrantLock();
	
	public void pushLeft(E element) {
		leftLock.lock();
		
		trace(Operation.STARTED, null, null);
		
		leftDeque.addFirst(element);
		
		trace(Operation.PUSH, Side.LEFT, element);
		
		leftLock.unlock();
	}
	
	public void pushRight(E element) {
		rightLock.lock();
		
		trace(Operation.STARTED, null, null);
		
		rightDeque.addFirst(element);
		
		trace(Operation.PUSH, Side.RIGHT, element);
		
		rightLock.unlock();
	}

	public E popLeft() {
		E toReturn = null;
		
		leftLock.lock();
		
		if (leftDeque.isEmpty()) {
			rightLock.lock();
			
			trace(Operation.STARTED, null, null);
			
			toReturn = rightDeque.isEmpty() ? null : rightDeque.removeLast();

			trace(Operation.POP, Side.LEFT, toReturn);
			
			rightLock.unlock();
		} else {
			trace(Operation.STARTED, null, null);
			
			toReturn = leftDeque.removeFirst();
			
			trace(Operation.POP, Side.LEFT, toReturn);
		}
		
		leftLock.unlock();
		
		return toReturn;
	}
	
	public E popRight() {
		E toReturn = null;
		
		rightLock.lock();
		
		if (rightDeque.isEmpty()) {
			rightLock.unlock();
			leftLock.lock();
			rightLock.lock();
			
			trace(Operation.STARTED, null, null);
			
			toReturn = leftDeque.isEmpty() ? null : leftDeque.removeLast();
			
			trace(Operation.POP, Side.RIGHT, toReturn);
			
			rightLock.unlock();
			leftLock.unlock();
		} else {
			trace(Operation.STARTED, null, null);
			
			toReturn = rightDeque.removeFirst();
			
			trace(Operation.POP, Side.RIGHT, toReturn);
			
			rightLock.unlock();
		}

		return toReturn;
	}
	
	public enum Operation {STARTED, PUSH, POP};
	public enum Side {LEFT, RIGHT};
	
	public void trace(Operation operation, Side side, E value) {
		if (TRACE) {
			switch (operation) {
			case POP:
				
				switch (side) {
				case LEFT:
					System.out.println("thread " + Thread.currentThread().getId() + " pop left " + value);
					break;
				case RIGHT:
					System.out.println("thread " + Thread.currentThread().getId() + " pop right " + value);
					break;
				}
				
				break;
			case PUSH:
				
				switch (side) {
				case LEFT:
					System.out.println("thread " + Thread.currentThread().getId() + " push left " + value);
					break;
				case RIGHT:
					System.out.println("thread " + Thread.currentThread().getId() + " push right " + value);
					break;
				}
				
				break;
			case STARTED:
				System.out.println("thread " + Thread.currentThread().getId() + " started");
			}
		}
	}
	
	private static final int THREADS_QTY = 80;
	private static final boolean TRACE = true;
	
	private static ConcurrentDeque<Integer> deque = new ConcurrentDeque<Integer>();
	
	public static void main(String[] args) {
		ExecutorService threadPool = Executors.newFixedThreadPool(8);
		
		for (int i = 1; i <= THREADS_QTY; i++) {
			threadPool.execute(new DequeUserThread());
		}
		
		threadPool.shutdown();
	}
	
	private static class DequeUserThread implements Runnable {

		public void run() {
			Random random = new Random();
			
			boolean push = random.nextBoolean();
			boolean left = random.nextBoolean();
			
			if (push) {
				int value = random.nextInt(THREADS_QTY);
				
				if (left) {
					deque.pushLeft(value);
				} else {
					deque.pushRight(value);
				}
			} else {
				if (left) {
					deque.popLeft();
				} else {
					deque.popRight();
				}
			}
		}
		
	}
	
}
