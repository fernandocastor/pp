import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class HashParalellDeque {

	final static int PQEQ_N_BKTS 	= 4;
	final static int QTD_ELEMENTS 	= 6;
	final static int NUM_THREADS 	= 2;
	final static int NUM_OPERATIONS	= 2; //2 = only pushs, 4 = pushs and pops

	static AtomicInteger end = new AtomicInteger(0); //indicates that all threads finished their operations

	pdeq hpdeq;

	public HashParalellDeque(){
		this.hpdeq = new pdeq();
	}

	public void execute(){
		for (int i = 0; i < NUM_THREADS; i++) {
			new Thread(new Updater(i)).start();
		}
	}

	public static void main(String[] args) {
		HashParalellDeque h = new HashParalellDeque();
		h.execute();
		while(end.get() != NUM_THREADS){}
		h.printFinalStatus();
	}


	public void printFinalStatus(){
		System.out.println();
		String strs = "";
		for(int i = 0; i < PQEQ_N_BKTS; i++){
			strs = strs.concat("DEQ"+i+": ");
			deq d = this.hpdeq.bkt[i];
			Iterator<String> it = d.deque.iterator();
			while(it.hasNext()){
				strs = strs.concat(it.next()+" ");
			}
			strs = strs.concat("\n");
		}
		System.out.println(strs);
		System.out.println("Index L: " + this.hpdeq.lidx );
		System.out.println("Index R: " + this.hpdeq.ridx );

	}






	/**
	 * Thread that add/remove elements to the pdeq, arbitrarily
	 * choosing a operation on one of its end.
	 * @author gjcc, brfc
	 *
	 */
	class Updater implements Runnable {

		Random g = new Random();
		int id;

		public Updater(int id) {
			this.g = new Random();
			this.id = id;
		}

		@Override
		public void run() {
			int i = 0;
			while(i < (QTD_ELEMENTS/NUM_THREADS)){
				int op = g.nextInt(NUM_OPERATIONS);
				//arbitrarily choosing a operation on one of its end.
				switch (op) {
				case 0:
					hpdeq.pdeq_push_l("L", this.id);
					break;
				case 1:
					hpdeq.pdeq_push_r("R", this.id);
					break;
				case 2:
					hpdeq.pdeq_pop_l(this.id);
					break;
				case 3:
					hpdeq.pdeq_pop_r(this.id);
					break;
				}
				i++;
			}
			end.incrementAndGet();
		}
	}


	/**
	 * Hashed Paralell Deque
	 * @author gjcc, brfc
	 *
	 */
	class pdeq {
		Lock llock;
		int lidx;
		Lock rlock;
		int ridx;
		deq bkt[];

		//for tracking purposes
		int posl = 0;
		int posr = 1;

		public pdeq() {
			llock = new ReentrantLock();
			lidx = 0;
			rlock = new ReentrantLock();
			ridx = 1;
			bkt = new deq[PQEQ_N_BKTS];
			for(int i = 0; i < PQEQ_N_BKTS; i++){
				bkt[i] = new deq();
			}
		}

		int moveleft(int idx){
			return (idx - 1) & (PQEQ_N_BKTS - 1);
		}


		int moveright(int idx){
			return (idx + 1) & (PQEQ_N_BKTS - 1);
		}



		void pdeq_push_l(String e, int tid)	{
			int i;
			this.llock.lock();
			i = this.lidx;
			e = e+this.posl;
			this.bkt[i].deq_push_l(e);

			System.out.println("Thread " + tid + " left pushed " + e);

			this.posl--;
			this.lidx = moveleft(this.lidx);
			this.llock.unlock();
		}


		String pdeq_pop_l(int tid){
			String e;
			int i;

			this.llock.lock();
			i = moveright(this.lidx);
			e = this.bkt[i].deq_pop_l();
			if (e != null)
				this.lidx = i;

			System.out.println("Thread " + tid + " left popped " + e);

			this.llock.unlock();
			return e;
		}

		void pdeq_push_r(String e, int tid)	{
			int i;
			this.rlock.lock();
			i = this.ridx;
			e = e+this.posr;
			this.bkt[i].deq_push_r(e);

			System.out.println("Thread " + tid + " right pushed " + e);

			this.posr++;
			this.ridx = moveright(this.ridx);
			this.rlock.unlock();
		}

		String pdeq_pop_r(int tid){
			String e;
			int i;

			this.rlock.lock();
			i = moveleft(this.ridx);
			e = this.bkt[i].deq_pop_r();
			if (e != null)
				this.ridx = i;
			
			System.out.println("Thread " + tid + " right popped " + e);
			
			this.rlock.unlock();
			return e;
		}
	}

	/**
	 * Simple Locked Deque
	 * @author gjcc, brfc
	 *
	 */

	class deq {
		Deque<String> deque;
		Lock lock;

		public deq() {
			lock = new ReentrantLock();
			deque = new LinkedList<String>();
		}

		void deq_push_l(String e){
			this.lock.lock();
			this.deque.addFirst(e);
			this.lock.unlock();
		}

		String deq_pop_l(){
			String e;
			this.lock.lock();
			if(this.deque.isEmpty())
				e = null;
			else 
				e = this.deque.removeFirst();

			this.lock.unlock();
			return e;
		}	

		void deq_push_r(String e){
			this.lock.lock();
			this.deque.addLast(e);
			this.lock.unlock();
		}

		String deq_pop_r(){
			String e;
			this.lock.lock();
			if(this.deque.isEmpty())
				e = null;
			else 
				e = this.deque.removeLast();

			this.lock.unlock();
			return e;
		}
	}
}
