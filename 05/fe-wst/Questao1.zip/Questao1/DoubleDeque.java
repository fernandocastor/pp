package trabalho05.deque.two;

import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DoubleDeque<E> {

	private LinkedList<E> dequeRight = new LinkedList<E>();
	private LinkedList<E> dequeLeft = new LinkedList<E>();
	private Lock lockLeft = new ReentrantLock();
	private Lock lockRight = new ReentrantLock();

	public void push_right(E o) {
		this.lockRight.lock();
		this.dequeRight.addLast(o);
		this.lockRight.unlock();
	}

	public void push_left(E o) {
		this.lockLeft.lock();
		this.dequeLeft.addFirst(o);
		this.lockLeft.unlock();
	}

	public E pop_right() {

		E element = null;
		this.lockRight.lock();

		if (this.dequeRight.isEmpty())
		{
			this.lockRight.unlock();
			this.lockLeft.lock();
			this.lockRight.lock();

			if (!this.dequeLeft.isEmpty())
			{
				element = this.dequeLeft.pollLast();
			}
			else
			{
				// dois deques vazios
			}

			this.lockRight.unlock();
			this.lockLeft.unlock();
		}
		else
		{
			element = this.dequeRight.pollLast();
			this.lockRight.unlock();
		}

		return element;
	}

	public E pop_left() {

		E element = null;
		this.lockLeft.lock();

		if (this.dequeLeft.isEmpty())
		{
			this.lockRight.lock();
			if (!this.dequeRight.isEmpty())
			{
				element = this.dequeRight.pollFirst();
			}
			this.lockRight.unlock();
		}
		else
		{
			element = this.dequeLeft.pollFirst();
		}

		this.lockLeft.unlock();
		return element;
	}

	@Override
	public String toString() {
		return "deque=[" + dequeLeft + dequeRight + "]";
	}
	
}
