package trabalho05.deque.two;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class DequeThread<E> extends Thread {

	private DoubleDeque<E> deque = null;
	private int seq = 0;

	public DequeThread(int s, DoubleDeque<E> d) {
		this.seq = s;
		this.deque = d;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void run() {

		// sequencia 1
		if (this.seq == 1)
		{
			this.deque.push_left((E) "a");
			this.deque.push_left((E) "b");
			this.deque.push_left((E) "c");
			this.deque.push_right((E) "d");
			this.deque.push_right((E) "e");
			this.deque.pop_left();
			this.deque.pop_right();
			this.deque.pop_right();
			this.deque.pop_left();
			this.deque.pop_right();
			this.deque.pop_right();
			this.deque.pop_left();
			this.deque.push_left((E) "aa");
			this.deque.push_left((E) "bb");
		}
		// sequencia 2
		else if (this.seq == 2)
		{
			this.deque.push_left((E) "x");
			this.deque.push_left((E) "y");
			this.deque.push_right((E) "z");
			this.deque.push_right((E) "w");
			this.deque.pop_left();
			this.deque.pop_right();
			this.deque.pop_left();
			this.deque.pop_right();
			this.deque.push_right((E) "ww");
			this.deque.push_left((E) "yy");
		}
		// sequencia 3
		else if (this.seq == 3)
		{
			this.deque.push_left((E) new AtomicInteger(1));
			this.deque.push_left((E) new AtomicInteger(2));
			this.deque.push_right((E) new AtomicInteger(3));
			this.deque.push_right((E) new AtomicInteger(4));
			this.deque.pop_left();
			this.deque.pop_right();
			this.deque.pop_left();
			this.deque.pop_right();
			this.deque.push_right((E) new AtomicInteger(5));
			this.deque.push_left((E) new AtomicInteger(6));
		}
		// sequencia 4
		else if (this.seq == 4)
		{
			this.deque.push_left((E) new AtomicInteger(11));
			this.deque.push_left((E) new AtomicInteger(22));
			this.deque.push_right((E) new AtomicInteger(33));
			this.deque.push_right((E) new AtomicInteger(44));
			this.deque.pop_left();
			this.deque.pop_right();
			this.deque.pop_left();
			this.deque.pop_right();
			this.deque.push_right((E) new AtomicInteger(55));
			this.deque.push_left((E) new AtomicInteger(66));
		}
		// sequencia 5
		else if (this.seq == 5)
		{
			for (int i = 0; i < 10; i++) {
				this.deque.push_left((E) new Double(1));
			}
			
			for (int i = 0; i < 10; i++) {
				this.deque.pop_right();
			}
			
		}
		// sequencia 6
		else if (this.seq == 6)
		{
			
			for (int i = 0; i < 10; i++) {
				this.deque.push_right((E) new Double(3));
			}
			for (int i = 0; i < 10; i++) {
				this.deque.pop_left();
			}
			
		}

	}

	public static void main(String[] args) {

		
			List<DequeThread<Double>> threads = new ArrayList<DequeThread<Double>>();

			DoubleDeque<Double> d = new DoubleDeque<Double>();
			DequeThread<Double> q1 = new DequeThread<Double>(5, d);
			DequeThread<Double> q2 = new DequeThread<Double>(6, d);
			threads.add(q1);
			threads.add(q2);

			for (DequeThread<Double> deque : threads)
			{
				deque.start();
			}

			try
			{
				q1.join();
				q2.join();
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}

			
		
	}
}
