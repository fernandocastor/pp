package trabalho05.deque.hash;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class PDeq<E> {

	private List<Deq<E>> deqList = new ArrayList<Deq<E>>(PDEQ_N_BKTS);
	static int PDEQ_N_BKTS = 4;
	private Lock llock = new ReentrantLock();
	private Lock rlock = new ReentrantLock();
	private int lidx = 0;
	private int ridx = 1;

	public PDeq() {
		for (int i = 0; i < PDEQ_N_BKTS; i++)
		{
			deqList.add(i, new Deq<E>());
		}
	}

	public int moveLeft(int idx) {
		return (idx - 1) & (PDEQ_N_BKTS - 1);
	}

	public int moveRight(int idx) {
		return (idx + 1) & (PDEQ_N_BKTS - 1);
	}

	public void pdeq_pop_l() {
		this.llock.lock();
		int i = this.moveRight(lidx);
		Object elem = this.deqList.get(i).deq_pop_l();
		if (elem != null)
		{
			lidx = i;
		}
		this.llock.unlock();
	}

	public void pdeq_pop_r() {
		this.rlock.lock();
		int i = this.moveLeft(ridx);
		Object elem = this.deqList.get(i).deq_pop_r();
		if (elem != null)
		{
			ridx = i;
		}
		this.rlock.unlock();
	}
	
	public void pdeq_push_l(E e) {
		this.llock.lock();
		int i = lidx;
		this.deqList.get(i).deq_push_l(e);
		lidx = this.moveLeft(lidx);
		this.llock.unlock();
	}
	
	public void pdeq_push_r(E e) {
		this.rlock.lock();
		int i = ridx;
		this.deqList.get(i).deq_push_r(e);
		ridx = this.moveRight(ridx);
		this.rlock.unlock();
	}

	@Override
	public String toString() {
		return this.deqList.toString();
	}
	
	
}
