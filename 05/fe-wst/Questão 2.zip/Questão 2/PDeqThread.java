package trabalho05.deque.hash;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class PDeqThread<E> extends Thread {

	private PDeq<E> pDeq;
	private int seq = 0;

	public PDeqThread(int s, PDeq<E> p) {
		this.seq = s;
		this.pDeq = p;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void run() {

		// sequencia 1
		if (this.seq == 1)
		{
			this.pDeq.pdeq_push_r((E) "R1");
			this.pDeq.pdeq_push_r((E) "R2");
			this.pDeq.pdeq_push_r((E) "R3");
			this.pDeq.pdeq_push_r((E) "R4");
			this.pDeq.pdeq_push_l((E) "L0");
			this.pDeq.pdeq_push_l((E) "L1");
			this.pDeq.pdeq_push_l((E) "L2");
			this.pDeq.pdeq_push_r((E) "R5");

			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();

		}
		// sequencia 2
		else if (this.seq == 2)
		{
			this.pDeq.pdeq_push_r((E) "R11");
			this.pDeq.pdeq_push_r((E) "R22");
			this.pDeq.pdeq_push_r((E) "R33");
			this.pDeq.pdeq_push_r((E) "R44");
			this.pDeq.pdeq_push_l((E) "L00");
			this.pDeq.pdeq_push_l((E) "L11");
			this.pDeq.pdeq_push_l((E) "L22");
			this.pDeq.pdeq_push_r((E) "R55");

			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
		}
		// sequencia 3
		else if (this.seq == 3)
		{
			this.pDeq.pdeq_push_l((E) new AtomicInteger(1));
			this.pDeq.pdeq_push_l((E) new AtomicInteger(2));
			this.pDeq.pdeq_push_r((E) new AtomicInteger(3));
			this.pDeq.pdeq_push_r((E) new AtomicInteger(4));
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_push_r((E) new AtomicInteger(5));
			this.pDeq.pdeq_push_l((E) new AtomicInteger(6));
		}
		// sequencia 4
		else if (this.seq == 4)
		{
			this.pDeq.pdeq_push_l((E) new AtomicInteger(11));
			this.pDeq.pdeq_push_l((E) new AtomicInteger(22));
			this.pDeq.pdeq_push_r((E) new AtomicInteger(33));
			this.pDeq.pdeq_push_r((E) new AtomicInteger(44));
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_push_r((E) new AtomicInteger(55));
			this.pDeq.pdeq_push_l((E) new AtomicInteger(66));
		}
		// sequencia 5
		else if (this.seq == 5)
		{
			for (int i = 0; i < 10; i++) {
				this.pDeq.pdeq_push_l((E) new Double(1));
			}
			for (int i = 0; i < 10; i++) {
				this.pDeq.pdeq_push_r((E) new Double(3));
			}		
			for (int i = 0; i < 10; i++) {
				this.pDeq.pdeq_pop_r();
			}
			for (int i = 0; i < 10; i++) {
				this.pDeq.pdeq_pop_l();
			}
			
		}
		// sequencia 6
		else if (this.seq == 6)
		{
			
			
		}
	}

	public static void main(String[] args) {

		PDeq<Double> pDeq = new PDeq<Double>();
		List<PDeqThread<Double>> threads = new ArrayList<PDeqThread<Double>>();
		PDeqThread<Double> t1 = new PDeqThread<Double>(5, pDeq);
		//PDeqThread<Double> t2 = new PDeqThread<Double>(6, pDeq);
		threads.add(t1);
		//threads.add(t2);

		for (PDeqThread<Double> deque : threads)
		{
			deque.start();
		}

		try
		{
			t1.join();
			//t2.join();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}

		

	}

}
