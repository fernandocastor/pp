/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deque;

import java.util.LinkedList;
import java.util.concurrent.locks.ReentrantLock;
/**
 *
 * @author Carlos
 */
public class DequeComposta<T> {

    private LinkedList<T> listaEsquerda;
    private LinkedList<T> listaDireita;
    private ReentrantLock travaEsquerda;
    private ReentrantLock travaDireita;

    public DequeComposta() {
        travaDireita = new ReentrantLock();
        travaEsquerda = new ReentrantLock();
        listaDireita = new LinkedList<T>();
        listaEsquerda = new LinkedList<T>();
    }

    public T popEsquerda() {
        try {
            travaEsquerda.lock();
            if (!listaEsquerda.isEmpty()) {
                return listaEsquerda.pollFirst();
            } else {
                try {
                    travaDireita.lock();
                    if (!listaDireita.isEmpty()) {
                        return listaDireita.pollFirst();
                    } else {
                        return null;
                    }
                } finally {
                    travaDireita.unlock();
                }
            }
        } finally {
            travaEsquerda.unlock();
        }
    }

    public T popDireita() {
        try {
            travaDireita.lock();

            if (!listaDireita.isEmpty()) {
                return listaDireita.pollLast();
            } else {
                try {
                    if (!travaEsquerda.tryLock()) {
                        travaDireita.unlock();
                        travaEsquerda.lock();
                        travaDireita.lock();
                    }

                    if (!listaDireita.isEmpty()) {
                        return listaDireita.pollLast();
                    } else if (!listaEsquerda.isEmpty()) {
                        return listaEsquerda.pollLast();
                    } else {
                        return null;
                    }
                } finally {
                    travaEsquerda.unlock();
                }
            }
        } finally {
            travaDireita.unlock();
        }
    }

    public void pushEsqueda(T elemento) {

        travaEsquerda.lock();
        listaEsquerda.addFirst(elemento);
        travaEsquerda.unlock();

    }

    public void pushDireita(T elemento) {
        travaDireita.lock();
        listaDireita.addFirst(elemento);
        travaDireita.unlock();
    }

}
