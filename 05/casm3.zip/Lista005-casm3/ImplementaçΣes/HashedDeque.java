/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deque;

/**
 *
 * @author Carlos
 */
import java.util.concurrent.locks.ReentrantLock;

public class HashedDeque<T> {
    private Deque<T>[] bucket;
    private ReentrantLock travaEsquerda;
    private ReentrantLock travaDireita;
    private int indiceEsquerda;
    private int indiceDireita;
    private int numBucket = 8;

    public HashedDeque() {
        travaEsquerda = new ReentrantLock();
        travaDireita = new ReentrantLock();
        indiceEsquerda = 0;
        indiceDireita = 1;
        bucket = (Deque<T>[]) new Deque[numBucket];
        for (int i = 0; i<numBucket; i++) {
            bucket[i] = new Deque<T>();
        }

    }

    public void pushLeft(T e) {
        
            travaEsquerda.lock();
            bucket[indiceEsquerda].pushLeft(e);
            
            if(indiceEsquerda==0){
                indiceEsquerda=numBucket-1;
            }else{
                indiceEsquerda--;
            }
            
            travaEsquerda.unlock();
    }

    public void pushRight(T e) {
        try {
            travaDireita.lock();
            bucket[indiceDireita].pushRight(e);
            if(indiceDireita==numBucket-1){
                indiceEsquerda=0;
            }else{
                indiceEsquerda++;
            }
        } finally {
            travaDireita.unlock();
        }
    }

    public T popLeft() {
        try {
            travaEsquerda.lock();
            int i=indiceEsquerda;
            if(i==numBucket-1){
                i=0;
            }else{
                i++;
            }
                    
            T temp = bucket[i].popLeft();
            if (temp != null) {
                indiceEsquerda = i;
            }
            return temp;
        } finally {
            travaEsquerda.unlock();
        }
    }

    public T popRight() {
        try {
            travaDireita.lock();
            int i = indiceDireita;
            if(i==0){
                i=numBucket-1;
            }else{
                i--;
            }
            
            T temp = bucket[i].popRight();
            if (temp != null) {
                indiceDireita = i;
            }
            return temp;
        } finally {
            travaDireita.unlock();
        }
    }

}
