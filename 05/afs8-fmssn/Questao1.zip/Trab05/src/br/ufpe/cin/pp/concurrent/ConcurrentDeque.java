package br.ufpe.cin.pp.concurrent;

import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ConcurrentDeque<E> {

	private Lock lockRight;
	private Lock lockLeft;

	private LinkedList<E> listRight;
	private LinkedList<E> listLeft;

	public ConcurrentDeque() {
		this.listLeft = new LinkedList<E>();
		this.listRight = new LinkedList<E>();
		this.lockLeft = new ReentrantLock();
		this.lockRight = new ReentrantLock();
	}

	public void push_right(E elem) {
		this.lockRight.lock();
		this.listRight.push(elem);
		this.lockRight.unlock();
	}

	public void push_left(E elem) {
		this.lockLeft.lock();
		this.listLeft.push(elem);
		this.lockLeft.unlock();
	}

	public E pop_right() {
		E elem = null;

		this.lockRight.lock();
		if (this.listRight.isEmpty()) {

			this.lockRight.unlock();
			this.lockLeft.lock();
			this.lockRight.lock();

			if (this.listRight.isEmpty()) { // double-checking idiom. might be a
											// problem
				if (this.listLeft.isEmpty()) {
					; // do nothing.
				} else {
					elem = this.listLeft.removeLast();
				}
			} else {
				elem = this.listRight.pop();
			}
			this.lockRight.unlock();
			this.lockLeft.unlock();

		} else {
			elem = listRight.pop();
			this.lockRight.unlock();
		}

		return elem;
	}

	public E pop_left() {
		E elem = null;

		this.lockLeft.lock();
		if (this.listLeft.isEmpty()) {
			this.lockRight.lock();
			if (this.listRight.isEmpty()) {
				; // do nothing;
			} else {
				elem = this.listRight.removeLast();
			}
			this.lockRight.unlock();
			this.lockLeft.unlock();
		} else {
			elem = this.listLeft.pop();
			this.lockLeft.unlock();
		}

		return elem;
	}

}
