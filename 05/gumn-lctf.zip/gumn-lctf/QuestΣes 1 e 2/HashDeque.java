
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class HashDeque<E> {
	private SimpleDeque<E> buckets[];
	private Lock leftLock, rightLock;
	private int leftIndex, rightIndex;
	private int numberOfBuckets;
	
	@SuppressWarnings("unchecked")
	public HashDeque(int nob) {
		if(nob<1)
			numberOfBuckets = 4;
		else
			numberOfBuckets = nob;
		
		buckets = (SimpleDeque<E>[]) new SimpleDeque[numberOfBuckets];
		
		for(int i=0; i<numberOfBuckets; i++) {
			buckets[i] = new SimpleDeque<E>();
		}
		
		leftLock = new ReentrantLock();
		rightLock = new ReentrantLock();
		
		leftIndex = 0;
		rightIndex = 1;
	}
	
	public HashDeque() {
		this(4);
	}
	
	public void pushLeft(E e) {
		try {
			leftLock.lock();
			buckets[leftIndex].pushLeft(e);
			leftIndex = this.moveLeft(leftIndex);
		} finally {
			leftLock.unlock();
		}
	}
	
	public void pushRight(E e) {
		try {
			rightLock.lock();
			buckets[rightIndex].pushRight(e);
			rightIndex = this.moveRight(rightIndex);
		} finally {
			rightLock.unlock();
		}
	}
	
	public E popLeft() {
		try {
			leftLock.lock();
			int i = this.moveRight(leftIndex);
			E e = buckets[i].popLeft();
			if(e!=null)
				leftIndex = i;
			return e;
		} finally {
			leftLock.unlock();
		}
	}
	
	public E popRight() {
		try {
			rightLock.lock();
			int i = this.moveLeft(rightIndex);
			E e = buckets[i].popRight();
			if(e!=null)
				rightIndex = i;
			return e;
		} finally {
			rightLock.unlock();
		}
	}
	
	private int moveLeft(int index) {
		return (index-1) & (numberOfBuckets-1);
	}
	
	private int moveRight(int index) {
		return (index+1) & (numberOfBuckets-1);
	}
}
