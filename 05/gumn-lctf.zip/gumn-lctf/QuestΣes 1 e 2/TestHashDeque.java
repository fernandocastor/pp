
public class TestHashDeque {
	private static HashDeque<Integer> deque = new HashDeque<Integer>();
	
	public static void main(String[] args) {
		long t1 = System.currentTimeMillis();
		
		PushLeftThread pushL1 = new PushLeftThread();
		PushLeftThread pushL2 = new PushLeftThread();
		
		PushRightThread pushR1 = new PushRightThread();
		PushRightThread pushR2 = new PushRightThread();
		
		PopLeftThread popL1 = new PopLeftThread();
		PopLeftThread popL2 = new PopLeftThread();
		
		PopRightThread popR1 = new PopRightThread();
		PopRightThread popR2 = new PopRightThread();
		
		pushL1.start();
		pushL2.start();
		pushR1.start();
		pushR2.start();
		
		popL1.start();
		popL2.start();
		popR1.start();
		popR2.start();
		
		try {
			pushL1.join();
			pushL2.join();
			pushR1.join();
			pushR2.join();
			
			popL1.join();
			popL2.join();
			popR1.join();
			popR2.join();
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		long t2 = System.currentTimeMillis();
		System.out.println("Tempo de execu��o = " + (t2 - t1) + " ms");
	}

	static class PushLeftThread extends Thread {
		public void run() {
			for(int i=0; i<1000000; i++) {
				deque.pushLeft(i);
			}
		}
	}

	static class PushRightThread extends Thread {
		public void run() {
			for(int i=0; i<1000000; i++) {
				deque.pushRight(i);
			}
		}
	}

	static class PopLeftThread extends Thread {
		public void run() {
			Integer i = null;
			
			do {
				i = deque.popLeft();
			} while(i!=null);
		}
	}

	static class PopRightThread extends Thread {
		public void run() {
			Integer i = null;
			
			do {
				i = deque.popRight();
			} while(i!=null);
		}
	}

}
