
import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CompoundDeque<E> {
	private LinkedList<E> leftQueue, rightQueue;
	private Lock leftLock, rightLock;
	
	public CompoundDeque() {
		leftQueue = new LinkedList<E>();
		rightQueue = new LinkedList<E>();
		leftLock = new ReentrantLock();
		rightLock = new ReentrantLock();
	}
	
	public void pushLeft(E e) {
		try {
			leftLock.lock();
			leftQueue.addFirst(e);
		} finally {
			leftLock.unlock();
		}
	}
	
	public void pushRight(E e) {
		try {
			rightLock.lock();
			rightQueue.addLast(e);
		} finally {
			rightLock.unlock();
		}
	}
	
	public E popLeft() {
		try {
			leftLock.lock();
			
			if(!leftQueue.isEmpty()) {
				return leftQueue.pollFirst();
			} else {
				try {
					rightLock.lock();
					
					if(!rightQueue.isEmpty()) {
						return rightQueue.pollFirst();
					} else {
						return null;
					}
				} finally {
					rightLock.unlock();
				}
			}
		} finally {
			leftLock.unlock();
		}
	}
	
	public E popRight() {
		try {
			rightLock.lock();
			
			if(!rightQueue.isEmpty()) {
				return rightQueue.pollLast();
			} else {
				try {
					if(!leftLock.tryLock()) {
						rightLock.unlock();
						leftLock.lock();
						rightLock.lock();
					}
					
					if(!rightQueue.isEmpty()) {
						return rightQueue.pollLast();
					} else if(!leftQueue.isEmpty()) {
						return leftQueue.pollLast();
					} else {
						return null;
					}
				} finally {
					leftLock.unlock();
				}
			}
		} finally {
			rightLock.unlock();
		}
	}
}
