
import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SimpleDeque<E> {
	private LinkedList<E> queue;
	private Lock lock;
	
	public SimpleDeque() {
		queue = new LinkedList<E>();
		lock = new ReentrantLock();
	}
	
	public void pushLeft(E e) {
		try {
			lock.lock();
			queue.addFirst(e);
		} finally {
			lock.unlock();
		}
	}
	
	public void pushRight(E e) {
		try {
			lock.lock();
			queue.addLast(e);
		} finally {
			lock.unlock();
		}
	}
	
	public E popLeft() {
		try {
			lock.lock();
			
			if(!queue.isEmpty()) {
				return queue.pollFirst();
			} else {
				return null;
			}
		} finally {
			lock.unlock();
		}
	}
	
	public E popRight() {
		try {
			lock.lock();
			
			if(!queue.isEmpty()) {
				return queue.pollLast();
			} else {
				return null;
			}
		} finally {
			lock.unlock();
		}
	}
}
