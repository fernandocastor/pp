

import java.util.concurrent.atomic.AtomicLong;

public class CounterAtomicLong {
	
	private AtomicLong counter = new AtomicLong();

	public void increment() {
		counter.incrementAndGet();
	}
	
	public long getCounter() {
		return counter.get();
	}
	
	public void setCounter(long c) {
		this.counter.set(c);
	}

}
