import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;


public class ThreadCounter {
	
	public static void main(String[] args) throws InterruptedException {
		
		
		
		int N_THREADS;
		long GLOBALCOUNTMAX;
		if (args != null && args.length > 0) {
			N_THREADS = Integer.valueOf(args[0]);
			if (args.length > 1) {
				GLOBALCOUNTMAX = Long.valueOf(args[1]);
			} else {
				GLOBALCOUNTMAX = Integer.MAX_VALUE;
			}
		} else {
			N_THREADS = 10;
			GLOBALCOUNTMAX = Integer.MAX_VALUE;
		}

		System.err.println("NUMBER OF THREADS " + N_THREADS);
		long starTime = System.currentTimeMillis();
		
		AtomicLong count = new AtomicLong();
		
		List<Thread> threads = new ArrayList<Thread>();
		List<CountingThread> countingThreads = new ArrayList<CountingThread>();
		for (int i = 0; i < N_THREADS; i++) {
			CountingThread countingThread = new CountingThread(count);
			countingThreads.add(countingThread);

			Thread thread = new Thread(countingThread, String.valueOf(i));
			threads.add(thread);
			thread.start();
		}

		
		for (Thread thread : threads) {
			thread.join();
		}


		long finalTime = System.currentTimeMillis();

		System.err.println("TIME:" + (finalTime - starTime));
		System.err.println("VALOR FINAL" +count);
		
	}

}

class CountingThread implements Runnable {

	private volatile AtomicLong counter;

	public CountingThread(AtomicLong counter) {
		this.counter = counter;
	}


	@Override
	public void run() {
		while (counter.get() < Integer.MAX_VALUE) {
			counter.incrementAndGet();
		}

		System.err.println("OUT:" + Thread.currentThread().getName());
	}

}
