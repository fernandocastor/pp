#!/bin/bash

FOLDER="/media/marcelo/DATA/Projects/workspace3/castor"
APLICATION_PATH=$FOLDER/src

JAVA_HOME=/usr/lib/jvm/java-8-oracle
PATH=$JAVA_HOME/bin
CLASSPATH=$JAVA_HOME/lib
CLASSPATH=$JAVA_HOME/lib:$APLICATION_PATH
export JAVA_HOME CLASSPATH PATH 

cd $APLICATION_PATH

echo "EXECUCAO DO PROGRAMA"
echo

javac ThreadCounter.java -cp $CLASSPATH
	
	OUT=$FOLDER/ThreadCounter.txt
	/usr/bin/touch $OUT

for i in 2 4 6 8 10 
	do
	    echo   >> $OUT
	    echo  NUMBER OF THREADS $i >> $OUT
	    echo   >> $OUT
		for j in 1 2 3 4 5 6 7 8 9 10 11 12 13 
		do
		    echo
			echo  EXECUCAO $CLASS
	        echo  NUMBER OF THREADS $i
			echo "EXECUCAO #"$j 
			echo   >> $OUT 
			/usr/bin/time -p -o $OUT -a java -Xmx6048m -Xms4048m ThreadCounter $i
					
		done
		 	 
	done