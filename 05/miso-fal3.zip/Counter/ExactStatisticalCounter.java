

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ExactStatisticalCounter {

	public static long N_THREADS = 3;
	public static long GLOBALCOUNTMAX = Integer.MAX_VALUE;
	public static long GLOBALCOUNT = 0;
	public static long GLOBALRESERVE = 0;
	public static long DELTA = 1;
	public static volatile boolean STOP = false;

	public static List<ThreadWriter> THREADS = new ArrayList<ThreadWriter>();

	public static void main(String[] args) throws InterruptedException {

			final Lock lock = new ReentrantLock();

			// args[0] = N (number of threads)
			// args[1] = K (limit of the sum of the counters)
			int n_args = args.length;
			if (n_args > 0) {
				N_THREADS = Long.valueOf(args[0]);
				if (n_args > 1) {
					GLOBALCOUNTMAX = Long.valueOf(args[1]);
				}
			} else {
				N_THREADS = 10;
				GLOBALCOUNTMAX = Integer.MAX_VALUE;
			}

			// create N writer threads
			for (int x = 0; x < N_THREADS; x++) {
				CounterObject co = new CounterObject();
				ThreadWriter e = new ThreadWriter(co, x, lock);
				THREADS.add(e);
				System.err.println("a" + x + "\t" + e.hashCode());
			}

			int x = 0;
			for (Thread thread : THREADS) {
				System.err.println("b" +x++ + "\t" + thread.hashCode());
				thread.start();
			}			
			
			Thread t = new Thread(new Runnable() {

				@Override
				public void run() {

					while (!STOP) {
						lock.lock();
						long total = ExactStatisticalCounter.GLOBALCOUNT;

						for (ThreadWriter t : THREADS) {
							total = total + t.getCounter().getCounter().getCounter();
						}
						lock.unlock();
						if (total == ExactStatisticalCounter.GLOBALCOUNTMAX) {
							STOP = true;
						}
					}
				}
			});

			t.start();
		}

}
