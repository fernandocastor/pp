

public class CounterObject implements Cloneable {

	private CounterAtomicLong counter;
	private long countermax;

	public CounterObject() {
		this.counter = new CounterAtomicLong();
		this.countermax = 0;
	}

	public synchronized void atomic_set(long c, long cm) {
		this.counter.setCounter(c);
		this.countermax = cm;
	}

	public CounterAtomicLong getCounter() {
		return counter;
	}

	public long getCountermax() {
		return countermax;
	}

	public synchronized boolean compareAndChange(long c, long cm, long c_new, long cm_new) {
		
		boolean success = false;
		if (c == this.counter.getCounter() && cm == this.countermax) {
			this.atomic_set(c_new, cm_new);
			success = true;
		}
		return success;
	}

	
	public CounterObject atomic_change()  {
		
		CounterObject c_new = null;
		try {
			c_new = (CounterObject) this.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
		this.atomic_set(0,0);
		
		return c_new;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		CounterObject novo = new CounterObject();
		novo.atomic_set(this.counter.getCounter(), this.countermax);
		return novo;
	}
	
	
}
