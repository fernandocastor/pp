

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

public class StatisticalCounterAtomicLong {

	// Array usado para controlar os contadores internos de cada thread
	// atualizadora
	protected AtomicLong[] counter;

	// Variavel parametrizavel para controlar a quantidade de threads
	protected int numberThreads;

	// Variavel para controlar a execucao da thread leitora
	protected static volatile long stopFlag;

	// Variavel para controlar o valor global do contador
	protected static volatile long globalCounter;

	public StatisticalCounterAtomicLong(int n) {
		this.numberThreads = n;

		this.counter = new AtomicLong[numberThreads];
		for (int i = 0; i < counter.length; i++) {
			counter[i] = new AtomicLong(0);
		}
		globalCounter = 0;
		stopFlag = 0;

	}

	public void inc(int id) {
		counter[id].incrementAndGet();
	}

	public long getCount() {
		return globalCounter;
	}

	public void countInit() {
		EventualThread eventual = new EventualThread();
		Thread thread = new Thread(eventual);
		thread.start();
	}

	public void countCleanup() {
		try {
			stopFlag = 1;
			while (stopFlag < 3) {
				TimeUnit.MICROSECONDS.sleep((long) (Math.random() * 1000));
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
			return;
		}
	}

	/**
	 * Thread Eventual usada para atualizar continuamente o valor do contador
	 * global
	 * 
	 */
	class EventualThread implements Runnable {

		@Override
		public void run() {
			long sum;
			while (stopFlag < 3) {
				sum = 0;
				for (AtomicLong count : counter) {
					sum += count.get();
				}

				globalCounter = sum;
				if (stopFlag != 0) {
					stopFlag++;
				}
			}
		}
	}

	class CountingThread implements Runnable {

		private final StatisticalCounterAtomicLong counter;
		private boolean isLive;
		private final int id;

		public CountingThread(StatisticalCounterAtomicLong counter, int id) {
			this.counter = counter;
			this.id = id;
			this.isLive = true;
		}

		public void shutdown() {
			this.isLive = false;
		}

		@Override
		public void run() {
			while (isLive) {
				counter.inc(id);
			}

			System.err.println("OUT:" + Thread.currentThread().getName());
		}

	}

	public static void main(String[] args) throws InterruptedException {
		int N_THREADS;
		long GLOBALCOUNTMAX;
		if (args != null && args.length > 0) {
			N_THREADS = Integer.valueOf(args[0]);
			if (args.length > 1) {
				GLOBALCOUNTMAX = Long.valueOf(args[1]);
			} else {
				GLOBALCOUNTMAX = Integer.MAX_VALUE;
			}
		} else {
			N_THREADS = 10;
			GLOBALCOUNTMAX = Integer.MAX_VALUE;
		}

		long starTime = System.currentTimeMillis();

		StatisticalCounterAtomicLong counter = new StatisticalCounterAtomicLong(
				N_THREADS);
		counter.countInit();

		List<Thread> threads = new ArrayList<Thread>();
		List<CountingThread> countingThreads = new ArrayList<CountingThread>();
		for (int i = 0; i < N_THREADS; i++) {
			CountingThread countingThread = counter.new CountingThread(counter,
					i);
			countingThreads.add(countingThread);

			Thread thread = new Thread(countingThread, String.valueOf(i));
			threads.add(thread);
			thread.start();
		}

		while (counter.getCount() < GLOBALCOUNTMAX) {
			// System.err.println("WHILE:" + counter.getCount());
		}

		for (CountingThread countingThread : countingThreads) {
			countingThread.shutdown();
		}
		
		for (Thread thread : threads) {
			thread.join();
		}

		counter.countCleanup();

		long finalTime = System.currentTimeMillis();

		System.err.println("TIME:" + (finalTime - starTime));
	}
}
