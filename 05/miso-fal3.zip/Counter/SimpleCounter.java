

public class SimpleCounter {
	
	public static void main(String[] args) {
		
		long count = 0;
		for (int i = 0; i < Integer.MAX_VALUE; i++) {
			count++;
		}
		System.err.println("VALOR FINAL" +count);
		
	}

}
