

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class StatisticalCounterLongVolatile {

	// Array usado para controlar os contadores internos de cada thread
	// atualizadora
	protected volatile long[] counter;

	// Variavel parametrizavel para controlar a quantidade de threads
	protected int numberThreads;

	// Variavel para controlar a execucao da thread leitora
	protected static volatile long stopFlag;

	// Variavel para controlar o valor global do contador
	protected static volatile long globalCounter;

	public StatisticalCounterLongVolatile(int n) {
		this.numberThreads = n;

		this.counter = new long[numberThreads];
		globalCounter = 0;
		stopFlag = 0;

	}

	public void inc(int id) {
		++counter[id];
	}

	public long getCount() {
		return globalCounter;
	}

	public void countInit() {
		EventualThreadLongVolatile eventual = new EventualThreadLongVolatile();
		Thread thread = new Thread(eventual);
		thread.start();
	}

	public void countCleanup() {
		try {
			stopFlag = 1;
			while (stopFlag < 3) {
				TimeUnit.MICROSECONDS.sleep((long) (Math.random() * 1000));
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
			return;
		}
	}

	/**
	 * Thread Eventual usada para atualizar continuamente o valor do contador
	 * global
	 * 
	 */
	class EventualThreadLongVolatile implements Runnable {

		@Override
		public void run() {
			long sum;
			while (stopFlag < 3) {
				sum = 0;
				for (long count : counter) {
					sum += count;
				}
				globalCounter = sum;
				if (stopFlag != 0) {
					stopFlag++;
				}
			}
		}
	}

	class CountingThreadLongVolatile implements Runnable {

		private final StatisticalCounterLongVolatile counter;
		private boolean isLive;
		private final int id;

		public CountingThreadLongVolatile(
				StatisticalCounterLongVolatile counter, int id) {
			this.counter = counter;
			this.id = id;
			this.isLive = true;
		}

		public void shutdown() {
			this.isLive = false;
		}

		@Override
		public void run() {
			while (isLive) {
				counter.inc(id);
			}
			System.err.println("OUT:" + Thread.currentThread().getName());
		}

	}

	public static void main(String[] args) throws InterruptedException {
		int N_THREADS;
		long GLOBALCOUNTMAX;
		if (args != null && args.length > 0) {
			N_THREADS = Integer.valueOf(args[0]);
			if (args.length > 1) {
				GLOBALCOUNTMAX = Long.valueOf(args[1]);
			} else {
				GLOBALCOUNTMAX = Integer.MAX_VALUE;
			}
		} else {
			N_THREADS = 10;
			GLOBALCOUNTMAX = Integer.MAX_VALUE;
		}

		long starTime = System.currentTimeMillis();

		StatisticalCounterLongVolatile counter = new StatisticalCounterLongVolatile(
				N_THREADS);
		counter.countInit();

		List<Thread> threads = new ArrayList<Thread>();
		List<CountingThreadLongVolatile> countingThreads = new ArrayList<CountingThreadLongVolatile>();
		for (int i = 0; i < N_THREADS; i++) {
			CountingThreadLongVolatile countingThread = counter.new CountingThreadLongVolatile(
					counter, i);
			countingThreads.add(countingThread);

			Thread thread = new Thread(countingThread, String.valueOf(i));
			threads.add(thread);
			thread.start();

		}

		while (counter.getCount() < GLOBALCOUNTMAX) {
		}

		for (CountingThreadLongVolatile countingThread : countingThreads) {
			countingThread.shutdown();
		}

		for (Thread thread : threads) {
			thread.join();
		}
		counter.countCleanup();

		long finalTime = System.currentTimeMillis();

		System.err.println("TIME:" + (finalTime - starTime));
	}
}
