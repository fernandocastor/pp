import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Bucket {

	private Lock lock;
	
	private Element element;
	
	public Bucket() {
		this.lock = new ReentrantLock();
	}
	
	public void lock(){
		this.lock.lock();
	}
	
	public void unlock(){
		this.lock.unlock();
	}

	public Element removeElement() {
		Element e = element;
		element = null;
		return e;
	}

	public void setElement(Element element) {
		this.element = element;
	}

	public boolean isEmpty() {
		return element == null;
	}
	
	@Override
	public String toString() {
		if (element == null) {
			return null;
		} else  {
			return String.valueOf(element.getValue());
		}
	}
	
}
