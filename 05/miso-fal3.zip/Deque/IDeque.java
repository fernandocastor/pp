public interface IDeque {

	public abstract int popLeft();

	public abstract int popRight();

	public abstract void pushLeft(int newElement);

	public abstract void pushRight(int newElement);

}