import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class BucketDeque {
	
	protected static final int BUCKET_SIZE = 4; 
	
	protected Lock leftLock;
	
	protected int leftIdX; 
		
	protected Lock rightLock;
	
	protected int rightIdX;
	
	protected Bucket buckets[];

	private final int dequeBucketSize;
	

	public BucketDeque(){
		this(BUCKET_SIZE);
	}
	
	
	public BucketDeque( int dequeBucketSize ){
		this.dequeBucketSize = dequeBucketSize;
		this.leftLock = new ReentrantLock();
		this.rightLock = new ReentrantLock();
		this.buckets = new Bucket[dequeBucketSize];
		
		this.leftIdX = 0;
		this.rightIdX = 1;
		
		for (int i = 0; i < dequeBucketSize; i++) {
			buckets[i] = new Bucket();
		}
		
	}
	
	protected int moveleft(int idx) {
		return (idx - 1) & (dequeBucketSize - 1);
	}

	protected int moveright(int idx) {
		return (idx + 1) & (dequeBucketSize - 1);
	}
	
	
	protected Element popLeft() {
		
		int position;
		Element result; 
		Bucket bucket;
		
		this.leftLock.lock();
		
		position = moveright(this.leftIdX);
		bucket = this.buckets[position];
		
		bucket.lock();
		if (bucket.isEmpty()){
			result = null;
		} else {
			result =  bucket.removeElement(); 
			this.leftIdX = position;
		}
		bucket.unlock();
		this.leftLock.unlock();
		return result;
	}

	public Element popRight(){
		
		int position;
		Element result;
		Bucket bucket;

		this.rightLock.lock();
		position = moveleft(this.rightIdX);
		bucket = this.buckets[position];
		bucket.lock();
		if (bucket.isEmpty()) {
			result = null;
		} else {
			result = bucket.removeElement();
			this.rightIdX = position;
		}
		bucket.unlock();
		this.rightLock.unlock();
		return result;
	}
	
	public void pushLeft(Element newElement) {
		int position;
		Bucket bucket;

		this.leftLock.lock();
		position = this.leftIdX;
		bucket = this.buckets[position];
		
		bucket.lock();
		bucket.setElement(newElement);
		
		this.leftIdX = moveleft(this.leftIdX);
		
		bucket.unlock();
		this.leftLock.unlock();
	}

	public void pushRight(Element newElement){
		int position;
		Bucket bucket;

		this.rightLock.lock();
		
		position = this.rightIdX;
		bucket = this.buckets[position];
		bucket.lock();
		
		bucket.setElement(newElement);
		this.rightIdX = moveright(this.rightIdX);
		
		bucket.unlock();
		this.rightLock.unlock();
	}
	
	public static void main(String[] args) {
		
//		
//		int MAX = (int) Math.pow(2, 4);
//		
//		System.err.println(MAX);
//		
//		BucketDeque deque = new BucketDeque(MAX);
//		
//		for (int i = 0; i < MAX; i++) {
//			if (i %2 == 0) {
//				deque.pushLeft(new Element(i));
//			} else {
//				deque.pushRight(new Element(i));
//			}
//			
//			//deque.pushLeft(new Element(i));
//			
//
//			System.err.println("\nLeft\n");
//			for (int j = 0; j < deque.buckets.length; j++) {
//				System.err.print(j + "\t");
//			}
//			System.err.println("\n");
//			for (int j = 0; j < deque.buckets.length; j++) {
//				System.err.print(deque.buckets[j] + "\t");
//			}
//		}
//		
//		
//		System.err.println("\nPop Left\n");
//		for (int i = 0; i < MAX; i++) {
//			System.err.print(deque.popLeft() + "\t");
//		}
	}
	

}
