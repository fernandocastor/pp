import java.util.LinkedList;

public class NonThreadSafeDeque  {


	public static void main(String[] args) throws InterruptedException {

		int MAX = Integer.MAX_VALUE / 50;

		LinkedList<Integer>  list = new LinkedList<Integer>();

		long startTime = System.currentTimeMillis();

		for (int i = 0; i < MAX; i++) {
			if (i % 2 == 0) {
				list.addFirst(i);	
			} else {
				list.addLast(i);
			}
		}
		
		System.err.println("1a tarefa encerrada");
		
		
		for (int i = 0; i < MAX; i++) {
			if (i % 2 == 0) {
				list.removeFirst();	
			} else {
				list.removeLast();
			}
		}
		
		System.err.println("2a tarefa encerrada");


		long endTime = System.currentTimeMillis();
		System.err.println("Execution " + (endTime - startTime) + "\n");

	}
}
