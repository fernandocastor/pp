#!/bin/bash

FOLDER="/media/marcelo/DATA/Projects/workspace3/deque"
APLICATION_PATH=$FOLDER/src

OUT=$FOLDER/out.txt

rm $OUT
touch $OUT

JAVA_HOME=/usr/lib/jvm/java-8-oracle
PATH=$JAVA_HOME/bin
CLASSPATH=$JAVA_HOME/lib
CLASSPATH=$JAVA_HOME/lib:$APLICATION_PATH
export JAVA_HOME CLASSPATH PATH 


cd $APLICATION_PATH

javac NonThreadSafeDeque.java -cp $CLASSPATH

echo "EXECUCAO DO PROGRAMA"
echo
		for j in 1 2 3 4 5 6 7 8 9 10 11 12 13 
		do
			echo "EXECUCAO #"$j
			echo   >> $OUT 
			/usr/bin/time -p -o $OUT -a java -Xmx6048m -Xms4048m NonThreadSafeDeque $i $w
		done 
		 	 
	done
done


 

