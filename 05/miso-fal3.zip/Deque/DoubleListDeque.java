import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DoubleListDeque implements IDeque {

	protected Lock leftLock;

	protected Lock rightLock;

	private LinkedList<Integer> rightChain;

	private LinkedList<Integer> leftChain;

	public DoubleListDeque() {

		this.leftLock = new ReentrantLock();
		this.rightLock = new ReentrantLock();
		this.leftChain = new LinkedList<Integer>();
		this.rightChain = new LinkedList<Integer>();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see IDeque#popLeft()
	 */
	@Override
	public int popLeft() {

		int result = -1;
		this.leftLock.lock();
		try {
			if (!this.leftChain.isEmpty()) {
				result = this.leftChain.removeFirst();
			} else {
				this.rightLock.lock();
				try {
					// Se a lista right ainda possuir elementos, estes ser�o
					// divididos com a fila left mantendo a ordem dos mesmos
					if (!rightChain.isEmpty()) {
						result = rightChain.removeFirst();
						// Se a lista left ainda possuir elementos, estes ser�o
						// divididos com a fila right mantendo a ordem dos
						// mesmos
						int size = rightChain.size();
						for (int i = 0; i < size / 2; i++) {
							// A posi��o precisa ser a mesma pois ao remover um
							// elemento, o pr�ximo ocupar� o mesmo �ndice
							this.leftChain.add(this.rightChain.remove(0));
						}
					}
				} finally {
					this.rightLock.unlock();
				}
			}
		} finally {
			this.leftLock.unlock();
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see IDeque#popRight()
	 */
	@Override
	public int popRight() {

		int result = -1;

		this.rightLock.lock();
		try {
			if (!this.rightChain.isEmpty()) {
				result = this.rightChain.removeLast();
			} else {
				this.rightLock.unlock();
				this.leftLock.lock();
				this.rightLock.lock();
				try {
					// Se a lista left ainda possuir elementos, estes ser�o
					// divididos com a fila right mantendo a ordem dos mesmos
					if (this.rightChain.isEmpty() && !this.leftChain.isEmpty()) {
						result = this.leftChain.removeLast();
						int size = leftChain.size();
						for (int i = size; i > size / 2; i--) {
							// A posi��o precisa ser a mesma pois ao remover um
							// elemento, o pr�ximo ocupar� o mesmo �ndice
							this.rightChain
									.add(this.leftChain.remove(size / 2));
						}
					}
				} finally {
					this.leftLock.unlock();
				}
			}
		} finally {
			this.rightLock.unlock();
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see IDeque#pushLeft(Element)
	 */
	@Override
	public void pushLeft(int newElement) {

		this.leftLock.lock();
		try {
			this.leftChain.addFirst(newElement);
		} finally {
			this.leftLock.unlock();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see IDeque#pushRight(Element)
	 */
	@Override
	public void pushRight(int newElement) {
		this.rightLock.lock();
		try {
			this.rightChain.addLast(newElement);
		} finally {
			this.rightLock.unlock();
		}
	}

	public static void main(String[] args) throws InterruptedException {

		int MAX = Integer.MAX_VALUE / 50;

		int numberOfThreads;
		if (args != null && args.length > 0) {
			numberOfThreads = Integer.parseInt(args[0]);
		} else {
			numberOfThreads = 2;
		}

		System.err.println("\n" + "#THREADS:" + numberOfThreads);

		IDeque deque = new DoubleListDeque();

		long startTime = System.currentTimeMillis();

		Thread threads[] = new Thread[numberOfThreads];
		int start, sliceSize;
		start = 0;
		sliceSize = MAX / numberOfThreads;
		for (int i = 0; i < numberOfThreads; i++) {
			// Pushing Elements Threads
			DequeUserRunnable dequeUserRunnable = new DequeUserRunnable(deque,
					start, start + sliceSize, 0, i % 2);
			start += sliceSize;
			threads[i] = new Thread(dequeUserRunnable);
			threads[i].start();
		}

		for (int i = 0; i < numberOfThreads; i++) {
			threads[i].join();
			System.err.println("Thread #" + i + " acabou primeira tarefa");
		}

		start = 0;
		sliceSize = MAX / numberOfThreads;
		for (int i = 0; i < numberOfThreads; i++) {
			// Popping Elements Threads
			DequeUserRunnable dequeUserRunnable = new DequeUserRunnable(deque, start, start + sliceSize, 1, i % 2);
			start += sliceSize;
			threads[i] = new Thread(dequeUserRunnable);
			threads[i].start();
		}

		for (int i = 0; i < numberOfThreads; i++) {
			threads[i].join();
			System.err.println("Thread #" + i + " acabou segunda tarefa");
		}

		long endTime = System.currentTimeMillis();
		System.err.println("Execution " + (endTime - startTime) + "\n");

	}
}
