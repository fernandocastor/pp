import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class HashedDeque implements IDeque {

	protected static final int BUCKET_SIZE = 4;

	protected Lock leftLock;

	protected int leftIndex;

	protected Lock rightLock;

	protected int rightIndex;

	protected LinkedListBucket buckets[];

	private final int dequeBucketSize;

	public HashedDeque() {
		this(BUCKET_SIZE);
	}

	public HashedDeque(int dequeBucketSize) {
		this.dequeBucketSize = dequeBucketSize;
		this.leftLock = new ReentrantLock();
		this.rightLock = new ReentrantLock();
		this.buckets = new LinkedListBucket[dequeBucketSize];

		this.leftIndex = 0;
		this.rightIndex = 1;

		for (int i = 0; i < dequeBucketSize; i++) {
			buckets[i] = new LinkedListBucket();
		}

	}

	protected int moveleft(int idx) {
		return (idx - 1) & (dequeBucketSize - 1);
	}

	protected int moveright(int idx) {
		return (idx + 1) & (dequeBucketSize - 1);
	}

	public int popLeft() {

		int position;
		int result = -1; 
		LinkedListBucket bucket;

		this.leftLock.lock();
		try {
			position = moveright(this.leftIndex);
			bucket = this.buckets[position];
			result = bucket.popLeft();
			if (result != -1) {
				this.leftIndex = position;
			}
		} finally {
			this.leftLock.unlock();
		}
		return result;
	}

	public int popRight() {

		int position;
		int result;
		LinkedListBucket bucket;

		this.rightLock.lock();
		try {
			position = moveleft(this.rightIndex);
			bucket = this.buckets[position];
			result = bucket.popRight();
			if (result != -1) {
				this.rightIndex = position;
			}
		} finally {
			this.rightLock.unlock();
		}
		return result;
	}

	public void pushLeft(int newElement) {
		LinkedListBucket bucket;

		this.leftLock.lock();
		try {
			bucket = this.buckets[this.leftIndex];
			bucket.pushLeft(newElement);
			this.leftIndex = moveleft(this.leftIndex);
		} finally {
			this.leftLock.unlock();
		}
	}

	public void pushRight(int newElement) {
		LinkedListBucket bucket;

		this.rightLock.lock();
		try {
			bucket = this.buckets[this.rightIndex];
			bucket.pushRight(newElement);
			this.rightIndex = moveright(this.rightIndex);
		} finally {
			this.rightLock.unlock();
		}
	}

	public static void main(String[] args) throws InterruptedException {

		int MAX = Integer.MAX_VALUE / 50;

		int numberOfThreads;
		if (args != null && args.length > 0) {
			numberOfThreads = Integer.parseInt(args[0]);
		} else {
			numberOfThreads = 2;
		}
		
		int numberOfBuckets;
		if (args != null && args.length > 1) {
			numberOfBuckets = Integer.parseInt(args[1]);
		} else {
			numberOfBuckets = 4;
		}

		System.err.println("\n" + "#THREADS:" + numberOfThreads);

		IDeque deque = new HashedDeque(numberOfBuckets);

		long startTime = System.currentTimeMillis();

		Thread threads[] = new Thread[numberOfThreads];
		int start, sliceSize;
		start = 0;
		sliceSize = MAX / numberOfThreads;
		for (int i = 0; i < numberOfThreads; i++) {
			// Pushing Elements Threads
			DequeUserRunnable dequeUserRunnable = new DequeUserRunnable(deque,
					start, start + sliceSize, 0, i % 2);
			start += sliceSize;
			threads[i] = new Thread(dequeUserRunnable);
			threads[i].start();
		}

		for (int i = 0; i < numberOfThreads; i++) {
			threads[i].join();
			System.err.println("Thread #" + i + " acabou primeira tarefa");
		}

		start = 0;
		sliceSize = MAX / numberOfThreads;
		for (int i = 0; i < numberOfThreads; i++) {
			// Popping Elements Threads
			DequeUserRunnable dequeUserRunnable = new DequeUserRunnable(deque, start, start + sliceSize, 1, i % 2);
			start += sliceSize;
			threads[i] = new Thread(dequeUserRunnable);
			threads[i].start();
		}

		for (int i = 0; i < numberOfThreads; i++) {
			threads[i].join();
			System.err.println("Thread #" + i + " acabou segunda tarefa");
		}

		long endTime = System.currentTimeMillis();
		System.err.println("Execution " + (endTime - startTime) + "\n");
	}

}
