import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class LinkedListBucket {

	private Lock lock;
	
	private LinkedList<Integer> chain;
	
	public LinkedListBucket() {
		this.lock = new ReentrantLock();
		this.chain = new LinkedList<Integer>();
	}
	
	public void pushLeft(int e) {
		this.lock.lock();
		try {
			this.chain.addFirst(e);
		} finally  {
			this.lock.unlock();
		}
	}
	
	public void pushRight(int e) {
		this.lock.lock();
		try {
			this.chain.addLast(e);
		} finally  {
			this.lock.unlock();
		}
	}

	public int popLeft() {
		this.lock.lock();
		try {
			if (this.chain.isEmpty()){
				return -1; 
			} else {
				return this.chain.removeFirst();
			}
		} finally  {
			this.lock.unlock();
		}
	}

	public int popRight() {
		this.lock.lock();
		try {
			if (this.chain.isEmpty()){
				return -1; 
			} else {
				return this.chain.removeLast();
			}
		} finally  {
			this.lock.unlock();
		}
	}
	
}
