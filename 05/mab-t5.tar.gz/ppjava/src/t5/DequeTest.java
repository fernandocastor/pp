package t5;

import java.util.Deque;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.Assert;
import org.junit.Test;

public class DequeTest {

	private static final int N_ITERATIONS = 100000;

	@Test
	public void testSeq() {
		Deque<Integer> deq = new ConcurrentHashDeque<Integer>(4);
//		Deque<Integer> deq = new ConcurrentDeque<Integer>();

		long start = System.nanoTime();
		for (int i = 0; i <= N_ITERATIONS; i++) {
			deq.addFirst(i);
		}

		for (int i = 0; i <= N_ITERATIONS; i++) {
			deq.addLast(i);
		}
		
		for (int i = N_ITERATIONS; i >= 0; i--) {
			Assert.assertEquals(i, deq.removeFirst().intValue());
		}

		for (int i = N_ITERATIONS; i >= 0; i--) {
			Assert.assertEquals(i, deq.removeLast().intValue());
		}
		long end = System.nanoTime();
		System.out.println((end - start) / 1000000000.0);
	}

	@Test
	public void testP1() throws InterruptedException {
		final AtomicInteger counter = new AtomicInteger();
//		final Deque<Integer> deq = new ConcurrentHashDeque<Integer>(4);
		final Deque<Integer> deq = new ConcurrentDeque<Integer>();

		Runnable rleft = getWriter(true, counter, deq);
		Runnable rright = getWriter(false, counter, deq);
		
		Thread t1 = new Thread(rleft);
		Thread t2 = new Thread(rright);
		t1.start();
		t2.start();
		t1.join();
		t2.join();
	}
	
	@Test
	public void testP2() throws InterruptedException {
		final AtomicInteger counter = new AtomicInteger();
		final Deque<Integer> deq = new ConcurrentHashDeque<Integer>(4);
//		final Deque<Integer> deq = new ConcurrentDeque<Integer>();

		Runnable left = getWriter(true, counter, deq); 
		Runnable right = getWriter(false, counter, deq);
		
		Runnable remleft = getRemover(true, counter, deq);
		Runnable remright = getWriter(false, counter, deq);
		
		Thread t1 = new Thread(left);
		Thread t2 = new Thread(right);
		Thread t3 = new Thread(remleft);
		Thread t4 = new Thread(remright);
		long start = System.nanoTime();
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t1.join();
		t2.join();
		t3.join();
		t4.join();
		long end = System.nanoTime();
		System.out.println((end - start) / 1000000000.0);
	}

	private Runnable getRemover(final boolean removeLeft, final AtomicInteger counter,
			final Deque<Integer> deq) {
		return new Runnable() {
			
			@Override
			public void run() {
				boolean underLimit = true;
				while (true) {
					if (underLimit && counter.get() > N_ITERATIONS) {
						underLimit = false;
					}
					
					if (removeLeft) {
						Integer i = deq.removeFirst();
						if (i == null && !underLimit) {
							break;
						}
					} else {
						Integer i = deq.removeLast();
						if (i == null && !underLimit) {
							break;
						}
					}
				}
			}
		};
	}

	private static Runnable getWriter(final boolean addLeft,
			final AtomicInteger counter, final Deque<Integer> deq) {
		return new Runnable() {
			@Override
			public void run() {
				while (true) {
					int val = counter.getAndIncrement();
					if (val > N_ITERATIONS) {
						break;
					} else {
						if (addLeft) {
							deq.addFirst(val);
						} else {
							deq.addLast(val);
						}
					}
				}
			}
		};
	}
}
