package t5;

import java.util.Collection;
import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ConcurrentHashDeque<T> implements Deque<T> {

	final int nBuckets;
	final LinkedList<T>[] buckets;
	int lidx, ridx;
	Lock llock, rlock;
	

	public ConcurrentHashDeque(int nBuckets) {
		lidx = 0;
		ridx = 1;
		
		llock = new ReentrantLock();
		rlock = new ReentrantLock();
		
		this.nBuckets = nBuckets;
		@SuppressWarnings("unchecked")
		LinkedList<T>[] buckets = (LinkedList<T>[]) new LinkedList[nBuckets];
		this.buckets = buckets;

		for (int i = 0; i < nBuckets; i++) {
			buckets[i] = new LinkedList<T>();
		}
	}

	private int mod(int x, int y) {
		int result = x % y;
	    if (result < 0)
	    {
	        result += y;
	    }
	    return result;
	}
	
	public int moveleft(int idx) {
		return mod(idx - 1, nBuckets);
	}
	
	public int moveright(int idx) {
		return mod(idx + 1, nBuckets);
	}

	@Override
	public void addFirst(T e) {
		llock.lock();
//		System.out.println("[Left - Add] lock for " + e);
		try {			
			buckets[lidx].addFirst(e);
			lidx = moveleft(lidx);
		} finally {
//			System.out.println("[Left - Add] unlock for " + e);
			llock.unlock();
		}
	}

	@Override
	public void addLast(T e) {
		rlock.lock();
//		System.out.println("[Right - Add] lock for " + e);
		try {
			buckets[ridx].addLast(e);
			ridx = moveright(ridx);
		} finally {
//			System.out.println("[Right - Add] unlock for " + e);
			rlock.unlock();
		}
	}

	@Override
	public T removeFirst() {
		llock.lock();
//		System.out.println("[Left - Remove] lock");
		T ret;
		try {
			int i = moveright(lidx);
			ret = buckets[i].pollFirst();
			if (ret != null) {
				lidx = i;
			}
//			System.out.println("[Left - Remove] unlock for " + ret);
		} finally {
			llock.unlock();
		}
		return ret;
	}

	@Override
	public T removeLast() {
		rlock.lock();
//		System.out.println("[Right - Remove] lock");
		T ret;
		try {
			int i = moveleft(ridx);
			ret = buckets[i].pollLast();
			if (ret != null) {
				ridx = i;
			}
//			System.out.println("[Right - Remove] unlock for " + ret);
		} finally {
			rlock.unlock();
		}
		return ret;
	}

	
	
	// unimplemented methods

	
	
	@Override
	public boolean isEmpty() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public Object[] toArray() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public <T> T[] toArray(T[] a) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean addAll(Collection<? extends T> c) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public void clear() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean offerFirst(T e) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean offerLast(T e) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T pollFirst() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T pollLast() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T getFirst() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T getLast() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T peekFirst() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T peekLast() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean removeFirstOccurrence(Object o) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean removeLastOccurrence(Object o) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean add(T e) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean offer(T e) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T remove() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T poll() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T element() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T peek() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public void push(T e) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public T pop() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean remove(Object o) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public boolean contains(Object o) {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public int size() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public Iterator<T> iterator() {
		throw new RuntimeException("Not implemented");
	}

	@Override
	public Iterator<T> descendingIterator() {
		throw new RuntimeException("Not implemented");
	}
}
