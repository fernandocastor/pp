package t4.tracker;

import java.util.concurrent.atomic.AtomicInteger;

public class AtomicIntegerTracker extends Tracker {

	AtomicInteger value = new AtomicInteger(0);
	
	@Override
	public void increment() {
		value.incrementAndGet();
	}

	@Override
	public Number get() {
		return value.get();
	}
}
