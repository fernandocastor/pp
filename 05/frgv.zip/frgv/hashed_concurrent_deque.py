#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
################################### FRGV ######################################

import sys
import datetime
from random import sample, randint
from threading import Thread, Lock
from collections import deque


class HashedConcurrentDeque():

  def __init__(self):
    """  """
    self.left_deque = deque()
    self.right_deque = deque()
    self.hashed = [ self.left_deque, self.right_deque ]

  def push_left(self, element):
    """ Insert a element on the left       """
    self.left_deque.appendleft(element)

  def pop_left(self):
    """ Remove a element on the left       """
    if self.left_deque:
      return ("Left", str(self.left_deque.popleft()))
    else:
      None

  def push_right(self, element):
    """ Insert a element on the right      """
    self.right_deque.append(element)

  def pop_right(self):
    """ Remve a element on the right       """
    if self.right_deque:
      return ("Right", str(self.right_deque.pop()))
    else:
      None


def push_pull(arg, thread_number, lock, n_threads):

  deques = arg
  i = 0
  while (i < (10/n_threads)):
    i += 1
    action_now = (sample(["Push", "Pop"], 1), sample(["Left", "Right"], 1))
    side = str(action_now[1][0])

    if action_now[0][0] == "Push":
      element = str(randint(0, 9))
      if action_now[1][0] == "Left":
        lock.acquire()
        deques.push_left(element)
        lock.release()
      else:
        lock.acquire()
        deques.push_right(element)
        lock.release()
    else:
      if action_now[1][0] == "Left":
        lock.acquire()
        res = deques.pop_left()
        lock.release()
      else:
        lock.acquire()
        res = deques.pop_right()
        lock.release()

      if res:
        side, element = res
      else:
        element = "Empty"

    print """
          Thread: {0}
          Action: {1}, Side: {2}, Value: {3}
          deque status: {4}, {5}
          """.format(thread_number, action_now[0][0], side, element,
                    deques.left_deque, deques.right_deque)

def main():

  param = sys.argv[1:]
  n_threads = int(param[0])

  lock = Lock()

  current_deque = HashedConcurrentDeque()
  for n in range(n_threads):
    new_thread = Thread(target=push_pull, args=(current_deque, n, lock, n_threads))
    new_thread.start()

if __name__ == "__main__":
	main()

