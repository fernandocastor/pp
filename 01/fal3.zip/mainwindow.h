#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <time.h>
#include <qthread.h>
#include <QBasicTimer>
#include <qapplication.h>
#include <qwidget.h>
#include <qpushbutton.h>
#include <qsemaphore.h>
#include <qmutex.h>
#include <qlayout.h>
#include <qmessagebox.h>
#include <qlabel.h>
#include <windows.h>
#include <QTimer>
#include <QString>

#define TAM 5

typedef struct processo
{
    int id;
    int prioridade;
    int executa;
    int bloqueio;
    int tipo;
    int fatia;
}Processo;

typedef struct {
        int inicio; //�ndice para o primeiro elemento a ser requisitado
        int fim;   //�ndice para a posicao livre da fila
        int n; //quantidade de processos na fila
        Processo P[5];
}Fila;


/*typedef struct fila
{
    No *inicio;
    No *fim;
}Fila;*/


//Fila *fila_cria(void);

namespace Ui
{
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
    bool valida(int prioridade, int tipo);
    void MainWindow::fila_remove(Fila *F);
    void fila_insere(Fila *F, int id, int prioridade, int fatia, int tipo, int bloqueio);
    void fila_interrompe(Fila *F1, Fila *F2, Fila *F3, int id, int estado);
    void erroid();
    void errotipo();


public slots:
    void botaocriarclick();
    void botaobloquearclick();
    void botaodesbloquearclick();
    void botaofinalizarclick();
    void executaprocesso();
    void sorriso();
    bool bloqueiaprocesso();
    bool desbloqueiaprocesso();
    bool finalizaprocesso();



public:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
