/********************************************************************************
** Form generated from reading ui file 'form.ui'
**
** Created: Thu 21. May 11:52:01 2009
**      by: Qt User Interface Compiler version 4.5.1
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_FORM_H
#define UI_FORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_POP1
{
public:
    QPushButton *pushButton;
    QSpinBox *spinBox;

    void setupUi(QWidget *POP1)
    {
        if (POP1->objectName().isEmpty())
            POP1->setObjectName(QString::fromUtf8("POP1"));
        POP1->resize(242, 167);
        pushButton = new QPushButton(POP1);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(80, 120, 75, 23));
        spinBox = new QSpinBox(POP1);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setGeometry(QRect(30, 100, 42, 22));

        retranslateUi(POP1);

        QMetaObject::connectSlotsByName(POP1);
    } // setupUi

    void retranslateUi(QWidget *POP1)
    {
        POP1->setWindowTitle(QApplication::translate("POP1", "COISA1", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("POP1", "PushButton", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(POP1);
    } // retranslateUi

};

namespace Ui {
    class POP1: public Ui_POP1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM_H
