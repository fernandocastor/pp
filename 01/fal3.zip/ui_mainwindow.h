/********************************************************************************
** Form generated from reading ui file 'mainwindow.ui'
**
** Created: Mon 15. Jun 20:45:25 2009
**      by: Qt User Interface Compiler version 4.5.1
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLCDNumber>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QMenu>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *menuSAIR;
    QAction *actionOutro;
    QAction *menuSORRISO;
    QWidget *centralWidget;
    QSpinBox *spinBox_Prioridade;
    QSpinBox *spinBox_Tempo;
    QLabel *label_criarprocess;
    QLabel *label_prioridade_2;
    QLabel *label_prioridade;
    QPushButton *botaoCriar;
    QLabel *label_criarprocess_2;
    QLabel *label_prioridade_3;
    QPushButton *botaoFinalizar;
    QFrame *line;
    QPushButton *botaoBloquear;
    QLabel *label_prioridade_4;
    QLabel *label_prioridade_5;
    QPushButton *botaoDesbloquear;
    QComboBox *comboBox_Tipo;
    QLineEdit *lineEdit_IDsF3_5;
    QLCDNumber *lcdNumber;
    QLineEdit *lineEdit_IDsF3_4;
    QLineEdit *lineEdit_IDsF3_3;
    QLineEdit *lineEdit_IDsF3_2;
    QLineEdit *lineEdit_IDsF3_1;
    QLineEdit *lineEdit_IDsF2_4;
    QLineEdit *lineEdit_IDsF2_3;
    QLineEdit *lineEdit_IDsF2_2;
    QLineEdit *lineEdit_IDsF2_1;
    QLineEdit *lineEdit_IDsF2_5;
    QLineEdit *lineEdit_IDsF1_5;
    QLineEdit *lineEdit_IDsF1_3;
    QLineEdit *lineEdit_IDsF1_1;
    QLineEdit *lineEdit_IDsF1_2;
    QLineEdit *lineEdit_IDsF1_4;
    QLabel *label_prioridade_6;
    QLabel *label_prioridade_7;
    QLabel *label_prioridade_8;
    QLabel *label_prioridade_9;
    QLabel *label_prioridade_10;
    QLabel *label_prioridade_11;
    QSpinBox *spinBox_Bloquear;
    QSpinBox *spinBox_Desbloquear;
    QSpinBox *spinBox_Finalizar;
    QMenuBar *menuBar;
    QMenu *menuMENU;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(542, 285);
        menuSAIR = new QAction(MainWindow);
        menuSAIR->setObjectName(QString::fromUtf8("menuSAIR"));
        actionOutro = new QAction(MainWindow);
        actionOutro->setObjectName(QString::fromUtf8("actionOutro"));
        menuSORRISO = new QAction(MainWindow);
        menuSORRISO->setObjectName(QString::fromUtf8("menuSORRISO"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        spinBox_Prioridade = new QSpinBox(centralWidget);
        spinBox_Prioridade->setObjectName(QString::fromUtf8("spinBox_Prioridade"));
        spinBox_Prioridade->setGeometry(QRect(110, 50, 42, 22));
        spinBox_Prioridade->setMinimum(1);
        spinBox_Prioridade->setMaximum(3);
        spinBox_Tempo = new QSpinBox(centralWidget);
        spinBox_Tempo->setObjectName(QString::fromUtf8("spinBox_Tempo"));
        spinBox_Tempo->setGeometry(QRect(110, 80, 42, 22));
        spinBox_Tempo->setMinimum(1);
        spinBox_Tempo->setMaximum(100);
        label_criarprocess = new QLabel(centralWidget);
        label_criarprocess->setObjectName(QString::fromUtf8("label_criarprocess"));
        label_criarprocess->setGeometry(QRect(10, 30, 91, 16));
        label_prioridade_2 = new QLabel(centralWidget);
        label_prioridade_2->setObjectName(QString::fromUtf8("label_prioridade_2"));
        label_prioridade_2->setGeometry(QRect(160, 50, 61, 16));
        label_prioridade = new QLabel(centralWidget);
        label_prioridade->setObjectName(QString::fromUtf8("label_prioridade"));
        label_prioridade->setGeometry(QRect(160, 80, 81, 16));
        botaoCriar = new QPushButton(centralWidget);
        botaoCriar->setObjectName(QString::fromUtf8("botaoCriar"));
        botaoCriar->setGeometry(QRect(10, 80, 91, 23));
        label_criarprocess_2 = new QLabel(centralWidget);
        label_criarprocess_2->setObjectName(QString::fromUtf8("label_criarprocess_2"));
        label_criarprocess_2->setGeometry(QRect(10, 120, 141, 16));
        label_prioridade_3 = new QLabel(centralWidget);
        label_prioridade_3->setObjectName(QString::fromUtf8("label_prioridade_3"));
        label_prioridade_3->setGeometry(QRect(160, 140, 71, 20));
        botaoFinalizar = new QPushButton(centralWidget);
        botaoFinalizar->setObjectName(QString::fromUtf8("botaoFinalizar"));
        botaoFinalizar->setGeometry(QRect(10, 200, 91, 23));
        line = new QFrame(centralWidget);
        line->setObjectName(QString::fromUtf8("line"));
        line->setGeometry(QRect(0, 100, 251, 31));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        botaoBloquear = new QPushButton(centralWidget);
        botaoBloquear->setObjectName(QString::fromUtf8("botaoBloquear"));
        botaoBloquear->setGeometry(QRect(10, 140, 91, 23));
        label_prioridade_4 = new QLabel(centralWidget);
        label_prioridade_4->setObjectName(QString::fromUtf8("label_prioridade_4"));
        label_prioridade_4->setGeometry(QRect(160, 170, 71, 20));
        label_prioridade_5 = new QLabel(centralWidget);
        label_prioridade_5->setObjectName(QString::fromUtf8("label_prioridade_5"));
        label_prioridade_5->setGeometry(QRect(160, 200, 71, 20));
        botaoDesbloquear = new QPushButton(centralWidget);
        botaoDesbloquear->setObjectName(QString::fromUtf8("botaoDesbloquear"));
        botaoDesbloquear->setGeometry(QRect(10, 170, 91, 23));
        comboBox_Tipo = new QComboBox(centralWidget);
        comboBox_Tipo->setObjectName(QString::fromUtf8("comboBox_Tipo"));
        comboBox_Tipo->setGeometry(QRect(10, 50, 91, 22));
        lineEdit_IDsF3_5 = new QLineEdit(centralWidget);
        lineEdit_IDsF3_5->setObjectName(QString::fromUtf8("lineEdit_IDsF3_5"));
        lineEdit_IDsF3_5->setGeometry(QRect(500, 200, 31, 20));
        lineEdit_IDsF3_5->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF3_5->setAutoFillBackground(false);
        lineEdit_IDsF3_5->setMaxLength(99);
        lineEdit_IDsF3_5->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF3_5->setReadOnly(true);
        lcdNumber = new QLCDNumber(centralWidget);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        lcdNumber->setGeometry(QRect(400, 30, 131, 61));
        lcdNumber->setCursor(QCursor(Qt::WaitCursor));
        lcdNumber->setSmallDecimalPoint(false);
        lcdNumber->setNumDigits(2);
        lcdNumber->setSegmentStyle(QLCDNumber::Outline);
        lineEdit_IDsF3_4 = new QLineEdit(centralWidget);
        lineEdit_IDsF3_4->setObjectName(QString::fromUtf8("lineEdit_IDsF3_4"));
        lineEdit_IDsF3_4->setGeometry(QRect(500, 180, 31, 20));
        lineEdit_IDsF3_4->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF3_4->setAutoFillBackground(false);
        lineEdit_IDsF3_4->setMaxLength(99);
        lineEdit_IDsF3_4->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF3_4->setReadOnly(true);
        lineEdit_IDsF3_3 = new QLineEdit(centralWidget);
        lineEdit_IDsF3_3->setObjectName(QString::fromUtf8("lineEdit_IDsF3_3"));
        lineEdit_IDsF3_3->setGeometry(QRect(500, 160, 31, 20));
        lineEdit_IDsF3_3->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF3_3->setAutoFillBackground(false);
        lineEdit_IDsF3_3->setMaxLength(99);
        lineEdit_IDsF3_3->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF3_3->setReadOnly(true);
        lineEdit_IDsF3_2 = new QLineEdit(centralWidget);
        lineEdit_IDsF3_2->setObjectName(QString::fromUtf8("lineEdit_IDsF3_2"));
        lineEdit_IDsF3_2->setGeometry(QRect(500, 140, 31, 20));
        lineEdit_IDsF3_2->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF3_2->setAutoFillBackground(false);
        lineEdit_IDsF3_2->setMaxLength(99);
        lineEdit_IDsF3_2->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF3_2->setReadOnly(true);
        lineEdit_IDsF3_1 = new QLineEdit(centralWidget);
        lineEdit_IDsF3_1->setObjectName(QString::fromUtf8("lineEdit_IDsF3_1"));
        lineEdit_IDsF3_1->setGeometry(QRect(500, 120, 31, 20));
        lineEdit_IDsF3_1->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF3_1->setAutoFillBackground(false);
        lineEdit_IDsF3_1->setMaxLength(99);
        lineEdit_IDsF3_1->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF3_1->setReadOnly(true);
        lineEdit_IDsF2_4 = new QLineEdit(centralWidget);
        lineEdit_IDsF2_4->setObjectName(QString::fromUtf8("lineEdit_IDsF2_4"));
        lineEdit_IDsF2_4->setGeometry(QRect(450, 180, 31, 20));
        lineEdit_IDsF2_4->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF2_4->setAutoFillBackground(false);
        lineEdit_IDsF2_4->setMaxLength(99);
        lineEdit_IDsF2_4->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF2_4->setReadOnly(true);
        lineEdit_IDsF2_3 = new QLineEdit(centralWidget);
        lineEdit_IDsF2_3->setObjectName(QString::fromUtf8("lineEdit_IDsF2_3"));
        lineEdit_IDsF2_3->setGeometry(QRect(450, 160, 31, 20));
        lineEdit_IDsF2_3->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF2_3->setAutoFillBackground(false);
        lineEdit_IDsF2_3->setMaxLength(99);
        lineEdit_IDsF2_3->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF2_3->setReadOnly(true);
        lineEdit_IDsF2_2 = new QLineEdit(centralWidget);
        lineEdit_IDsF2_2->setObjectName(QString::fromUtf8("lineEdit_IDsF2_2"));
        lineEdit_IDsF2_2->setGeometry(QRect(450, 140, 31, 20));
        lineEdit_IDsF2_2->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF2_2->setAutoFillBackground(false);
        lineEdit_IDsF2_2->setMaxLength(99);
        lineEdit_IDsF2_2->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF2_2->setReadOnly(true);
        lineEdit_IDsF2_1 = new QLineEdit(centralWidget);
        lineEdit_IDsF2_1->setObjectName(QString::fromUtf8("lineEdit_IDsF2_1"));
        lineEdit_IDsF2_1->setGeometry(QRect(450, 120, 31, 20));
        lineEdit_IDsF2_1->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF2_1->setAutoFillBackground(false);
        lineEdit_IDsF2_1->setMaxLength(99);
        lineEdit_IDsF2_1->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF2_1->setReadOnly(true);
        lineEdit_IDsF2_5 = new QLineEdit(centralWidget);
        lineEdit_IDsF2_5->setObjectName(QString::fromUtf8("lineEdit_IDsF2_5"));
        lineEdit_IDsF2_5->setGeometry(QRect(450, 200, 31, 20));
        lineEdit_IDsF2_5->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF2_5->setAutoFillBackground(false);
        lineEdit_IDsF2_5->setMaxLength(99);
        lineEdit_IDsF2_5->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF2_5->setReadOnly(true);
        lineEdit_IDsF1_5 = new QLineEdit(centralWidget);
        lineEdit_IDsF1_5->setObjectName(QString::fromUtf8("lineEdit_IDsF1_5"));
        lineEdit_IDsF1_5->setGeometry(QRect(400, 200, 31, 20));
        lineEdit_IDsF1_5->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF1_5->setAutoFillBackground(false);
        lineEdit_IDsF1_5->setMaxLength(99);
        lineEdit_IDsF1_5->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF1_5->setReadOnly(true);
        lineEdit_IDsF1_3 = new QLineEdit(centralWidget);
        lineEdit_IDsF1_3->setObjectName(QString::fromUtf8("lineEdit_IDsF1_3"));
        lineEdit_IDsF1_3->setGeometry(QRect(400, 160, 31, 20));
        lineEdit_IDsF1_3->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF1_3->setAutoFillBackground(false);
        lineEdit_IDsF1_3->setMaxLength(99);
        lineEdit_IDsF1_3->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF1_3->setReadOnly(true);
        lineEdit_IDsF1_1 = new QLineEdit(centralWidget);
        lineEdit_IDsF1_1->setObjectName(QString::fromUtf8("lineEdit_IDsF1_1"));
        lineEdit_IDsF1_1->setGeometry(QRect(400, 120, 31, 20));
        lineEdit_IDsF1_1->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF1_1->setAutoFillBackground(false);
        lineEdit_IDsF1_1->setMaxLength(99);
        lineEdit_IDsF1_1->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF1_1->setReadOnly(true);
        lineEdit_IDsF1_2 = new QLineEdit(centralWidget);
        lineEdit_IDsF1_2->setObjectName(QString::fromUtf8("lineEdit_IDsF1_2"));
        lineEdit_IDsF1_2->setGeometry(QRect(400, 140, 31, 20));
        lineEdit_IDsF1_2->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF1_2->setAutoFillBackground(false);
        lineEdit_IDsF1_2->setMaxLength(99);
        lineEdit_IDsF1_2->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF1_2->setReadOnly(true);
        lineEdit_IDsF1_4 = new QLineEdit(centralWidget);
        lineEdit_IDsF1_4->setObjectName(QString::fromUtf8("lineEdit_IDsF1_4"));
        lineEdit_IDsF1_4->setGeometry(QRect(400, 180, 31, 20));
        lineEdit_IDsF1_4->setLayoutDirection(Qt::LeftToRight);
        lineEdit_IDsF1_4->setAutoFillBackground(false);
        lineEdit_IDsF1_4->setMaxLength(99);
        lineEdit_IDsF1_4->setAlignment(Qt::AlignCenter);
        lineEdit_IDsF1_4->setReadOnly(true);
        label_prioridade_6 = new QLabel(centralWidget);
        label_prioridade_6->setObjectName(QString::fromUtf8("label_prioridade_6"));
        label_prioridade_6->setGeometry(QRect(410, 100, 16, 20));
        label_prioridade_7 = new QLabel(centralWidget);
        label_prioridade_7->setObjectName(QString::fromUtf8("label_prioridade_7"));
        label_prioridade_7->setGeometry(QRect(460, 100, 16, 20));
        label_prioridade_8 = new QLabel(centralWidget);
        label_prioridade_8->setObjectName(QString::fromUtf8("label_prioridade_8"));
        label_prioridade_8->setGeometry(QRect(510, 100, 21, 20));
        label_prioridade_9 = new QLabel(centralWidget);
        label_prioridade_9->setObjectName(QString::fromUtf8("label_prioridade_9"));
        label_prioridade_9->setGeometry(QRect(350, 120, 41, 20));
        label_prioridade_10 = new QLabel(centralWidget);
        label_prioridade_10->setObjectName(QString::fromUtf8("label_prioridade_10"));
        label_prioridade_10->setGeometry(QRect(360, 200, 31, 20));
        label_prioridade_11 = new QLabel(centralWidget);
        label_prioridade_11->setObjectName(QString::fromUtf8("label_prioridade_11"));
        label_prioridade_11->setGeometry(QRect(310, 50, 71, 20));
        spinBox_Bloquear = new QSpinBox(centralWidget);
        spinBox_Bloquear->setObjectName(QString::fromUtf8("spinBox_Bloquear"));
        spinBox_Bloquear->setGeometry(QRect(110, 140, 42, 21));
        spinBox_Bloquear->setMinimum(1);
        spinBox_Bloquear->setMaximum(99);
        spinBox_Bloquear->setValue(1);
        spinBox_Desbloquear = new QSpinBox(centralWidget);
        spinBox_Desbloquear->setObjectName(QString::fromUtf8("spinBox_Desbloquear"));
        spinBox_Desbloquear->setGeometry(QRect(110, 170, 42, 22));
        spinBox_Desbloquear->setMinimum(1);
        spinBox_Desbloquear->setMaximum(99);
        spinBox_Finalizar = new QSpinBox(centralWidget);
        spinBox_Finalizar->setObjectName(QString::fromUtf8("spinBox_Finalizar"));
        spinBox_Finalizar->setGeometry(QRect(110, 200, 42, 22));
        spinBox_Finalizar->setMinimum(1);
        spinBox_Finalizar->setMaximum(99);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 542, 21));
        menuMENU = new QMenu(menuBar);
        menuMENU->setObjectName(QString::fromUtf8("menuMENU"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuMENU->menuAction());
        menuMENU->addAction(menuSORRISO);
        menuMENU->addAction(menuSAIR);

        retranslateUi(MainWindow);
        QObject::connect(botaoCriar, SIGNAL(clicked()), MainWindow, SLOT(botaocriarclick()));
        QObject::connect(menuSAIR, SIGNAL(activated()), MainWindow, SLOT(close()));
        QObject::connect(botaoBloquear, SIGNAL(clicked()), MainWindow, SLOT(botaobloquearclick()));
        QObject::connect(botaoDesbloquear, SIGNAL(clicked()), MainWindow, SLOT(botaodesbloquearclick()));
        QObject::connect(botaoFinalizar, SIGNAL(clicked()), MainWindow, SLOT(botaoclickhandlerContador()));
        QObject::connect(botaoFinalizar, SIGNAL(clicked()), MainWindow, SLOT(botaofinalizarclick()));
        QObject::connect(menuSORRISO, SIGNAL(activated()), MainWindow, SLOT(sorriso()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Simulador: Escalonador de Processos", 0, QApplication::UnicodeUTF8));
        menuSAIR->setText(QApplication::translate("MainWindow", "Sair", 0, QApplication::UnicodeUTF8));
        actionOutro->setText(QApplication::translate("MainWindow", "Outro", 0, QApplication::UnicodeUTF8));
        menuSORRISO->setText(QApplication::translate("MainWindow", ":)", 0, QApplication::UnicodeUTF8));
        label_criarprocess->setText(QApplication::translate("MainWindow", "CRIAR PROCESSO", 0, QApplication::UnicodeUTF8));
        label_prioridade_2->setText(QApplication::translate("MainWindow", "PRIORIDADE", 0, QApplication::UnicodeUTF8));
        label_prioridade->setText(QApplication::translate("MainWindow", "FATIA DE TEMPO", 0, QApplication::UnicodeUTF8));
        botaoCriar->setText(QApplication::translate("MainWindow", "Criar", 0, QApplication::UnicodeUTF8));
        label_criarprocess_2->setText(QApplication::translate("MainWindow", "OPERADOR DE PROCESSOS", 0, QApplication::UnicodeUTF8));
        label_prioridade_3->setText(QApplication::translate("MainWindow", "ID PROCESSO", 0, QApplication::UnicodeUTF8));
        botaoFinalizar->setText(QApplication::translate("MainWindow", "Finalizar", 0, QApplication::UnicodeUTF8));
        botaoBloquear->setText(QApplication::translate("MainWindow", "Bloquear", 0, QApplication::UnicodeUTF8));
        label_prioridade_4->setText(QApplication::translate("MainWindow", "ID PROCESSO", 0, QApplication::UnicodeUTF8));
        label_prioridade_5->setText(QApplication::translate("MainWindow", "ID PROCESSO", 0, QApplication::UnicodeUTF8));
        botaoDesbloquear->setText(QApplication::translate("MainWindow", "Desbloquear", 0, QApplication::UnicodeUTF8));
        comboBox_Tipo->clear();
        comboBox_Tipo->insertItems(0, QStringList()
         << QApplication::translate("MainWindow", "Tipo", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "CPU-Bound", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("MainWindow", "I/O-Bound", 0, QApplication::UnicodeUTF8)
        );
        lineEdit_IDsF3_5->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF3_5->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        lcdNumber->setToolTip(QApplication::translate("MainWindow", "ID do processo em execu\303\247\303\243o", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        lineEdit_IDsF3_4->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF3_4->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF3_3->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF3_3->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF3_2->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF3_2->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF3_1->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF3_1->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_4->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_4->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_3->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_3->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_2->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_2->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_1->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_1->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_5->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF2_5->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_5->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_5->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_3->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_3->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_1->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_1->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_2->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_2->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_4->setStyleSheet(QApplication::translate("MainWindow", "background: rgb(211, 211, 211);", 0, QApplication::UnicodeUTF8));
        lineEdit_IDsF1_4->setText(QApplication::translate("MainWindow", "N", 0, QApplication::UnicodeUTF8));
        label_prioridade_6->setText(QApplication::translate("MainWindow", "F1", 0, QApplication::UnicodeUTF8));
        label_prioridade_7->setText(QApplication::translate("MainWindow", "F2", 0, QApplication::UnicodeUTF8));
        label_prioridade_8->setText(QApplication::translate("MainWindow", "F3", 0, QApplication::UnicodeUTF8));
        label_prioridade_9->setText(QApplication::translate("MainWindow", "IN\303\215CIO", 0, QApplication::UnicodeUTF8));
        label_prioridade_10->setText(QApplication::translate("MainWindow", " FIM", 0, QApplication::UnicodeUTF8));
        label_prioridade_11->setText(QApplication::translate("MainWindow", " ID PROCESSO", 0, QApplication::UnicodeUTF8));
        menuMENU->setTitle(QApplication::translate("MainWindow", "Menu", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
