#include "mainwindow.h"
#include "ui_mainwindow.h"
/*
* 2� per�odo do curso de Sistemas de Informa��o no Instituto Federal de Alagoas.
* Projeto criado para as disciplinas: Estruturas de Dados / Sistemas Operacionais
*
* Alunos: Felipe Alencar e Mailson Santos
* Professor(a): Cledja Rolim
*
* Escalonador de Processos com filas circulares de prioridade
* Data de In�cio: 21/05/2009
* Data de Entrega: 28/05/2009
*/


/*
* VARI�VEIS GLOBAIS PARA CONTROLE DO SISTEMA:
* 	int		id							ID sequencial para os processos.
* 	int		idsBloqueadasContador		Quantifica quantos processos est�o bloqueados.
* 	int		idsFinalizadasContador		Quantifica quantos processos foram finalizados.
* 	int		idsBloqueadas[]				Armazena os IDs dos processos bloqueados.
* 	int		idsFinalizadas[]			Armazena os IDs dos processos finalizados.
*	int 	fatia						Simula as fatias de uso do clock do processador.
*	int 	a							Processos I/O Bound.
*	Fila	P1, P2, P3					Filas com prioridades 1, 2 e 3.
*/
int id = 0; 
int idsBloqueadasContador = 0;
int idsFinalizadasContador = 0;
int idsBloqueadas[15]; 
int idsFinalizadas[15];
int a = 0; 
int fatia = 0; 
Fila P1, P2, P3; 

void MainWindow::erroid()
{
    QMessageBox erro1;
    erro1.setText("ID NAO ENCONTRADA");
    erro1.setWindowTitle("INSIRA UMA ID QUE CONSTE NA LISTA");
    erro1.exec();
}

void MainWindow::errotipo()
{
    QMessageBox erro1;
    erro1.setText("INSIRA UM TIPO VALIDO");
    erro1.setWindowTitle("PROBLEMA NO TIPO");
    erro1.exec();
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(finalizaprocesso()));
    // Justificativa para termos usado vari�veis globais, os slots n�o suportam (at� onde sabemos) fun��es com par�metros.
    connect(timer, SIGNAL(timeout()), this, SLOT(bloqueiaprocesso())); // fun��o inserida antes para que n�o haja sincronismo.
    // connect(timer, SIGNAL(timeout()), this, SLOT(desbloqueiaprocesso())); // fun��o inserida antes para que n�o haja sincronismo.
    connect(timer, SIGNAL(timeout()), this, SLOT(executaprocesso()));
    timer->start(1000);

    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::valida(int prioridade, int tipo)
{
    if(tipo == 0)
    {
        return false;
    }
    else if(prioridade == 1 && P1.n == 5)
    {
        QMessageBox erro;
        erro.setText("Fila Cheia ");
        erro.setWindowTitle("ERRO");
        erro.exec();
        return false;
    }
    else if(prioridade == 2 && P2.n == 5)
    {
        QMessageBox erro2;
        erro2.setText("Fila Cheia ");
        erro2.setWindowTitle("ERRO");
        erro2.exec();
        return false;
    }
    else if(prioridade == 3 && P3.n == 5)
    {
        QMessageBox erro3;
        erro3.setText("Fila Cheia ");
        erro3.setWindowTitle("ERRO");
        erro3.exec();
        return false;
    }
    else
        return true;
}

void MainWindow::fila_insere(Fila *F, int id, int prioridade, int fatia, int tipo, int bloqueio)
{
   if(F->n == TAM)
   {
      printf("Fila cheia!");
      //getch();
   }
   else
   {
      F->fim = (F->inicio + F->n)%TAM;
      F->P[F->fim].id = id;
      F->P[F->fim].prioridade = prioridade;
      F->P[F->fim].fatia = fatia;
      F->P[F->fim].tipo = tipo;
      if(tipo == 1)
          F->P[F->fim].bloqueio = 0; //troca caso bloqueado
      if(tipo == 2)
          F->P[F->fim].bloqueio = 1; //j� cria bloqueado
      F->P[F->fim].executa = 1; //execu��o
      F->n++;
   }
}

void MainWindow::fila_remove(Fila *F)
{
   //int v;

   if(F->n == 0)
   {
      printf("Fila vazia!");
   }
   else
   {
      F->inicio = (F->inicio + 1)%TAM;
      F->n--;

   }
}

void procurar(Fila P, int a)
{
    int i;
    if(P.P[P.inicio].id == a)
    {
        P.P[P.inicio].fatia = 1;
        return;
    }
}

bool MainWindow::finalizaprocesso()
{
    int p = ui->spinBox_Finalizar->value();
    procurar(P1, 1);
    procurar(P2, p);
    procurar(P3, p);
}

bool MainWindow::desbloqueiaprocesso()
{
    int i = 0;
    while((idsBloqueadas[i] != '\0'))
    {
        if(P1.P[P1.inicio].id == idsBloqueadas[i])
        {
            P1.P[P1.inicio].bloqueio = 0;
            idsBloqueadas[i] = 0;
        }

        if(P2.P[P2.inicio].id == idsBloqueadas[i])
        {
            P2.P[P2.inicio].bloqueio = 0;
            idsBloqueadas[i] = 0;
        }

        if(P3.P[P3.inicio].id == idsBloqueadas[i])
        {
            P3.P[P3.inicio].bloqueio = 0;
            idsBloqueadas[i] = 0;
        }
        i++;
    }
}

bool MainWindow::bloqueiaprocesso()
{
    int i = 0;

    while((idsBloqueadas[i] != '\0'))
    {
        if(P1.P[P1.inicio].id == idsBloqueadas[i])
        {
            P1.P[P1.inicio].bloqueio = 1;
            break;
        }
        else
        {
            P1.P[P1.inicio].bloqueio = 0;
        }

        if(P2.P[P2.inicio].id == idsBloqueadas[i])
        {
            P2.P[P2.inicio].bloqueio = 1;
            break;
        }
        else
        {
            P1.P[P1.inicio].bloqueio = 0;
        }

        if(P3.P[P3.inicio].id == idsBloqueadas[i])
        {
            P3.P[P3.inicio].bloqueio = 1;
            break;
        }
        else
        {
            P1.P[P1.inicio].bloqueio = 0;
        }

        i++;

        if(i > 15)
            break;
    }
}

void MainWindow::executaprocesso()
{
    char c[2];
    int i, j;
    int aux = 0;
    Processo N;
    if(P3.P[P3.inicio].executa == 1) // || executa == 0, depois verifica a impress�o para n�o imprim�-lo na execu��o.
    {
        for(j=0; idsFinalizadas[j] != '\0'; j++)
        {
            if(P3.P[P3.inicio].id == idsFinalizadas[j])
            {
                P3.P[P3.inicio].fatia = 1;
                idsFinalizadas[j] = 0;
            }
        }

        if(P3.P[P3.inicio].tipo == 2 && a >= 0 && a<= 3) //Se for I/O Bound
        {
            P3.P[P3.inicio].bloqueio = 1;
        }

        a++;
        if(P3.P[P3.inicio].tipo == 2 && a >=3 && a<=6)
        {
            P3.P[P3.inicio].bloqueio = 0;
        }
        if(a == 6)
            a = 0;
        else //if(P3.P[P3.inicio].tipo == 2 && a%5 == 0) //Se for I/O Bound
        //{
//            P3.P[P3.inicio].bloqueio = 0;
//        }

        
        if(P3.P[P3.inicio].bloqueio == 1) //Se a vari�vel bloqueio estiver = 1 (bloqueado) n�o imprime no visor de execu��o
        { //Faz a troca normal de processos, guardando o bloqueado numa vari�vel auxiliar e inserindo no final da fila
            ui->lcdNumber->display(0);
            if(P3.n == 1)
            {
                ui->lcdNumber->display(0);
            }
            N = P3.P[P3.inicio];
            fila_remove(&P3);
            fila_insere(&P3, N.id, N.prioridade, N.fatia, N.tipo, N.bloqueio);
        }

        else //se o in�cio da fila n�o estiver bloqueado, escalona normal o processo na execu��o
        {
            ui->lcdNumber->display(P3.P[P3.inicio].id); //imprime no visor
            P3.P[P3.inicio].fatia = P3.P[P3.inicio].fatia - 1; //diminui o tempo de execu��o utilizado pelo processo
            fatia++; //incrementa a fatia de uso do processador (clock)

            if(P3.P[P3.inicio].fatia <= 0 && fatia != 2) //se o tempo de execu��o do processo terminar, e a fatia de uso
            {                                            //do processador for menor que o m�ximo (2), remove-o da fila
                P3.P[P3.inicio].executa = -1;
                fila_remove(&P3);
                //ui->lcdNumber->display(0);
            }

            else if(P3.P[P3.inicio].fatia <= 0 && fatia == 2) //neste caso a fatia de uso do processador foi totalmente utilizada.
            {                                                 //ent�o igualamos a 0 a fatia de uso do processador.
                fatia = 0;
                P3.P[P3.inicio].executa = -1;
                fila_remove(&P3);
                //ui->lcdNumber->display(0);
            }

            else if(P3.P[P3.inicio].fatia > 0 && fatia == 2) //o processo ainda n�o terminou sua execu��o, mas utilizou toda
            {                                                //a fatia de uso do processador
                fatia = 0;
                N = P3.P[P3.inicio]; //uso da vari�vel auxiliar do tipo processo, servindo para inserir o atual no fim da fila.
                fila_remove(&P3); //remove o processo do in�cio
                fila_insere(&P3, N.id, N.prioridade, N.fatia, N.tipo, N.bloqueio); //insere no fim
            }
        }

        //Fun��es de impress�o, cada 'if' est� associado � uma quantidade de processos para ser impressa nos campos dos processos.
        if(P3.n > 0)
        {

            i = 0; //vari�vel auxiliar i para percorrer a fila
            
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 1)
                ui->lineEdit_IDsF3_1->setStyleSheet("background: rgb(255, 0, 0)");
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 0)
                ui->lineEdit_IDsF3_1->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_1->setText(itoa(P3.P[(P3.inicio+i)%TAM].id, c, 10)); //imprime o id do processo no campo.

            
            if((P3.inicio+i)%TAM == P3.fim)
            {
                ui->lineEdit_IDsF3_2->setText("N"); //a quantidade de "Ns" impressos t� relacionada com a quantidade de processos
                ui->lineEdit_IDsF3_3->setText("N"); //alocados na fila.
                ui->lineEdit_IDsF3_4->setText("N");
                ui->lineEdit_IDsF3_5->setText("N");

                return;
            }
            i++;
            //i%P3.n;
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 1)
                ui->lineEdit_IDsF3_2->setStyleSheet("background: rgb(255, 0, 0)");
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 0)
                ui->lineEdit_IDsF3_2->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_2->setText(itoa(P3.P[(P3.inicio+i)%TAM].id, c, 10));
            
            if((P3.inicio+i)%TAM == P3.fim)
            {
                ui->lineEdit_IDsF3_3->setText("N");
                ui->lineEdit_IDsF3_4->setText("N");
                ui->lineEdit_IDsF3_5->setText("N");

                return;
            }

            i++;
            //i%P3.n;
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 1)
                ui->lineEdit_IDsF3_3->setStyleSheet("background: rgb(255, 0, 0)");
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 0)
                ui->lineEdit_IDsF3_3->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_3->setText(itoa(P3.P[(P3.inicio+i)%TAM].id, c, 10));
            if((P3.inicio+i)%TAM == P3.fim)
            {
                ui->lineEdit_IDsF3_4->setText("N");
                ui->lineEdit_IDsF3_5->setText("N");

                return;
            }
            i++;
            //i%P3.n;
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 1)
                ui->lineEdit_IDsF3_4->setStyleSheet("background: rgb(255, 0, 0)");
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 0)
                ui->lineEdit_IDsF3_4->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_4->setText(itoa(P3.P[(P3.inicio+i)%TAM].id, c, 10));
            if((P3.inicio+i)%TAM == P3.fim)
            {
                ui->lineEdit_IDsF3_5->setText("N");

                return;
            }
            i++;
            //i%P3.n;
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 1)
                ui->lineEdit_IDsF3_5->setStyleSheet("background: rgb(255, 0, 0)");
            if(P3.P[(P3.inicio+i)%TAM].bloqueio == 0)
                ui->lineEdit_IDsF3_5->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_5->setText(itoa(P3.P[(P3.inicio+i)%TAM].id, c, 10));
            if((P3.inicio+i)%TAM == P3.fim) return;
        }


        else if(P3.n == 0)
        {
            ui->lineEdit_IDsF3_1->setText("N"); ui->lineEdit_IDsF3_1->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_2->setText("N"); ui->lineEdit_IDsF3_2->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_3->setText("N"); ui->lineEdit_IDsF3_3->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_4->setText("N"); ui->lineEdit_IDsF3_4->setStyleSheet("background: rgb(211, 211, 211)");
            ui->lineEdit_IDsF3_5->setText("N"); ui->lineEdit_IDsF3_5->setStyleSheet("background: rgb(211, 211, 211)");
        }
    }

    if(P3.P[P3.inicio].executa != 1 && P2.P[P2.inicio].executa == 1)
    {
        for(j=0; idsFinalizadas[j] != '\0'; j++)
        {
            if(P2.P[P2.inicio].id == idsFinalizadas[j])
            {
                P2.P[P2.inicio].fatia = 1;
                idsFinalizadas[j] = 0;
            }
        }

        if(P2.P[P2.inicio].tipo == 2 && a >= 0 && a<= 3) //Se for I/O Bound
        {
            P2.P[P2.inicio].bloqueio = 1;
        }

        a++;
        if(P2.P[P2.inicio].tipo == 2 && a >=3 && a<=6)
        {
            P2.P[P2.inicio].bloqueio = 0;
        }
        if(a == 6)
            a = 0;

        if(P2.P[P2.inicio].bloqueio == 1) //Se a vari�vel bloqueio estiver = 1 (bloqueado) n�o imprime no visor de execu��o
        { //Faz a troca normal de processos, guardando o bloqueado numa vari�vel auxiliar e inserindo no final da fila
            ui->lcdNumber->display(0);
            if(P2.n == 1)
            {
                ui->lcdNumber->display(0);
            }
            N = P2.P[P2.inicio];
            fila_remove(&P2);
            fila_insere(&P2, N.id, N.prioridade, N.fatia, N.tipo, N.bloqueio);
        }

        else
        {
            ui->lcdNumber->display(P2.P[P2.inicio].id);
            P2.P[P2.inicio].fatia = P2.P[P2.inicio].fatia - 1;
            fatia++;
            if(P2.P[P2.inicio].fatia <= 0 && fatia != 2)
            {
                P2.P[P2.inicio].executa = -1;
                fila_remove(&P2);
                //ui->lcdNumber->display(0);
            }

            else if(P2.P[P2.inicio].fatia <= 0 && fatia == 2)
            {
                fatia = 0;
                P2.P[P2.inicio].executa = -1;
                fila_remove(&P2);
                //ui->lcdNumber->display(0);
            }

            else if(P2.P[P2.inicio].fatia > 0 && fatia == 2)
            {
                fatia = 0;
                N = P2.P[P2.inicio];
                fila_remove(&P2);
                fila_insere(&P2, N.id, N.prioridade, N.fatia, N.tipo, N.bloqueio);
            }

            if(P2.n > 0)
            {
                i = 0;
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF2_1->setStyleSheet("background: rgb(255, 0, 0)");
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF2_1->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_1->setText(itoa(P2.P[(P2.inicio+i)%TAM].id, c, 10));
                if((P2.inicio+i)%TAM == P2.fim)
                {
                    ui->lineEdit_IDsF2_2->setText("N");
                    ui->lineEdit_IDsF2_3->setText("N");
                    ui->lineEdit_IDsF2_4->setText("N");
                    ui->lineEdit_IDsF2_5->setText("N");

                    return;
                }
                i++;
                //i%P2.n;
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF2_2->setStyleSheet("background: rgb(255, 0, 0)");
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF2_2->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_2->setText(itoa(P2.P[(P2.inicio+i)%TAM].id, c, 10));
                if((P2.inicio+i)%TAM == P2.fim)
                {
                    ui->lineEdit_IDsF2_3->setText("N");
                    ui->lineEdit_IDsF2_4->setText("N");
                    ui->lineEdit_IDsF2_5->setText("N");

                    return;
                }

                i++;
                //i%P2.n;
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF2_3->setStyleSheet("background: rgb(255, 0, 0)");
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF2_3->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_3->setText(itoa(P2.P[(P2.inicio+i)%TAM].id, c, 10));
                if((P2.inicio+i)%TAM == P2.fim)
                {
                    ui->lineEdit_IDsF2_4->setText("N");
                    ui->lineEdit_IDsF2_5->setText("N");

                    return;
                }
                i++;
                //i%P2.n;
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF2_4->setStyleSheet("background: rgb(255, 0, 0)");
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF2_4->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_4->setText(itoa(P2.P[(P2.inicio+i)%TAM].id, c, 10));
                if((P2.inicio+i)%TAM == P2.fim)
                {
                    ui->lineEdit_IDsF2_5->setText("N");

                    return;
                }
                i++;
                //i%P2.n;
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF2_5->setStyleSheet("background: rgb(255, 0, 0)");
                if(P2.P[(P2.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF2_5->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_5->setText(itoa(P2.P[(P2.inicio+i)%TAM].id, c, 10));
                if((P2.inicio+i)%TAM == P2.fim) return;
            }

            else if(P2.n == 0)
            {
                ui->lineEdit_IDsF2_1->setText("N"); ui->lineEdit_IDsF2_1->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_2->setText("N"); ui->lineEdit_IDsF2_2->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_3->setText("N"); ui->lineEdit_IDsF2_3->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_4->setText("N"); ui->lineEdit_IDsF2_4->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF2_5->setText("N"); ui->lineEdit_IDsF2_5->setStyleSheet("background: rgb(211, 211, 211)");
            }
        }
    }

    if(P3.P[P3.inicio].executa != 1 && P2.P[P3.inicio].executa != 1 && P1.P[P1.inicio].executa == 1)
    {
        //Faz a finaliza�ao dos processos a serem finalizados
        for(j=0; idsFinalizadas[j] != '\0'; j++)
        {
            if(P1.P[P1.inicio].id == idsFinalizadas[j])
            {
                P1.P[P1.inicio].fatia = 1;
                idsFinalizadas[j] = 0;
            }
        }
        if(P1.P[P1.inicio].tipo == 2 && a >= 0 && a<= 3) //Se for I/O Bound
        {
            P1.P[P1.inicio].bloqueio = 1;
        }

        a++;
        if(P1.P[P1.inicio].tipo == 2 && a >=3 && a<=6)
        {
            P1.P[P1.inicio].bloqueio = 0;
        }
        if(a == 6)
            a = 0;

        if(P1.P[P1.inicio].bloqueio == 1) //Se a vari�vel bloqueio estiver = 1 (bloqueado) n�o imprime no visor de execu��o
        { //Faz a troca normal de processos, guardando o bloqueado numa vari�vel auxiliar e inserindo no final da fila
            ui->lcdNumber->display(0);
            if(P1.n == 1)
            {
                ui->lcdNumber->display(0);
            }


            N = P1.P[P1.inicio];
            fila_remove(&P1);
            fila_insere(&P1, N.id, N.prioridade, N.fatia, N.tipo, N.bloqueio);
        }

        else
        {
            ui->lcdNumber->display(P1.P[P1.inicio].id);
            P1.P[P1.inicio].fatia = P1.P[P1.inicio].fatia - 1;
            fatia++;
            if(P1.P[P1.inicio].fatia <= 0 && fatia != 2)
            {
                P1.P[P1.inicio].executa = -1;
                fila_remove(&P1);
                //ui->lcdNumber->display(0);
            }

            else if(P1.P[P1.inicio].fatia <= 0 && fatia == 2)
            {
                fatia = 0;
                P1.P[P1.inicio].executa = -1;
                fila_remove(&P1);
                //ui->lcdNumber->display(0);
            }

            else if(P1.P[P1.inicio].fatia > 0 && fatia == 2)
            {
                fatia = 0;
                N = P1.P[P1.inicio];
                fila_remove(&P1);
                fila_insere(&P1, N.id, N.prioridade, N.fatia, N.tipo, N.bloqueio);
            }

            if(P1.n > 0)
            {
                i = 0;
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF1_1->setStyleSheet("background: rgb(255, 0, 0)");
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF1_1->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_1->setText(itoa(P1.P[(P1.inicio+i)%TAM].id, c, 10));

                if((P1.inicio+i)%TAM == P1.fim)
                {
                    ui->lineEdit_IDsF1_2->setText("N");
                    ui->lineEdit_IDsF1_3->setText("N");
                    ui->lineEdit_IDsF1_4->setText("N");
                    ui->lineEdit_IDsF1_5->setText("N");

                    return;
                }
                i++;
                //i%P1.n;
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF1_2->setStyleSheet("background: rgb(255, 0, 0)");
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF1_2->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_2->setText(itoa(P1.P[(P1.inicio+i)%TAM].id, c, 10));

                if((P1.inicio+i)%TAM == P1.fim)
                {
                    ui->lineEdit_IDsF1_3->setText("N");
                    ui->lineEdit_IDsF1_4->setText("N");
                    ui->lineEdit_IDsF1_5->setText("N");

                    return;
                }

                i++;
                //i%P1.n;
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF1_3->setStyleSheet("background: rgb(255, 0, 0)");
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF1_3->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_3->setText(itoa(P1.P[(P1.inicio+i)%TAM].id, c, 10));

                if((P1.inicio+i)%TAM == P1.fim)
                {
                    ui->lineEdit_IDsF1_4->setText("N");
                    ui->lineEdit_IDsF1_5->setText("N");

                    return;
                }
                i++;
                //i%P1.n;
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF1_4->setStyleSheet("background: rgb(255, 0, 0)");
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF1_4->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_4->setText(itoa(P1.P[(P1.inicio+i)%TAM].id, c, 10));

                if((P1.inicio+i)%TAM == P1.fim)
                {
                    ui->lineEdit_IDsF1_5->setText("N");

                    return;
                }
                i++;
                //i%P1.n;
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 1)
                    ui->lineEdit_IDsF1_5->setStyleSheet("background: rgb(255, 0, 0)");
                if(P1.P[(P1.inicio+i)%TAM].bloqueio == 0)
                    ui->lineEdit_IDsF1_5->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_5->setText(itoa(P1.P[(P1.inicio+i)%TAM].id, c, 10));

                if((P1.inicio+i)%TAM == P1.fim) return;
            }


            else if(P1.n == 0)
            {
                ui->lineEdit_IDsF1_1->setText("N"); ui->lineEdit_IDsF1_1->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_2->setText("N"); ui->lineEdit_IDsF1_2->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_3->setText("N"); ui->lineEdit_IDsF1_3->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_4->setText("N"); ui->lineEdit_IDsF1_4->setStyleSheet("background: rgb(211, 211, 211)");
                ui->lineEdit_IDsF1_5->setText("N"); ui->lineEdit_IDsF1_5->setStyleSheet("background: rgb(211, 211, 211)");
            }
        }
    }

    if(P3.P[P3.inicio].executa != 1 && P2.P[P3.inicio].executa != 1 && P1.P[P1.inicio].executa != 1)
        ui->lcdNumber->display(0);
}

void MainWindow::botaocriarclick() //Slot que recebe o sinal "click()" do bot�o criar na janela principal, a fun�ao ta definida na classe MainWindow
{
    //faz a verifica��o no momento da cria��o do processo

    if(valida(ui->spinBox_Prioridade->value(), ui->comboBox_Tipo->currentIndex()) == true) //Se o tipo selecionado for diferente de "Tipo" que � igual a 0
    {
        id++; //uso da vari�vel contadora global para defini��o das ids dos processos
        if(ui->spinBox_Prioridade->value() == 1) //verifica em que fila o processo ser� inserido
            fila_insere(&P1, id, ui->spinBox_Prioridade->value(), ui->spinBox_Tempo->value(), ui->comboBox_Tipo->currentIndex(), 0); //Verifica que o n� processo foi inserido com sucesso

        if(ui->spinBox_Prioridade->value() == 2)
            fila_insere(&P2, id, ui->spinBox_Prioridade->value(), ui->spinBox_Tempo->value(), ui->comboBox_Tipo->currentIndex(), 0); //Verifica que o n� processo foi inserido com sucesso

        if(ui->spinBox_Prioridade->value() == 3)
            fila_insere(&P3, id, ui->spinBox_Prioridade->value(), ui->spinBox_Tempo->value(), ui->comboBox_Tipo->currentIndex(), 0); //Verifica que o n� processo foi inserido com sucesso
    }

    if(ui->comboBox_Tipo->currentIndex() == 0)
    {
        errotipo();
    }

}

void MainWindow::botaobloquearclick()
{
    int i = 0;
    while((ui->spinBox_Bloquear->value() != P1.P[(P1.inicio+i)%TAM].id) && (ui->spinBox_Bloquear->value() != P2.P[(P2.inicio+i)%TAM].id) && (ui->spinBox_Bloquear->value() != P3.P[(P3.inicio+i)%TAM].id))
    {
        if((P1.P[(P1.inicio+i)%TAM].id == P1.P[P1.fim].id) && (P2.P[(P2.inicio+i)%TAM].id == P2.P[P2.fim].id) && (P3.P[(P3.inicio+i)%TAM].id == P3.P[P3.fim].id))
        {
            bloqueiaprocesso();

        }
        if(i==15)
            break;

        i++;
    }
    if((ui->spinBox_Bloquear->value() == P1.P[(P1.inicio+i)%TAM].id) || (ui->spinBox_Bloquear->value() == P2.P[(P2.inicio+i)%TAM].id) || (ui->spinBox_Bloquear->value() == P3.P[(P3.inicio+i)%TAM].id))
        idsBloqueadas[idsBloqueadasContador] = ui->spinBox_Bloquear->value();
    else
    {
        erroid();
    }


    //idsBloqueadasContador++;
}

void MainWindow::botaodesbloquearclick()
{
    int i = 0;
    while((ui->spinBox_Desbloquear->value() != P1.P[(P1.inicio+i)%TAM].id) && (ui->spinBox_Desbloquear->value() != P2.P[(P2.inicio+i)%TAM].id) && (ui->spinBox_Desbloquear->value() != P3.P[(P3.inicio+i)%TAM].id))
    {
        if((P1.P[(P1.inicio+i)%TAM].id == P1.P[P1.fim].id) && (P2.P[(P2.inicio+i)%TAM].id == P2.P[P2.fim].id) && (P3.P[(P3.inicio+i)%TAM].id == P3.P[P3.fim].id))
            break;
        if(i==30)
            return;
        i++;
    }
    if((ui->spinBox_Desbloquear->value() == P1.P[(P1.inicio+i)%TAM].id) || (ui->spinBox_Desbloquear->value() == P2.P[(P2.inicio+i)%TAM].id) || (ui->spinBox_Desbloquear->value() == P3.P[(P3.inicio+i)%TAM].id))
    {
        desbloqueiaprocesso();
    }
    else
    {
        erroid();
    }
}

void MainWindow::botaofinalizarclick()
{
    int i = 0;
    while((ui->spinBox_Finalizar->value() != P1.P[(P1.inicio+i)%TAM].id) && (ui->spinBox_Finalizar->value() != P2.P[(P2.inicio+i)%TAM].id) && (ui->spinBox_Finalizar->value() != P3.P[(P3.inicio+i)%TAM].id))
    {
        if((P1.P[(P1.inicio+i)%TAM].id == P1.P[P1.fim].id) && (P2.P[(P2.inicio+i)%TAM].id == P2.P[P2.fim].id) && (P3.P[(P3.inicio+i)%TAM].id == P3.P[P3.fim].id))
        {
        }

        if(i==15)
            break;

        i++;
    }

    if((ui->spinBox_Finalizar->value() == P1.P[(P1.inicio+i)%TAM].id) || (ui->spinBox_Finalizar->value() == P2.P[(P2.inicio+i)%TAM].id) || (ui->spinBox_Finalizar->value() == P3.P[(P3.inicio+i)%TAM].id))
        idsFinalizadas[idsFinalizadasContador] = ui->spinBox_Finalizar->value();

    else
    {
        erroid();
    }
    //idsBloqueadasContador++;
}

void MainWindow::sorriso()
{
    QMessageBox texto;
    texto.setWindowTitle("Escalonador de Processos - Vers�o 1.0++");
    texto.setText("Projeto ESTDxSOPE - 2009.1\n\n Desenvolvido por: Felipe Alencar (felipealencarlopes@gmail.com)\n\t    Mailson Melo (maia_santos@hotmail.com)\n\n Tipo de escalonamento: Circular com prioridades \n");
    texto.exec();
}
