#include <QtGui/QApplication>
#include "mainwindow.h"
/*
* 2� per�odo do curso de Sistemas de Informa��o no Instituto Federal de Alagoas.
* Projeto criado para as disciplinas: Estruturas de Dados / Sistemas Operacionais
*
* Alunos: Felipe Alencar e Mailson Santos
* Professor(a): Cledja Rolim
*
* Escalonador de Processos com filas circulares de prioridade
* Data de In�cio: 21/05/2009
* Data de Entrega: 28/05/2009
*/

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show(); //Exibe a janela principal e seus bot�es

    return a.exec();
}
