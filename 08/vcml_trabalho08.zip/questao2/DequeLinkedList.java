package questao2;

import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DequeLinkedList {

	private Lock lock = new ReentrantLock();
	private LinkedList<String> list = new LinkedList<String>();

	public String pop_left() {
		String elem = null;
		this.lock.lock();
		elem = this.list.pollFirst();
		this.lock.unlock();
		return elem;
	}

	public String pop_right() {
		String elem = null;
		this.lock.lock();
		elem = this.list.pollLast();
		this.lock.unlock();
		return elem;
	}

	public void push_left(String e) {
		this.lock.lock();
		this.list.addFirst(e);
		this.lock.unlock();
	}
	
	public void push_right(String e) {
		this.lock.lock();
		this.list.addLast(e);
		this.lock.unlock();
	}
	
	public LinkedList<String> get_list(){		
		return this.list;
	}	
	
}
