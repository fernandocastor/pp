package questao2;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DequeHash {

	private List<DequeLinkedList> deqList = new ArrayList<DequeLinkedList>(HashSize);
	static int HashSize = 4;
	private Lock llock = new ReentrantLock();
	private Lock rlock = new ReentrantLock();
	private int lidx = 0;
	private int ridx = 1;

	public DequeHash() {
		for (int i = 0; i < HashSize; i++)
		{
			deqList.add(i, new DequeLinkedList());
		}
	}

	public int moveLeft(int idx) {
		if(idx-1 < 0){
			return HashSize -1;
		}
		else {
			return (idx - 1);
		}
	}

	public int moveRight(int idx) {
		return (idx + 1)%HashSize;
	}

	public void pop_left() {
		this.llock.lock();
		int i = this.moveRight(lidx);
		Object elem = this.deqList.get(i).pop_left();
		if (elem != null)
		{
			lidx = i;
		}
		this.llock.unlock();
	}

	public void pop_right() {
		this.rlock.lock();
		int i = this.moveLeft(ridx);
		Object elem = this.deqList.get(i).pop_right();
		if (elem != null)
		{
			ridx = i;
		}
		this.rlock.unlock();
	}
	
	public void push_left(String str) {
		this.llock.lock();
		int i = lidx;
		this.deqList.get(i).push_left(str);
		lidx = this.moveLeft(lidx);
		this.llock.unlock();
	}
	
	public void push_right(String str) {
		this.rlock.lock();
		int i = ridx;
		this.deqList.get(i).push_right(str);
		ridx = this.moveRight(ridx);
		this.rlock.unlock();
	}
	
	public void Print(){				
		String strPrint = "[";
		for (int i = 0; i < deqList.size(); i++) {
			strPrint  = strPrint + "{" + i + ":";
			int j = 0; 
			for (String elemTmp : deqList.get(i).get_list()) {				
				if(j == 0){
					strPrint = strPrint + elemTmp;
				}
				else {
					strPrint = strPrint + "-" + elemTmp; 
				}
				j++;
			}
			strPrint = strPrint + "}";
		}
		strPrint = strPrint + "]";
		System.out.println(strPrint);
	}
	
}
