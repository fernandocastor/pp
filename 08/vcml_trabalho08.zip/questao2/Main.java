package questao2;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		DequeHash pDeq = new DequeHash();
		List<DequeHashThread> threads = new ArrayList<DequeHashThread>();
		DequeHashThread t1 = new DequeHashThread(1, pDeq);
		DequeHashThread t2 = new DequeHashThread(2, pDeq);
		threads.add(t1);
		threads.add(t2);

		for (DequeHashThread deque : threads)
		{
			deque.start();
		}

		try
		{
			t1.join();
			t2.join();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}

		

	}
	
}
