package questao2;

public class DequeHashThread extends Thread {

	private DequeHash deque;
	private int Id = 0;

	public DequeHashThread(int id, DequeHash d) {
		this.Id = id;
		this.deque = d;
	}

	@Override
	public void run() {

		if (this.Id == 1)
		{
			this.deque.push_left("a");
			this.deque.Print();
			this.deque.push_left("b");
			this.deque.Print();
			this.deque.push_left("c");
			this.deque.Print();
			this.deque.push_right("d");
			this.deque.Print();
			this.deque.push_right("e");
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.push_left("f");
			this.deque.Print();
			this.deque.push_left("g");
			this.deque.Print();
		} 
		else if (this.Id == 2)
		{
			this.deque.push_left("x");
			this.deque.Print();
			this.deque.push_left("y");
			this.deque.Print();
			this.deque.push_right("z");
			this.deque.Print();
			this.deque.push_right("w");
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.push_right("t");
			this.deque.Print();
			this.deque.push_left("r");
			this.deque.Print();
		}
	}	

}
