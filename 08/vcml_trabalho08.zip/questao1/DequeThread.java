package questao1;

public class DequeThread extends Thread {

	private Deque deque = null;
	private int Id;	

	public DequeThread(Deque d, int id) {		
		this.deque = d;
		this.Id = id;		
	}
	
	@Override
	public void run() {
 
		if (this.Id == 1)
		{
			this.deque.push_left("a");
			this.deque.Print();
			this.deque.push_left("b");
			this.deque.Print();
			this.deque.push_left("c");
			this.deque.Print();
			this.deque.push_right("d");
			this.deque.Print();
			this.deque.push_right("e");
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.push_left("aa");
			this.deque.Print();
			this.deque.push_left("bb");
			this.deque.Print();
		} 
		else if (this.Id == 2)
		{
			this.deque.push_left("x");
			this.deque.Print();
			this.deque.push_left("y");
			this.deque.Print();
			this.deque.push_right("z");
			this.deque.Print();
			this.deque.push_right("w");
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.pop_left();
			this.deque.Print();
			this.deque.pop_right();
			this.deque.Print();
			this.deque.push_right("ww");
			this.deque.Print();
			this.deque.push_left("yy");
			this.deque.Print();
		}
		
	}

	
}
