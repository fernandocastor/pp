package questao1;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		List<DequeThread> threads = new ArrayList<DequeThread>();

		Deque d = new Deque();
		DequeThread t1 = new DequeThread(d, 1);
		DequeThread t2 = new DequeThread(d, 2);
		threads.add(t1);
		threads.add(t2);

		for (DequeThread deque : threads)
		{
			deque.start();
		}
		try
		{
			t1.join();
			t2.join();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}			

	}

}
