package questao1;

public enum EnumDequeOperation 
{	
	push_right
	, push_left 
	, pop_right
	, pop_left
}
