import java.util.LinkedList;
import java.util.List;


public class Principal implements Runnable{
	final static int NUMBER = 100;
	final static int NUMBER_OF_THREADS = 2;
	
	//private Deq<Integer> myDeq = new Deq<Integer>();
	private Deq<Integer> myDeq = new Deq<Integer>();

	public static void main(String[] args) throws Exception {
		
		Principal p = new Principal();
		List<Thread> threads = new LinkedList<Thread>();
		
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {			
			threads.add(new Thread(p));
			threads.get(i).start();
		}
		
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {			
			threads.get(i).join();
		}
		
		
		try{
			System.out.println(p.myDeq.getDeq());
		} catch (NullPointerException n){
			System.out.println(n);
		}
		
	}

	@Override
	public void run() {
		for (int i = 0; i < 100; i++) {
			int x = (int) (Math.random() * NUMBER);
			if(x%4==0){
				myDeq.pushLeft(x);
			} else if(x%4==1){
				myDeq.pushRight(x);
			} else if(x%4==2){
				myDeq.popLeft();				
			} else {
				myDeq.popRight();
			}			
		}
		
	}

}
