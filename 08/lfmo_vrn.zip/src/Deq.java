import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Deq<T> {

	private LinkedList<T> deq;
	private final Lock rightLock = new ReentrantLock();
	private final Lock leftLock = new ReentrantLock();

	public Deq() {
		this.deq = new LinkedList<T>();
	}

	public void pushRight(T e) {
		rightLock.lock();
		try{
			deq.addLast(e);
			//System.out.println(Thread.currentThread().getName() +  " Add Right:" + getDeq());
		} finally {
			rightLock.unlock();
		}			
	}

	public void pushLeft(T e) {
		leftLock.lock();
		try{
			deq.addFirst(e);
			//System.out.println(Thread.currentThread().getName() +  " Add Left:" + getDeq());
		} finally {
			leftLock.unlock();
		}
		
	}

	public T popRight() {
		rightLock.lock();
		try{
			//System.out.println(Thread.currentThread().getName() +  " Remove Right:" + getDeq());
			return deq.pollLast();
		} finally {
			rightLock.unlock();
		}
	}

	public T popLeft() {
		leftLock.lock();
		try{
			//System.out.println(Thread.currentThread().getName() +  " Remove Left:" + getDeq());
			return deq.pollFirst(); 
		} finally {
			leftLock.unlock();
		}
	}

	public LinkedList<T> getDeq() {
		return deq;
	}
	
	@Override
	public String toString() {
		String c = "[";
		for (T t : deq) {
			c += t + "->";
		}
		return c+"]";
	}

}
