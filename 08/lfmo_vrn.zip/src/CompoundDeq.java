import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class CompoundDeq<T> {
	private LinkedList<T> rightDeq;
	private LinkedList<T> leftDeq;
	private final Lock rightLock = new ReentrantLock();
	private final Lock leftLock = new ReentrantLock();

	public CompoundDeq() {
		this.rightDeq = new LinkedList<T>();
		this.leftDeq = new LinkedList<T>();
	}

	public void pushRight(T e) {
		rightLock.lock();
		try{
			rightDeq.addLast(e);
			//System.out.println(Thread.currentThread().getName() +  " Add Right:" + toString());
		} finally {
			rightLock.unlock();
		}			
	}

	public void pushLeft(T e) {
		leftLock.lock();
		try{
			leftDeq.addFirst(e);
			//System.out.println(Thread.currentThread().getName() +  " Add Left:" + toString());
		} finally {
			leftLock.unlock();
		}
	}

	public T popRight() {
		T elem;
		rightLock.lock();
		try{
			elem = rightDeq.pollLast();
			if(elem == null){
				try{
					rightLock.unlock();
					leftLock.lock();
					rightLock.lock();
					elem = leftDeq.pollLast();
					//TODO mover os elementos da Deq esquerda para a Deq direita
				} finally{
					leftLock.unlock();
				}
			}
		} finally {
			rightLock.unlock();
		}
		//System.out.println(Thread.currentThread().getName() +  " Remove Right:" + toString());
		return elem;
	}

	public T popLeft() {
		T elem;
		leftLock.lock();		
		try{			
			elem = leftDeq.pollFirst(); //Tenta remover da Deq esquerda...			
			if(elem == null){ //..se ela tiver vazia. Tenta remover da Deq direita.
				try{
					rightLock.lock();
					elem = rightDeq.pollFirst();
					//TODO mover os elementos da Deq direita para a Deq esquerda
				}finally{
					rightLock.unlock();
				}
			}
		} finally {			
			leftLock.unlock();			
		}
		//System.out.println(Thread.currentThread().getName() +  " Remove Left:" + toString());
		return elem;
	}
	
	@Override
	public String toString() {
		String c = "[";
		for (T t : leftDeq) {
			c += t + ",";
		}
		for (T t : rightDeq) {
			c += t + ",";
		}
		return c+"]";
	}

	public String getDeq() {
		return toString();
	}
}
