package collection;

import java.util.Iterator;

public interface DequeCastorInterface<E> {

	public abstract void pushLeft(E e);

	public abstract E popLeft();

	public abstract void pushRigth(E e);

	public abstract E popRigth();

}