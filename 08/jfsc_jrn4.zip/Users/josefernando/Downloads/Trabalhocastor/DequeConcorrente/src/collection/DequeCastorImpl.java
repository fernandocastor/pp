package collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class DequeCastorImpl<E> implements Iterable<E>, DequeCastorInterface<E> {

	
	private ReadWriteLock lockLeft;
	private ReadWriteLock lockRight;
	private LinkedList<E> list;

	public DequeCastorImpl() {
		list = new LinkedList<E>();
		lockLeft = new ReentrantReadWriteLock();
		lockRight = new ReentrantReadWriteLock();
	}

	/* (non-Javadoc)
	 * @see collection.DequeCastorInterface#pushLeft(E)
	 */
	@Override
	public void pushLeft(E e) {
		lockLeft.writeLock().lock();
		try{
			list.addFirst(e);
		}finally{
			lockLeft.writeLock().unlock();
		}
	}

	/* (non-Javadoc)
	 * @see collection.DequeCastorInterface#popLeft()
	 */
	@Override
	public E popLeft() {
		lockLeft.writeLock().lock();
		try{
			return list.removeFirst();
		}finally{
			lockLeft.writeLock().unlock();
		}
	}

	/* (non-Javadoc)
	 * @see collection.DequeCastorInterface#pushRigth(E)
	 */
	@Override
	public void pushRigth(E e) {
		lockRight.writeLock().lock();
		try{
			list.addLast(e);
		}finally{
			lockRight.writeLock().unlock();
		}
	}

	/* (non-Javadoc)
	 * @see collection.DequeCastorInterface#popRigth()
	 */
	@Override
	public E popRigth() {
		lockRight.writeLock().lock();
		try{
			return list.removeLast();
		}finally{
			lockRight.writeLock().unlock();
		}
	}
	
	/* (non-Javadoc)
	 * @see collection.DequeCastorInterface#iterator()
	 */
	@Override
	public Iterator<E> iterator() {
		
		LinkedList<E> result = new LinkedList<E>();
		lockLeft.readLock().lock();
		lockRight.readLock().lock();
		try{
			result.addAll(list);
			return result.iterator();
		}finally{
			lockLeft.readLock().unlock();
			lockRight.readLock().unlock();
		}
	}
}
