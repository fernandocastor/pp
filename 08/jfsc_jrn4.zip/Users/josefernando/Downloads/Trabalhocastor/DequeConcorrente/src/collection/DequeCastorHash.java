package collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DequeCastorHash<E> implements DequeCastorInterface<E> {
	
	private Lock lockLeft;
	private int indexLeft;
	private Lock lockRight;
	private int indexRight;
	
	private Lock[] bucketsLock;
	private List<LinkedList<E>> buckets;

	public DequeCastorHash() {
		indexLeft = -3;
		indexRight = 1;
		lockLeft = new ReentrantLock();
		lockRight = new ReentrantLock();
		buckets = new ArrayList<LinkedList<E>>();
		buckets.add(new LinkedList<E>());
		buckets.add(new LinkedList<E>());
		buckets.add(new LinkedList<E>());
		buckets.add(new LinkedList<E>());
		
		bucketsLock = new Lock[]{new ReentrantLock(),new ReentrantLock(),new ReentrantLock(),new ReentrantLock()};
	}
	
	@Override
	public void pushLeft(E e) {
		lockLeft.lock();
		int index = 3 + (indexLeft%4);
		bucketsLock[index].lock();
		LinkedList<E> bucket = buckets.get(index);
		indexLeft -= 1;
		bucket.addFirst(e);
		bucketsLock[index].unlock();
		lockLeft.unlock();
		
	}

	@Override
	public E popLeft() {
		lockLeft.lock();
		int index = indexLeft+1;
		index = 3+(index%4);
		bucketsLock[index].lock();
		LinkedList<E> bucket = buckets.get(index);
		E e = bucket.removeFirst();
		indexLeft += 1;
		bucketsLock[index].unlock();
		lockLeft.unlock();
		return e;
	}

	@Override
	public void pushRigth(E e) {
		lockRight.lock();
		int index = (indexRight%4);
		
		bucketsLock[index].lock();
		LinkedList<E> bucket = buckets.get(index);
		indexRight +=1;
		bucket.addLast(e);
		bucketsLock[index].unlock();
		lockRight.unlock();
		
	}

	@Override
	public E popRigth() {
		lockRight.lock();
		int index = indexRight - 1;
		index = (index%4);
		bucketsLock[index].lock();
		LinkedList<E> bucket = buckets.get(index);
		E e = bucket.removeLast();
		bucketsLock[index].unlock();
		indexRight -=1;
		lockRight.unlock();
		return e;
	}

	@Override
	public String toString() {
		int index = 0;
		System.out.println("indexLeft: "+indexLeft);	
		System.out.println("indexRight: "+indexRight);	
		for (LinkedList<E> linkedList : buckets) {
			System.out.println("Bucket - "+index+ " ==> "+linkedList);
			index++;
		}
		return super.toString();
	}
	
	public static void main(String[] args) {
		DequeCastorInterface<String> deque = new DequeCastorHash<String>();
		try{
			voidTestRight(deque);
		}catch(Exception e ){
			e.printStackTrace();
		}
		
		try{
			voidTestLeft(deque);
		}catch(Exception e ){
			e.printStackTrace();
		}
		int left = 0;
		int right = 0;
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		
		System.out.println("popRigth");
		deque.popRigth();
		System.out.println(deque);
		System.out.println("popLeft");
		deque.popLeft();
		System.out.println(deque);
		System.out.println("popRigth");
		deque.popRigth();
		System.out.println(deque);
		System.out.println("popLeft");
		deque.popLeft();
		System.out.println(deque);
		System.out.println("popRigth");
		deque.popRigth();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		System.out.println("popRigth");
		deque.popRigth();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		
//		System.out.println("ADICIONAR");
//		for (int i = 0; i > -15; i--) {
//				System.out.println("Index: "+i+", Bucket: "+ ((i%4)+3));
//			
//		}
////		
//		System.out.println("REMOVER");
//		
//		for (int i = -14; i < 0; i++) {
//			System.out.println(3+(i%4));
//			
//		}
	}
	
	public static void voidTestRight(DequeCastorInterface<String> deque){
		int right = 0;
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		deque.pushRigth((right++)+"R");
		System.out.println(deque);
		
		System.out.println();
		System.out.println("_________________________________");
		System.out.println("REMOVENDO");
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
		deque.popRigth();
		System.out.println(deque);
	}
	
	
	public static void voidTestLeft(DequeCastorInterface<String> deque){
		int left = 0;
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
		deque.pushLeft((left++)+"L");
		System.out.println(deque);
//		
		System.out.println();
		System.out.println("_________________________________");
		System.out.println("REMOVENDO");
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		deque.popLeft();
		System.out.println(deque);
		
	}
	
}
