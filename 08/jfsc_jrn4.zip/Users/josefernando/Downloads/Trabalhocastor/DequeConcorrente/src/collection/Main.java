package collection;

import java.util.HashSet;
import java.util.Set;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		
		Thread.sleep(5000l);
		
		DequeCastorInterface<String> deque = new DequeCastorHash<String>();
		
		Set<Thread> threads = new HashSet<Thread>();
		
		for (int i = 0; i < 2; i++) {
			String op = i%2 == 0 ? "POP" : "PUSH";
			for (int j = 0; j < 2; j++) {
				String hand = j%2 == 0 ? "L" : "R";
				new Worker(deque, 10000000, op, hand).start();
			}
		}
		boolean hasThreadsRunning = true;
		while(hasThreadsRunning){
			try {
				Thread.sleep(5000l);
				hasThreadsRunning = false;
				for (Thread thread : threads) {
					hasThreadsRunning = thread.isAlive();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}

class Worker extends Thread{

	private DequeCastorInterface<String> deque;
	private int attemps;
	private String op;
	private String hand;
	
	public Worker(DequeCastorInterface<String> deque, int attemps, String op,String hand) {
		this.deque = deque;
		this.attemps = attemps;
		this.op = op;
		this.hand = hand;
	}
	
	@Override
	public void run() {
		
		for (int i = 0; i < attemps; i++) {
			if(op.equals("PUSH") && hand.equals("L")){
				deque.pushLeft(new String ("SS"));
			}else if(op.equals("PUSH") && hand.equals("R")){
				deque.pushRigth(new String ("SS"));
			}else if(op.equals("POP") && hand.equals("L")){
				try{
					deque.popLeft();
				}catch (Exception e) {
					System.out.println(this.getName()+" ==> "+e.getClass());
				}
			}else if(op.equals("POP") && hand.equals("R")){
				try{
					deque.popRigth();
				}catch (Exception e) {
					System.out.println(this.getName()+" ==> "+e.getClass());
				}
			}
		}
		
	}
	
}
