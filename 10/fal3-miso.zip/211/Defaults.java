package q211;

public enum Defaults {
	MANAGER;

	public ContentionManager newInstance() {
		// TODO Auto-generated method stub
		return null;
	}

}
