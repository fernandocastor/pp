package q211;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import javax.management.monitor.Monitor;

public class Transaction {
	public enum Status {ABORTED, ACTIVE, COMMITTED}
	private static final int TIMEOUT = 2000;
	public AtomicBoolean waiting;
	public AtomicInteger priority;
	public static Transaction COMMITTED = new Transaction(Status.COMMITTED);
	private final AtomicReference<Status> status;
	static ThreadLocal<Transaction> local = new ThreadLocal<Transaction>() {
		protected Transaction initialValue() {
			return new Transaction(Status.COMMITTED);
		}
	};
	public Monitor monitor;
	
	
	public Transaction() {
		this.status = new AtomicReference<Status>(Status.ACTIVE);
		this.priority = new AtomicInteger(0);
	}
	
	private Transaction(Transaction.Status myStatus) {
		status = new AtomicReference<Status>(myStatus);
	}
	
	public Status getStatus() {
		return status.get();
	}
	
	public boolean commit() {
		return status.compareAndSet(Status.ACTIVE, Status.COMMITTED);
	}
	
	public boolean abort() {
		return status.compareAndSet(Status.ACTIVE, Status.ABORTED);
	}
	
	public boolean setStatusToWaiting() {
		return this.waiting.compareAndSet(false, true);
	}
	
	public boolean setStatusToNotWaiting() {
		return this.waiting.compareAndSet(true, false);
	}
	
	public static Transaction getLocal() {
		return local.get();
	}
	
	public static void setLocal(Transaction transaction) {
		local.set(transaction);
	}
	
	// Suspende uma transa��o B at� que a transa��o A entre e deixe o estado ativo.
	public void blockWhileActiveAndNotWaiting() 
	{
		synchronized (this) 
		{
			while (this.status.get() == Status.ACTIVE && this.waiting.get() == false)
			{
				
				try {
					monitor.wait(TIMEOUT);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if (Action.stop.get()) 
				{
					try {
						throw new Exception();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}
}