package q211;

public class PriorityManager {
	// Se uma transa��o precedente possui um timestamp maior, a aborta, sen�o, aguarde.

	private static int clock = 0;

	public PriorityManager() {
	}

	/*
	 ** Ou d� a chance a outra transa��o de finalizar, ou a aborta, ou ambos.
	 **
	 */
	public void resolve(Transaction me, Transaction other) {
		if (other.priority.get() > me.priority.get()) {
			other.blockWhileActiveAndNotWaiting();	// aguarda por prioridade igual ou maior
		} 
		else {
			other.abort();				// aborda prioridade menor
		}
	}	
}
