package q211;

public abstract class ContentionManager {
	static ThreadLocal<ContentionManager> local
	= new ThreadLocal<ContentionManager>() {
		protected ContentionManager initialValue() {
			try {
				return (ContentionManager) Defaults.MANAGER.newInstance();
			} catch (Exception ex) {
				try {
					throw new PanicException(ex);
				} catch (PanicException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return null;
		}
	};
	public abstract void resolve(Transaction me, Transaction other);
	public static ContentionManager getLocal() {
		return local.get();
	}
	public static void setLocal(ContentionManager m) {
		local.set(m);
	}
}