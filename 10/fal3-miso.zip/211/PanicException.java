package q211;
public class PanicException extends Exception {

	private static final long serialVersionUID = 52;

	public PanicException(String msg) {
		super(msg);
	}

	public PanicException(String msg, Throwable t) {
		super(msg, t);
	}

	public PanicException(Throwable t) {
		super(t);
	}
}