package q211;

import java.util.concurrent.atomic.AtomicBoolean;

public class Action {

	public static AtomicBoolean stop;
	
	public Action() {
		this.stop = new AtomicBoolean(false);
	}

}
