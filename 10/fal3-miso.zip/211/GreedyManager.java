package q211;

import java.util.concurrent.atomic.AtomicInteger;

public class GreedyManager extends ContentionManager {

	// contador usado como clock
	private AtomicInteger clock = new AtomicInteger(0);

	public GreedyManager()	{
	}

	/*
	** Se uma transa��o anterior est�:
	**  ativa e possui prioridade maior, ent�o espera;
	**	ativa e possui prioridade menor, ent�o a aborta;
	**	esperando e possui prioridade maior, ent�o adote sua prioridade e a aborta;
	** 	esperando e com prioridade menor, ent�o a aborta.
	*/
	@Override
	public void resolve(Transaction me, Transaction other) {
		
		if (other.waiting.get() || other.priority.get() < me.priority.get()) {
			other.abort();
		} else {
			me.setStatusToWaiting();				// anuncia que a thread atual est� esperando
			other.blockWhileActiveAndNotWaiting();	// espera por uma transa��o precedente para se tornar ativa
			me.setStatusToNotWaiting();				// anuncia que a thread atual n�o est� mais esperando
		}
	}

	// n�mero de clock menor = maior prioridade
	
}


