package q211;

public class KarmaManager {
	// Se uma transa��o precedente possui uma prioridade maior, executa, sen�o, aguarde.

	private static int clock = 0;

	public KarmaManager() {
	}

	public void resolve(Transaction me, Transaction other) {
		if (other.priority.get() > me.priority.get()) {
			other.blockWhileActiveAndNotWaiting();	// aguarda por prioridade igual ou maior
		} 
		else {
			other.abort();				// aborda prioridade menor
		}
	}	
}
