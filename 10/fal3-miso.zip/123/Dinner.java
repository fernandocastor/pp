


public class Dinner implements Runnable{
	
	private volatile boolean hungryState;
	private LockFreeQueue<Dinner> hungryDinners;
	private int id;
	 
    public Dinner(int id, boolean hungry, LockFreeQueue<Dinner> hungryDinners)
    {
        this.id = id;
		this.hungryState = hungry;
		this.hungryDinners = hungryDinners;
		
		if (hungryState){
			hungryDinners.enq(this);
		}
    }
 
    public int getId() {
		return id;
	}

	public void waitAndEat() throws EmptyException
    {
        if (!hungryState) {
        	Dinner hungryOne = hungryDinners.deq();
        	hungryOne.feed();
        	System.err.println("#" + id + ":feed " + hungryOne.getId());
        	this.changeState();
        	hungryDinners.enq(this);
        } else {
        	while (hungryState){
        		//Do nothing
        	}
        }
    }
 
    private void changeState() {
    	// Switch to non hungry as just ate
        hungryState = !hungryState;
	}

	private void feed()
    {
        // Switch to non hungry as just ate
        hungryState = !hungryState;
    }
	
	
	@Override
	public void run() {
		while (true) {
			try {
				waitAndEat();
			} catch (EmptyException e) {
				//e.printStackTrace();
			}
		}
		
	}
	
	public static void main(String[] args) {
		
		int dinnersCount = 5;
		LockFreeQueue<Dinner> hungryQueue = new LockFreeQueue<Dinner>();
		Dinner[] dinners = new Dinner[dinnersCount];
		
		for (int i = 0; i < dinnersCount; i++) {
			dinners[i] = new Dinner(i, i%2 == 0, hungryQueue );
			Thread t = new Thread(dinners[i]);
			t.start();
		}
		
	}

}

