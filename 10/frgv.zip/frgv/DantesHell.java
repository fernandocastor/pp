//package E123;

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.Random;

class Unfortunates implements Runnable {

	Unfortunates u;
	AtomicBoolean hunger = new AtomicBoolean(true);
  AtomicBoolean token = new AtomicBoolean(false);
	Lock multex = new ReentrantLock();
	int id;
	int len;

	Unfortunates (int index, int n) {
		id = index;
		len = n;
	}

	@Override
	public void run() {
    while (token.get() == false) {
//     System.out.println("Thread "+id+" are hunger");
//     System.out.println();
    }

		if (id == len-1) {
			u = DantesHell.unfortunates.get((len-1)-id);
		} else {
			u = DantesHell.unfortunates.get(id+1);
		}
		multex.lock();
		try {
			if (u.hunger.compareAndSet(false, true));
        token.getAndSet(false);
        System.out.println("Thread "+u.id+" eat by Thread "+id);
        System.out.println();
        u.token.getAndSet(true);
				//multex.unlock();
		} finally {
			multex.unlock();
		}
	}
}

class DantesHell {

	static final ArrayList<Unfortunates> unfortunates = new ArrayList<Unfortunates>();

	public static void main(String[] args) {

		int n;
    Unfortunates ali;
    Random rand = new Random();
		if(args.length == 0) {
			n = 4;
		} else {
			n = Integer.parseInt(args[0]);
		}

		for (int i = 0; i < n; i++) {
			unfortunates.add(new Unfortunates(i, n));
		}

		for (Unfortunates u : unfortunates) {
			new Thread(u).start();
		}
    ali = DantesHell.unfortunates.get(rand.nextInt(n));
    ali.token.getAndSet(true);
    System.out.println("Thread "+ali.id+" start");
	}

}
