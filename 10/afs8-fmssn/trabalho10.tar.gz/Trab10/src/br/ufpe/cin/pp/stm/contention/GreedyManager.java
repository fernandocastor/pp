package br.ufpe.cin.pp.stm.contention;

import br.ufpe.cin.pp.stm.Transaction;

public class GreedyManager extends ContentionManager {

	int delay = 20;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if (me.timestamp > other.timestamp || other.waiting) {
			other.waiting = false;
			other.abort();
		} else {
			me.waiting = true;
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				// fuck you checked exceptions :)
				throw new RuntimeException(e);
			}
			me.waiting = false;
		}
	}

}
