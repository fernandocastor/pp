package br.ufpe.cin.pp.stm;

public class Transaction {

	public int timestamp;
	public boolean waiting;

	public int workDone;

	public void abort() {
		// TODO Auto-generated method stub

	}

}
