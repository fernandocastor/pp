package br.ufpe.cin.pp.stm.contention;

import br.ufpe.cin.pp.stm.Transaction;

public class PriorityManager extends ContentionManager {

	public long delay = 20;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if (me.timestamp > other.timestamp) {
			other.abort();
		} else {
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				// fuck you checked exceptions :)
				throw new RuntimeException(e);
			}
		}
	}

}
