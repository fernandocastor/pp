package br.ufpe.cin.pp.stm.contention;

import br.ufpe.cin.pp.stm.Defaults;
import br.ufpe.cin.pp.stm.Transaction;

public abstract class ContentionManager {

	static ThreadLocal<ContentionManager> local = new ThreadLocal<ContentionManager>() {
		protected ContentionManager initialValue() {
			try {
				return (ContentionManager) Defaults.MANAGER.newInstance();
			} catch (Exception ex) {
				throw new RuntimeException("PanicException");
			}
		}
	};

	public abstract void resolve(Transaction me, Transaction other);

	public static ContentionManager getLocal() {
		return local.get();
	}

	public static void setLocal(ContentionManager m) {
		local.set(m);
	}

}
