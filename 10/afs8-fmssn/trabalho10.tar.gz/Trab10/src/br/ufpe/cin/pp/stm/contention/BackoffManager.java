package br.ufpe.cin.pp.stm.contention;

import java.util.Random;

import br.ufpe.cin.pp.stm.Transaction;

public class BackoffManager extends ContentionManager {

	private static final int MIN_DELAY = 10;

	private static final int MAX_DELAY = 500;

	Random random = new Random();

	Transaction previous = null;

	int delay = MIN_DELAY;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if (other != previous) {
			previous = other;
			delay = MIN_DELAY;
		}
		if (delay < MAX_DELAY) {
			try {
				Thread.sleep(random.nextInt(delay));
			} catch (InterruptedException e) {
				// fuck you, checked exceptions :)
				throw new RuntimeException(e);
			}
			delay = 2 * delay;
		} else {
			other.abort();
			delay = MIN_DELAY;
		}
	}

}
