package br.ufpe.cin.pp.stm;

import br.ufpe.cin.pp.stm.contention.BackoffManager;

public class Defaults {

	
	public static Class MANAGER = BackoffManager.class;
}
