package br.ufpe.cin.pp.stm.contention;

import br.ufpe.cin.pp.stm.Transaction;

public class KarmaManager extends ContentionManager {

	int delay = 20;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if (me.workDone > other.workDone) {
			other.abort();
		} else {
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				// fuck you checked exceptions :)
				throw new RuntimeException(e);
			}
		}
	}

}
