package TinyTM.contention;

import TinyTM.Transaction;

public class GreedyManager extends ContentionManager {
	
	private static final int DELAY = 256;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if(me.getTime().before(other.getTime()) || other.isWaiting()) {
			other.abort();
		} else {
			me.setWaiting(true);
			
			try {
				Thread.sleep(DELAY);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
			
			me.setWaiting(false);
		}
	}

}
