package TinyTM.contention;

import TinyTM.Transaction;

public class PriorityManager extends ContentionManager {
	
	private static final int DELAY = 256;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if(me.getTime().before(other.getTime())) {
			other.abort();
		} else {
			try {
				Thread.sleep(DELAY);
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}

}
