package TinyTM.contention;

import TinyTM.Transaction;

public class KarmaManager extends ContentionManager {

	@Override
	public void resolve(Transaction me, Transaction other) {
		if(me.getCompletedWork() > other.getCompletedWork()) {
			other.abort();
		} else {
			Thread.yield();
		}
	}

}
