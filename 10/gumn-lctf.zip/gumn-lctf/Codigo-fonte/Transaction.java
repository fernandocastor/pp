/*
 * Transaction.java
 *
 * Created on January 3, 2007, 8:44 PM
 *
 * From "The Art of Multiprocessor Programming",
 * by Maurice Herlihy and Nir Shavit.
 *
 * This work is licensed under a Creative Commons Attribution-Share Alike 3.0 United States License.
 * http://i.creativecommons.org/l/by-sa/3.0/us/88x31.png
 */

package TinyTM;

import java.util.Date;
import java.util.concurrent.atomic.AtomicReference;

public class Transaction {
  
  public enum Status {ABORTED, ACTIVE, COMMITTED};
  
  public static final Transaction COMMITTED = new Transaction(Status.COMMITTED);
  
  private final AtomicReference<Status> status;
  
  private final Date time;
  
  private volatile boolean waiting;
  
  private volatile int completedWork;
  
  static ThreadLocal<Transaction> local = new ThreadLocal<Transaction>() {
    @Override
    protected Transaction initialValue() {
      return new Transaction(Status.COMMITTED);
    }
  };
  
  public Transaction() {
    status = new AtomicReference<Status>(Status.ACTIVE);
    time = new Date();
    waiting = false;
    completedWork = 0;
  }
  
  private Transaction(Transaction.Status myStatus) {
    status = new AtomicReference<Status>(myStatus);
    time = new Date();
    waiting = false;
    completedWork = 0;
  }
  
  public Status getStatus() {
    return status.get();
  }
  
  public Date getTime() {
    return time;
  }
  
  public boolean isWaiting() {
	return waiting;
  }
  
  public void setWaiting(boolean waiting) {
	this.waiting = waiting;
  }
  
  public int getCompletedWork() {
	return completedWork;
  }
  
  public void setCompletedWork(int completedWork) {
	this.completedWork = completedWork;
  }
  
  public boolean commit() {
    return status.compareAndSet(Status.ACTIVE, Status.COMMITTED);
  }
  
  public boolean abort() {
    return status.compareAndSet(Status.ACTIVE, Status.ABORTED);
  }
  
  public static Transaction getLocal() {
    return local.get();
  }
  
  public static void setLocal(Transaction transaction) {
    local.set(transaction);
  }
  
}
