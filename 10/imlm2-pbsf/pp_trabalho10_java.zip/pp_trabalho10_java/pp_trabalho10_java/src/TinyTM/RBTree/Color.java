/*
 * Color.java
 *
 * Created on April 7, 2007, 8:03 PM
 *
 * From "Multiprocessor Synchronization and Concurrent Data Structures",
 * by Maurice Herlihy and Nir Shavit.
 *
 * This work is licensed under a Creative Commons Attribution-Share Alike 3.0 United States License.
 * http://i.creativecommons.org/l/by-sa/3.0/us/88x31.png
 */

package TinyTM.RBTree;

/**
 *
 * @author mph
 */
  
  public enum Color {BLACK, RED};
