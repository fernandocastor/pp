package TinyTM.contention;

import TinyTM.Transaction;

public class KarmaContentionManager extends ContentionManager {

	private final long WAIT_DELAY = 1000;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if(me.getKarma() > other.getKarma()) {
			other.abort();
		} else {
			try {
				Thread.sleep(WAIT_DELAY);
			} catch (InterruptedException e) {
				Thread.interrupted();
			}
		}
	}

}
