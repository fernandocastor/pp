package TinyTM.contention;

import TinyTM.Transaction;

public class PriorityContentionManager extends ContentionManager {

	private final long WAIT_DELAY = 1000;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if(me.getTimestamp() < other.getTimestamp()) {
			other.abort();
		} else {
			try {
				Thread.sleep(WAIT_DELAY);
			} catch (InterruptedException e) {
				Thread.interrupted();
			}
			
		}

	}

}
