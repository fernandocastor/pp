package TinyTM.contention;

import TinyTM.Transaction;

public class GreedyContentionManager extends ContentionManager {

	private final long WAIT_DELAY = 1000;

	@Override
	public void resolve(Transaction me, Transaction other) {
		if(me.getTimestamp() < other.getTimestamp()) {
			other.abort();
		} else if(other.isWaiting()) {
			other.abort();
		} else {
			try {
				me.setWaiting(true);
				Thread.sleep(WAIT_DELAY);
			} catch (InterruptedException e) {
				Thread.interrupted();
			} finally {
				me.setWaiting(false);
			}
			
		}

	}

}
