/*
 * Transaction.java
 *
 * Created on January 3, 2007, 8:44 PM
 *
 * From "The Art of Multiprocessor Programming",
 * by Maurice Herlihy and Nir Shavit.
 *
 * This work is licensed under a Creative Commons Attribution-Share Alike 3.0 United States License.
 * http://i.creativecommons.org/l/by-sa/3.0/us/88x31.png
 */

package TinyTM;

import java.util.concurrent.atomic.AtomicReference;

public class Transaction {
  public enum Status {ABORTED, ACTIVE, COMMITTED};
  public static final Transaction COMMITTED = new Transaction(Status.COMMITTED);
  private final AtomicReference<Status> status;
  static ThreadLocal<Transaction> local = new ThreadLocal<Transaction>() {
    @Override
    protected Transaction initialValue() {
      return new Transaction(Status.COMMITTED);
    }
  };
  public Transaction() {
    status = new AtomicReference<Status>(Status.ACTIVE);
    timestamp = System.currentTimeMillis();
  }
  private Transaction(Transaction.Status myStatus) {
    status = new AtomicReference<Status>(myStatus);
    timestamp = System.currentTimeMillis();
  }
  public Status getStatus() {
    return status.get();
  }
  public boolean commit() {
    return status.compareAndSet(Status.ACTIVE, Status.COMMITTED);
  }
  public boolean abort() {
    return status.compareAndSet(Status.ACTIVE, Status.ABORTED);
  }
  public static Transaction getLocal() {
    return local.get();
  }
  public static void setLocal(Transaction transaction) {
    local.set(transaction);
  }

  private final long timestamp;

  /**
   * Creates a new transaction with the same timestamp as the possibly aborted
   * transaction <code>aborted</code>.
   * @param aborted
   */
  public Transaction(Transaction aborted) {
    status = new AtomicReference<Status>(Status.ACTIVE);
    timestamp = aborted.getTimestamp();
  }
  
  public long getTimestamp() {
	return timestamp;
  }

  private volatile boolean waiting;

  public boolean isWaiting() {
	return waiting;
  }

  public void setWaiting(boolean waiting) {
	this.waiting = waiting;
  }

  private volatile long readCount;
  private volatile long writeCount;

  public void onRead() {
	  readCount++;
  }

  public void onWrite() {
	  writeCount++;
  }

  public long getKarma() {
	  return readCount + writeCount;
  }
}
