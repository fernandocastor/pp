package dante;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DanteHell {

	private static final int DEMON_COUNT = 5;
	private static UnboundedTotalQueue<Integer> demonsToBeFeed = new UnboundedTotalQueue<Integer>();
	
	public static void main(String[] args) {
		enqueDemons();
		feedDemons();
	}

	private static void feedDemons() {
		Set<Integer> drawnDemons = new HashSet<Integer>();
		Random random = new Random();
		
		while (drawnDemons.size() < DEMON_COUNT) {
			int ramdonDid = random.nextInt(DEMON_COUNT);
			
			if (drawnDemons.add(ramdonDid)) {
				new FeedThread(ramdonDid).start();
			}
		}
	}

	private static void enqueDemons() {
		Set<Integer> drawnDemons = new HashSet<Integer>();
		Random random = new Random();
		
		System.out.println("begining engueing demons");
		while (drawnDemons.size() < DEMON_COUNT) {
			int ramdonDid = random.nextInt(DEMON_COUNT);
			
			if (drawnDemons.add(ramdonDid)) {
				System.out.println(ramdonDid);
				demonsToBeFeed.enq(ramdonDid);
			}
		}
		System.out.println("ending engueing demons");
	}
	
	private static class FeedThread extends Thread {

		private static final String EMPTY_EXCEPTION_MESSAGE = "EMPTY";
		
		private int did;
		
		public FeedThread(int did) {
			this.did = did;
		}

		public void run() {
			while (true) {
				try {
					System.out.println("demon " + did + " trying to feed someone");
					Integer fedDid = demonsToBeFeed.deq(); // demon been fed
					
					if (fedDid != null) {
						System.out.println("DEMON " + fedDid + " was just fed by demon " + this.did);
					}
				} catch (RuntimeException e) {
					if (e.getMessage().equals(EMPTY_EXCEPTION_MESSAGE)) {
						break;
					}
				} catch (Exception e) {
					// try again
				}
			}
		}
	}
	
	private static class UnboundedTotalQueue<T> {
		
		private Lock enqLock;
		private Lock deqLock;

		private volatile Node<T> head;
		private volatile Node<T> tail;
		
		public UnboundedTotalQueue() {
			enqLock =  new ReentrantLock(true);
			deqLock =  new ReentrantLock(true);
			
			head = new Node<T>(null);
			tail = head;
		}
		
		public void enq(T value) {
			enqLock.lock();
			
			try {
				Node<T> newNode = new Node<T>(value);
				tail.next = newNode;
				tail = newNode;
				
			} finally {
				enqLock.unlock();
			}
		}

		public T deq() throws InterruptedException {
			T result;
			deqLock.lock();
			
			try {
				if (head.next == null) {
					throw new RuntimeException("EMPTY");
				}
				
				result = head.next.value;
				
				if (((FeedThread) Thread.currentThread()).did == (Integer) result) {
					return null;
				}
				
				head = head.next;
			} finally {
				deqLock.unlock();
			}
			
			return result;
		}
	}
	
	
	private static class Node<T> {
		public T value;
		public volatile Node<T> next;
		
		public Node(T value) {
			this.value = value;
			this.next = null;
		}
		
	}
	
}
