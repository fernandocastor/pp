package trabalho10;


public class PriorityManager extends ContentionManager {

	Transaction previous = null;

	@Override
	public void resolve(Transaction me, Transaction other) {

		if (me.time.get().before(other.time.get())) {
			other.abort();
		} else {
			try {
				me.wait();
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}
}
