package trabalho10;

public class GreedyManager extends ContentionManager {

	Transaction previous = null;

	@Override
	public void resolve(Transaction me, Transaction other) {

		if (me.time.get().before(other.time.get())
				|| (other.waiting.get())) {
			other.abort();
		} else {
			try {
				me.waiting.set(true);
				me.wait();
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}
}
