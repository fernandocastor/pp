package trabalho10;

public class KarmaManager extends ContentionManager {

	Transaction previous = null;

	@Override
	public void resolve(Transaction me, Transaction other) {

		if (me.track.get() > other.track.get()) {
			other.abort();
		} else {
			try {
				me.wait();
			} catch (InterruptedException ex) {
				Thread.currentThread().interrupt();
			}
		}
	}
}
