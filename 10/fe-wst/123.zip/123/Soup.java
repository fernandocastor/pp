package trabalho9.ex123;

import java.util.concurrent.atomic.AtomicInteger;

public class Soup {

	private AtomicInteger porcoes = new AtomicInteger(20);
	private Unfortunates[] infelizes;

	public Soup(Unfortunates[] infelizes) {
		this.infelizes = infelizes;
	}
	
	
	
	public AtomicInteger getPorcoes() {
		return porcoes;
	}



	public void setPorcoes(AtomicInteger porcoes) {
		this.porcoes = porcoes;
	}



	public Unfortunates[] getInfelizes() {
		return infelizes;
	}



	public void setInfelizes(Unfortunates[] infelizes) {
		this.infelizes = infelizes;
	}



	@Override
	public String toString() {
		return "Sopa porções restantes= " + porcoes + "]";
	}

	
}
