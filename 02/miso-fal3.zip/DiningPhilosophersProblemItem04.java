package exe01;

import java.util.Random;


/**
 * IN0984 - Sistemas Distribu�dos/Programa��o Paralela
 * Trabalho 04 - Item 04
 * Estas classes simulam o comportamento dos fil�sofos, onde cada fil�sofo � uma thread e os
 * chopsticks (chopsticks) s�o objetos compartilhados. Os m�todos destas classes previnem que
 * dois fil�sofos segurem o mesmo chopstick ao mesmo tempo e entrem em deadlock. Al�m disso,
 * o monitor nestas classes foi modificado para que nenhum fil�sofo passe fome, independente da
 * quantidade de fil�sofos que estejam pensando/comendo. 
 * 
 * @author {fal4,miso}@cin.ufpe.br
 */

public class DiningPhilosophersProblemItem04 {
	
	private static final int NUMBER_OF_PHILOSOPHERS = 10;

	public static void main (String[] args) {
		
		
		int i;
		
		// Criando os fil�sofos
		PhilosopherItem04[] philosophers = new PhilosopherItem04[NUMBER_OF_PHILOSOPHERS];
		
		// Criando o monitor para garantir que os dois chopsticks seja pegos ao mesmo tempo.
		PhilosopherMonitor04 philosopherMonitor = new PhilosopherMonitor04(NUMBER_OF_PHILOSOPHERS);
		
		// Instanciando os filos�fos no array de fil�sofos, tratando-os como threads.		
		for (i = 0; i < NUMBER_OF_PHILOSOPHERS; i++) {
			/* 
			 * In�cio das configura��es do problema: NUMBER_OF_PHILOSOPHERS fil�sofos, NUMBER_OF_PHILOSOPHERS monitores para os NUMBER_OF_PHILOSOPHERS chopsticks.
			 */ 			
			philosophers[i] = new PhilosopherItem04(i, philosopherMonitor, NUMBER_OF_PHILOSOPHERS);
			// Utiliza��o de start() ao inv�s de run(). Cria��o de novas threads para serem executadas em paralelo.
			new Thread(philosophers[i]).start();
		}
	}

}

/**
 * O comportamento dos fil�sofos alterna entre pensar e comer.
 * Para comer, um fil�sofo precisa segurar dois chopsticks. A sequ�ncia com trava para pegar
 * primeiramente o chopstick da esquerda e depois o da direita, ajuda no controle e preven��o
 * de que um fil�sofo n�o segure o mesmo hashi que outro fil�sofo j� esteja segurando. O uso
 * de monitores previne que um fil�sofo fique aguardando por um chopstick, garantindo que
 * os dois chopsticks sejam pegos ao mesmo tempo, evitando deadlocks.
 */
class PhilosopherItem04 implements Runnable {
	// ID do fil�sofo.
	private int id;
	
	int numberOfPhilosophers;
	
	// Monitor para os estados e a��es dos fil�sofos.
	private PhilosopherMonitor04 philosopherMonitor;
	
	/**
	 * Construtor de um novo fil�sofo:
	 * @param id id �nico para o fil�sofo.
	 * @param philosopherMonitor objeto que controla o uso dos chopsticks e estado dos
	 * 		  fil�sofos
	 * @param numberOfPhilosophers 
	 */
	public PhilosopherItem04 (int id, PhilosopherMonitor04 philosopherMonitor, int numberOfPhilosophers) {
		this.id = id;
		/* Para que n�o ocorra starvation em qualquer quantidade de fil�sofos, o tempo de pensamento dos
		 * fil�sofos deve ser aumentado.
		 */
		this.numberOfPhilosophers = numberOfPhilosophers;
		this.philosopherMonitor = philosopherMonitor;
	}
	
	/**
	 * Loop para que os fil�sofos pensem, peguem os chopsticks e comam.
	 */
	public void run() {
		try {
			while (true) {
				think();
				philosopherMonitor.getChopsticks(id);
				eat();
				philosopherMonitor.dropChopsticks(id);
			}
		} catch (InterruptedException e) {
			System.out.println("Fil�sofo " + id + " foi interrompido.\n");			
		}
	}

	/**
	 * Temporizador para que os fil�sofos fiquem pensando.
	 * @throws InterruptedException
	 */
	private void think() throws InterruptedException {
		System.out.println("Fil�sofo " + id + " est� pensando.\n");
		Thread.sleep(this.philosopherMonitor.TIME_TO_THINK*this.numberOfPhilosophers);
	}
	
	/**
	 * Quantidade de tempo vari�vel para modelar o ato de comer dos fil�sofos.
	 * @throws InterruptedException
	 */
	private void eat() throws InterruptedException {
		this.philosopherMonitor.eatenTimes[id]++;
		System.out.println("Fil�sofo " + id + " est� comendo, j� comeu: "+this.philosopherMonitor.eatenTimes[id]+" vezes");
		Thread.sleep(this.philosopherMonitor.TIME_TO_EAT);
	}
}

/**
 * Monitor para garantir que um fil�sofo somente pega os chopsticks quando nenhum
 * vizinho est� comendo.
 */
class PhilosopherMonitor04 {
	public int[] eatenTimes;
	// Temporizadores
	public int TIME_TO_THINK = 1000;
	public int TIME_TO_EAT = 1000;
	
	// Os estados do fil�sofo podem ser
	private enum State {THINKING, HUNGRY, EATING};
	
	// O estado para cada fil�sofo
	private State[] philosopherState;
	
	/**
	 * Criando um monitor para o n�mero correto de fil�sofos.
	 * O estado inicial para todos os fil�sofos � o de PENSANDO.
	 * @param numPhilosophers n�mero de fil�sofos
	 */
	public PhilosopherMonitor04 (int numPhilosophers) {
		eatenTimes = new int[numPhilosophers];
		philosopherState = new State[numPhilosophers];
		for (int i = 0; i < philosopherState.length; i++) {
			eatenTimes[i] = 0;
			philosopherState[i] = State.THINKING;
		}
	}
	
	/**
	 * Um fil�sofo pega os dois chopsticks. Caso algum n�o esteja dispon�vel, ele espera.
	 * 
	 * @param philosopherId id do fil�sofo que deseja comer
	 * @throws InterruptedException the thread was interrupted
	 */
	public synchronized void getChopsticks(int philosopherId) throws InterruptedException {		
		// Define o estado do fil�sofo como HUNGRY
		philosopherState[philosopherId] = State.HUNGRY;
		System.out.println("Fil�sofo " + philosopherId + " est� com fome.\n");
		
		
		// Aguarda at� que nenhum fil�sofo vizinho esteja comendo.
		while (anyNeighborPhilosopherIsEating(philosopherId)) {
			wait();
		}
		
		// Define o estado do fil�sofo como EATING
		philosopherState[philosopherId] = State.EATING;
		System.out.println("Fil�sofo " + philosopherId + " est� comendo.\n");
	}

	/**
	 * M�todo para verificar se algum vizinho do fil�sofo (philosopherId) est� comendo
	 * @param philosopherId the philosopher whose neighbors are checked
	 * @return true if either neighbor is currently eating
	 */
	private boolean anyNeighborPhilosopherIsEating(int philosopherId) {
		// Verifica fil�sofo de um lado
		if (philosopherState[getLeftPhilosopherId(philosopherId)] == State.EATING){
			return true;
		}

		// Verifica fil�sofo do outro lado
		if (philosopherState[getRightPhilosopherId(philosopherId)] == State.EATING){
			return true;
		}
		
		// Caso nenhum esteja comendo
		return false;
	}

	private int getLeftPhilosopherId(int philosopherId){
		return (philosopherId + 1) % philosopherState.length;
	}

	private int getRightPhilosopherId(int philosopherId){
		return (philosopherId + philosopherState.length - 1) % philosopherState.length;
	}
	
	/**
	 * Solta os dois chopsticks e notifica � todos os fil�sofos que est�o aguardando, caso
	 * algum deles possa comer.
	 *  
	 * @param philosopherId identificador do fil�sofo que terminou de comer.
	 */
	public synchronized void dropChopsticks(int philosopherId) {
		philosopherState[philosopherId] = State.THINKING;
		notifyAll();
	}
}