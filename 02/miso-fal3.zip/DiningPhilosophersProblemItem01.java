package exe01;

import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * IN0984 - Sistemas Distribu�dos/Programa��o Paralela
 * Trabalho 02 - Item 02
 * Estas classes simulam o comportamento dos fil�sofos, onde cada fil�sofo � uma thread e os
 * chopsticks (chopsticks) s�o objetos compartilhados. Os m�todos destas classes previnem que
 * dois fil�sofos segurem o mesmo chopstick ao mesmo tempo.
 * 
 * Ocorre deadlock.
 * 
 * @author {fal3,miso}@cin.ufpe.br
 */

public class DiningPhilosophersProblemItem01 {
	
	public static void main (String[] args) {

		int i;
		
		// Modelando array dos objetos chopsticks como travas reentrantes.
		Lock[] chopsticks = new ReentrantLock[5];
		
		// Criando os fil�sofos
		PhilosopherItem01[] philosophers = new PhilosopherItem01[5];
		
		for (i = 0; i < 5; i++) {
			chopsticks[i] = new ReentrantLock();
		}
		
		// Instanciando os filos�fos no array de fil�sofos, tratando-os como threads.		
		for (i = 0; i < 5; i++) {
			/* 
			 * In�cio das configura��es do problema: 5 fil�sofos, 5 chopsticks.
			 * Em (i+1)%5, � o desenho em que o chopstick do lado esquerdo de um fil�sofo se
			 * torna o chopstick do lado direito de outro, e assim sucessivamente.
			 */ 			
			philosophers[i] = new PhilosopherItem01(i, chopsticks[i], chopsticks[(i+1)%5]);
			new Thread(philosophers[i]).start();
		}
	}

}

/**
 * O comportamento dos fil�sofos alterna entre pensar e comer.
 * Para comer, um fil�sofo precisa segurar dois chopsticks. A sequ�ncia com trava para pegar
 * primeiramente o chopstick da esquerda e depois o da direita, ajuda no controle e preven��o
 * de que um fil�sofo n�o segure o mesmo hashi que outro fil�sofo j� esteja segurando.
 *
 */
class PhilosopherItem01 implements Runnable {
	// Utilizado para variar o quanto um fil�sofo pensa antes de comer e quanto dura sua refei��o.
	private Random randomNumber = new Random();
	
	// ID do fil�sofo.
	private int id;
	
	// Os chopsticks que o fil�sofo deve usar.
	private Lock leftChopstick;
	private Lock rightChopstick;
	
	/**
	 * Construtor de um novo fil�sofo:
	 * @param id id �nico para o fil�sofo.
	 * @param leftChopstick hashi da sua esquerda.
	 * @param rightChopstick hashi da sua direita.
	 */
	public PhilosopherItem01 (int id, Lock leftChopstick, Lock rightChopstick) {
		this.id = id;
		this.leftChopstick = leftChopstick;
		this.rightChopstick = rightChopstick;
	}
	
	/**
	 * Loop para que os fil�sofos pensem, peguem os chopsticks e comam.
	 */
	public void run() {
		try {
			while (true) {
				think();
				getLeftChopstick();
				getRightChopstick();
				eat();
				dropChopsticks();
			}
		} catch (InterruptedException e) {
			System.out.println("Fil�sofo " + id + " foi interrompido.\n");			
		}
	}

	/**
	 * Temporizador para que os fil�sofos fiquem pensando.
	 * @throws InterruptedException
	 */
	private void think() throws InterruptedException {
		System.out.println("Fil�sofo " + id + " est� pensando.\n");
		Thread.sleep(randomNumber.nextInt(5));
	}
	
	/** 
	 * Trava o chopstick do lado esquerdo que o fil�sofo est� segurando.
	 */
	private void getLeftChopstick() {
		leftChopstick.lock();
		System.out.println("Fil�sofo " + id + " est� segurando o hashi de sua equerda.\n");
	}

	/** 
	 * Trava o chopstick do lado direito que o fil�sofo est� segurando.
	 */
	private void getRightChopstick() {
		rightChopstick.lock();
		System.out.println("Fil�sofo " + id + " est� segurando o hash de sua direita.\n");
	}

	/**
	 * Quantidade de tempo vari�vel para modelar o ato de comer dos fil�sofos.
	 * @throws InterruptedException
	 */
	private void eat() throws InterruptedException {
		System.out.println("Fil�sofo " + id + " est� comendo.\n");
		Thread.sleep (randomNumber.nextInt(10));
	}
	
	/**
	 * Remove a trava dos chopsticks para que outros fil�sofos os usem.
	 */
	private void dropChopsticks() {
		leftChopstick.unlock();
		rightChopstick.unlock();
	}
}