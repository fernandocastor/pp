package main;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* 
 * Wai -> Waiting with Wai
 * Eat -> Eat
 * Thi -> Thi
 */
enum PhilosopherStatus {
	Wai, Eat, Thi
}

class Chopstick {
	public static final int OnTable = -1;
	static int instances = 0;
	public int id;
	public AtomicInteger holder = new AtomicInteger(OnTable);

	public Chopstick() {
		id = instances++;
	}
}

class Philosopher implements Runnable {
	static final int maxTimeWaitToEat = 100;
	static AtomicInteger token = new AtomicInteger(0);
	static int instances = 0;
	static Random rand = new Random();
	AtomicBoolean end = new AtomicBoolean(false);
	int id;
	PhilosopherStatus status = PhilosopherStatus.Wai;
	Chopstick left;
	Chopstick right;
	int Eatime = 0;

	Philosopher() {
		id = instances++;
		left = Dinner.chopsticks.get(id);
		right = Dinner.chopsticks.get((id + 1) % Dinner.philosopherCount);
	}

	void sleep() {
		try {
			Thread.sleep(rand.nextInt(maxTimeWaitToEat));
		} catch (InterruptedException ex) {
		}
	}

	void waitForChopstick(Chopstick chopstick) {
		do {
			if (chopstick.holder.get() == Chopstick.OnTable) {
				chopstick.holder.set(id);
				return;
			} else {
				sleep();
			}
		} while (true);
	}

	// @Override
	public void run() {
		do {
			if (status == PhilosopherStatus.Thi) {
				status = PhilosopherStatus.Wai;
			} else {
				if (token.get() == id) {
					waitForChopstick(left);
					waitForChopstick(right);
					token.set((id + 2) % Dinner.philosopherCount);
					status = PhilosopherStatus.Eat;
					Eatime++;
					sleep();
					putsDown();
					status = PhilosopherStatus.Thi;
					sleep();
				} else {
					sleep();
				}
			}
		} while (!end.get());
	}

	private void putsDown() {
		left.holder.set(Chopstick.OnTable);
		right.holder.set(Chopstick.OnTable);
	}
}

public class Dinner {
	static final int philosopherCount = 5;
	static final int durationOfDinner = 15;
	static final ArrayList<Chopstick> chopsticks = new ArrayList<Chopstick>();
	static final ArrayList<Philosopher> philosophers = new ArrayList<Philosopher>();

	public static void main(String[] args) {
		for (int i = 0; i < philosopherCount; i++)
			chopsticks.add(new Chopstick());
		for (int i = 0; i < philosopherCount; i++)
			philosophers.add(new Philosopher());
		for (Philosopher p : philosophers)
			new Thread(p).start();
		long endTime = System.currentTimeMillis() + (durationOfDinner * 1000);

		do {
			StringBuilder strPhil = new StringBuilder("Philosophers |");
			StringBuilder strState = new StringBuilder("\nDoing        |");
			StringBuilder strHands = new StringBuilder("\nChopsticks   |");
			for (Philosopher p : philosophers) {
				strPhil.append(String.format("  P0%1$s  |", p.id));
				strState.append(String.format("  %1$s  |", p.status));

				strHands.append(String.format(" %1$s | %2$s |",
						(p.left.holder.get() == p.id ? p.left.id : " "),
						(p.right.holder.get() == p.id ? p.right.id : " ")));
			}
			strPhil.append(strState);
			strPhil.append(strHands);
			strPhil.append("\n======================================================");

			System.out.println(strPhil.toString());
			try {
				Thread.sleep(1000);
			} catch (Exception ex) {
			}
		} while (System.currentTimeMillis() < endTime);

		for (Philosopher p : philosophers)
			p.end.set(true);
	}
}