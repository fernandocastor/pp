package br.ufpe.cin.pp.trabalho02.ch01.ex1_3;

public class DiningPhilosophers {

	private static final int N = 5;
	
	public static void main(String[] args) {
		StarvationFreeChopsticks chopsticks = new StarvationFreeChopsticks(N);
		
		for (int i = 0; i < N; i++) {
			Philosopher philosopher = new Philosopher(i, chopsticks);
			new Thread(philosopher).start();
		}
	}
	
}
