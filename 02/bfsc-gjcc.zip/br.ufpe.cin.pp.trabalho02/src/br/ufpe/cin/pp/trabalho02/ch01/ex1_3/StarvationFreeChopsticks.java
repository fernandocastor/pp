package br.ufpe.cin.pp.trabalho02.ch01.ex1_3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class StarvationFreeChopsticks {

	private int n;
	private List<Queue<Integer>> queues;
	
	public StarvationFreeChopsticks(int n) {
		this.n = n;
		
		this.queues = new ArrayList<Queue<Integer>>(n);
		
		for (int i = 0; i < n; i++) {
			this.queues.add(new LinkedList<Integer>());
		}
	}
	
	public synchronized boolean getChopsticks(int id) {
		boolean lock = false;
		
		int rightChopstick = id;
		int leftChopstick = (id == n-1) ? 0 : id+1;

		// if it is empty
		if (queues.get(rightChopstick).isEmpty()) {
			lock = queues.get(leftChopstick).isEmpty();
			queues.get(rightChopstick).add(id);
			queues.get(leftChopstick).add(id);
			
		// if it is in the head
		} else if (queues.get(rightChopstick).peek() == id) {
			lock = queues.get(leftChopstick).peek() == id;
			
		// if it is in the queue
		} else if (queues.get(rightChopstick).contains(id)) {
			lock = false;
			
		// if it is not in the queue
		} else {
			lock = false;
			queues.get(rightChopstick).add(id);
			queues.get(leftChopstick).add(id);
		}
		
		return lock;
	}
	
	public synchronized void returnChopsticks(int id) {
		int rightChopstick = id;
		int leftChopstick = (id == n-1) ? 0 : id+1;
		
		if (queues.get(rightChopstick).peek() == id && queues.get(leftChopstick).peek() == id) {
			queues.get(rightChopstick).poll();
			queues.get(leftChopstick).poll();
		}
	}
	
}
