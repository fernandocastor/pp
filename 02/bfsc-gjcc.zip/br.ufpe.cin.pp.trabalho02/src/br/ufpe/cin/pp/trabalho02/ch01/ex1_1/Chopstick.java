package br.ufpe.cin.pp.trabalho02.ch01.ex1_1;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Chopstick {
	
	private Lock lock = new ReentrantLock();

	public void getChopstick() {
		this.lock.lock();
	}
	
	public void returnChopstick() {
		this.lock.unlock();
	}
			
}
