package br.ufpe.cin.pp.trabalho02.ch01.ex1_2;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Chopstick {
	
	private Lock lock = new ReentrantLock();

	public boolean tryGetChopstick() {
		boolean acquired = false;
		
		try {
			acquired = this.lock.tryLock(0, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			
		}
		
		return acquired;
	}
	
	public void returnChopstick() {
		this.lock.unlock();
	}
			
}
