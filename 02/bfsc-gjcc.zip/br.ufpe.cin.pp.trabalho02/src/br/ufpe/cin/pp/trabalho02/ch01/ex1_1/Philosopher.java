package br.ufpe.cin.pp.trabalho02.ch01.ex1_1;

import java.util.Random;

public class Philosopher implements Runnable {
	
//	private int id;
	private String name;
	private Chopstick rightChopstick;
	private Chopstick leftChopstick;
	
	public Philosopher(int id, Chopstick rightChopstick, Chopstick leftChopstick) {
//		this.id = id;
		this.name = "Philosopher " + id;
		this.leftChopstick = leftChopstick;
		this.rightChopstick = rightChopstick;
	}
	
	public void run() {
		for (int i = 1; i <= new Random().nextInt(100); i++) {
			try {
				eat(i);
				think(i);
			} catch (InterruptedException e) {
				System.err.println("Interruped Exception with " + this.name +" in " + i +"th try." );
			}
		}
	}
	
	public void eat(int times) throws InterruptedException {
		System.out.println(this.name + " is trying to eat for the " + times + "th time.");
		
//		Para simular um deadlock com N=2
//		if (this.id == 1) {
//			Thread.sleep(1000);
//		}
		
		rightChopstick.getChopstick();
		
//		Para simular um deadlock com N=2
//		if (this.id == 2) {
//			Thread.sleep(1000);
//		}
		
		leftChopstick.getChopstick();
		
		try {
			System.out.println(this.name + " started eating for the " + times + "th time.");
			Thread.sleep(new Random().nextInt(1000));
			System.out.println(this.name + " finished eating for the " + times + "th time.");
		} finally {
			rightChopstick.returnChopstick();
			leftChopstick.returnChopstick();
		}
	}
	
	public void think(int times) {
		try {
			System.out.println(this.name + " started thinking for the " + times + "th time.");
			Thread.sleep(new Random().nextInt(5000));
			System.out.println(this.name + " finished thinking for the " + times + "th time.");
		} catch (InterruptedException e) {
			
		}
	}
	
}
