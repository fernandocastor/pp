package br.ufpe.cin.pp.trabalho02.ch01.ex1_1;

public class DiningPhilosophers {

	private static final int N = 2;
	private static Chopstick[] chopsticks = new Chopstick[N];
	
	public static void main(String[] args) {
		for (int i = 0; i < N; i++) {
			chopsticks[i] = new Chopstick();
		}

		for (int i = 1; i <= N; i++) {
			if (i == N) {
				Philosopher philosopher = new Philosopher(i, chopsticks[i-1], chopsticks[0]);
				new Thread(philosopher).start();
			} else {
				Philosopher philosopher = new Philosopher(i, chopsticks[i-1], chopsticks[i]);
				new Thread(philosopher).start();
			}
		}
	}
	
}
