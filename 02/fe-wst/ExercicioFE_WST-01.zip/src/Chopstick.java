

public class Chopstick {
	
	private int idFilosofo = -1;
	private boolean isUsada=false;
	private int idChopstick;
	

	public int getIdChopstick() {
		return idChopstick;
	}

	public void setIdChopstick(int idChopstick) {
		this.idChopstick = idChopstick;
	}

	public int getIdFilosofo() {
		return idFilosofo;
	}

	public void setIdFilosofo(int idFilosofo) {
		this.idFilosofo = idFilosofo;
	}

	public boolean isUsada() {
		return isUsada;
	}

	public void setUsada(boolean isUsada) {
		this.isUsada = isUsada;
	}

	public Chopstick(boolean isUsada, int idChopstick) {
		super();
		this.isUsada = isUsada;
		this.idChopstick = idChopstick;
	}
	
}
