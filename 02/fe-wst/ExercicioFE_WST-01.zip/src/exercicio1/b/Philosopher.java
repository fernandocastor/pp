package exercicio1.b;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Philosopher implements Runnable {

	private int index;
	private Chopstick chopStickDireita;
	private Chopstick chopStickEsquerda;
	private Table table;
	

	public Philosopher(int i, Table table, Chopstick direita, Chopstick esquerda) {
		this.index = i;
		this.table = table;
		this.chopStickDireita = direita;
		this.chopStickEsquerda = esquerda;
	}

	public void think() {
		try {
			System.out.println(this + " is sleeping...");
			Thread.sleep(4);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public synchronized boolean eat() {

		boolean ate = false;
		int sticks = 0;
		
		if (!this.chopStickEsquerda.isUsada()) {
			this.chopStickEsquerda.setUsada(true);
			this.chopStickEsquerda.setIdFilosofo(index);
			
			sticks++;
			System.out.println(this + ", Hashi: " + this.chopStickEsquerda.getIdChopstick());
		}

		if (!this.chopStickDireita.isUsada()) {
			this.chopStickDireita.setUsada(true);
			this.chopStickDireita.setIdFilosofo(index);
			sticks++;
			System.out.println(this + ", Hashi: " + this.chopStickDireita.getIdChopstick() );
		}

		if (sticks == 1) {
					
			System.out.println(this + " so pegou 1 hashi");
			
			if(this.chopStickEsquerda.getIdFilosofo() == this.index){
				this.chopStickEsquerda.setUsada(false);
				this.chopStickEsquerda.setIdFilosofo(-1);
			}
			else if(this.chopStickDireita.getIdFilosofo() == this.index){
				this.chopStickDireita.setUsada(false);
				this.chopStickDireita.setIdFilosofo(-1);
			}
			System.out.println(this + "tentou pegar os 2 hashis e não conseguiu");
			
		}
		
	
		if (sticks == 2) {
			long cal = Calendar.getInstance().getTimeInMillis();
			
			System.out.println(this + " could eat." + cal);
			ate = true;
			try {
				Thread.sleep(4);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return ate;
	}

	public synchronized void stopEating() {
		this.chopStickDireita.setIdFilosofo(-1);
		this.chopStickDireita.setUsada(false);
		this.chopStickEsquerda.setIdFilosofo(-1);
		this.chopStickEsquerda.setUsada(false);

			
		long cal = Calendar.getInstance().getTimeInMillis();

		
		
		System.out.println(this + " stopped eating. Hora" + cal);
	}

	@Override
	public void run() {
		// this.think();
		
		while (true) {
			try {
				if (this.eat()) {
					Thread.sleep(4);
					this.stopEating();
		
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public String toString() {
		return "Philosopher [index=" + index + "]";
	}

}
