package exercicio1.a;

import java.util.Arrays;

public class Table {

	private Chopstick[] chopsticks = new Chopstick[5];
	private int next = 0;

	public Table() {
		chopsticks[0] = new Chopstick(false, 0);
		chopsticks[1] = new Chopstick(false, 1);
		chopsticks[2] = new Chopstick(false, 2);
		chopsticks[3] = new Chopstick(false, 3);
		chopsticks[4] = new Chopstick(false, 4);
	}
	
	public Chopstick retornaChopstick(int valor){
		return this.chopsticks[valor];
	}

//	public boolean getChopstick(Integer phi) {
//
//		boolean ate = false;
//		// check if there is 1 stick available
//		//if (this.check1Available()) {
//		
//			for (int i = 0; i < this.chopsticks.length && !ate; i++) {
//				if (chopsticks[i] == 0) {
//					this.useStick(i, phi);
//					ate = true;
//				}
//			}
//		//}
//		System.out.println(this);
//		return ate;
//	}

//	public synchronized int serve2(Integer phi) {
//
//		int numberSticks = 0;
//
//		if (this.next == 0) {
//
//			// try to get first stick
//			if (this.getChopstick(phi)) {
//				numberSticks = 1;
//				// try to get second stick
//				if (this.getChopstick(phi)) {
//					numberSticks = 2;
//				}
//			}
//		} else {
//			System.out.println(">>>>>>>>>>>>>>>>>>>>  Philosopher [" + phi + "] is NOT the next." + " the next is: " + this.next);
//		}
//		return numberSticks;
//	}

//	public synchronized int serve1(Integer phi) {
//
//		int numberSticks = 1;
//		if (this.next == phi) {
//			if (this.getChopstick(phi)) {
//				numberSticks = 2;
//				this.next = 0;
//				System.out.println(">>>>>>>>>>>>>>>>>>>>  next is available now.");
//			}
//		}
//		return numberSticks;
//	}
//
//	

//	public void useStick(int index, int phi) {
//		// synchronized (chopsticks) {
//		this.chopsticks[index] = phi;
//		// }
//	}

//	public synchronized void releaseStick(int phi) {
//		for (int i = 0; i < this.chopsticks.length; i++) {
//			if (this.chopsticks[i] == phi) {
//				this.chopsticks[i] = 0;
//				// break;
//			}
//		}
//		System.out.println(this);
//	}

	public int getNext() {
		return next;
	}

	public void setNext(int next) {
		this.next = next;
	}

	@Override
	public String toString() {
		return "Table [chopsticks=" + Arrays.toString(chopsticks) + "]";
	}

	
}
