package filosofos;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		List<Thread> threads = new ArrayList<Thread>();
		Table t = new Table();
		

		// create 5 philosophers
		for (int i = 0; i < 5; i++) {
			//se for o ultimo Hashi ele vai pegar o ultimo e o primeiro
			Runnable task = new Philosopher(i, t, t.retornaChopstick(i), t.retornaChopstick(i==4?0:i+1));
			Thread philosopher = new Thread(task);
			philosopher.setName(String.valueOf(i));
			philosopher.start();
			threads.add(philosopher);
		}

		int running = 0;

		do {
			running = 0;
			for (Thread thread : threads) {
				if (thread.isAlive()) {
					running++;
				}
			}
		} while (running > 0);

	}
}
