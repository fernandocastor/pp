package filosofos;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Philosopher implements Runnable {

	private int index;
	private Chopstick chopStickDireita;
	private Chopstick chopStickEsquerda;
	private Table table;
	

	public Philosopher(int i, Table table, Chopstick direita, Chopstick esquerda) {
		this.index = i;
		this.table = table;
		this.chopStickDireita = direita;
		this.chopStickEsquerda = esquerda;
	}

	public void think() {
		try {
			System.out.println(this + " is sleeping...");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public synchronized boolean eat() {

		boolean ate = false;
		int sticks = 0;

		if (!this.chopStickEsquerda.isUsada()) {
			this.chopStickEsquerda.setUsada(true);
			this.chopStickEsquerda.setIdFilosofo(index);
			
			sticks++;
			System.out.println(this + ", Hashi: " + this.chopStickEsquerda.getIdChopstick());
		}

		if (!this.chopStickDireita.isUsada()) {
			this.chopStickDireita.setUsada(true);
			this.chopStickDireita.setIdFilosofo(index);
			sticks++;
			System.out.println(this + ", Hashi: " + this.chopStickDireita.getIdChopstick() );
		}

		if (sticks == 1) {
					
			System.out.println(this + " so pegou 1 hashi");
			
			if (this.chopStickEsquerda.isUsada()
					&& this.chopStickEsquerda.getIdFilosofo() != this.index) {
				while (this.chopStickEsquerda.isUsada()) {
				}
				this.chopStickEsquerda.setUsada(true);
				this.chopStickEsquerda.setIdFilosofo(index);
				sticks++;
				System.out.println(this + ", Hashi: " + this.chopStickEsquerda.getIdChopstick() );
			} else if (this.chopStickDireita.isUsada()
					&& this.chopStickDireita.getIdFilosofo() != this.index) {
				while (this.chopStickDireita.isUsada()) {
				}
				this.chopStickDireita.setUsada(true);
				this.chopStickDireita.setIdFilosofo(index);
				System.out.println(this + ", Hashi: " + this.chopStickDireita.getIdChopstick());
				sticks++;
			}

		}

	
		if (sticks == 2) {
			long cal = Calendar.getInstance().getTimeInMillis();
			
			System.out.println(this + " could eat." + cal);
			ate = true;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return ate;
	}

	public synchronized void stopEating() {
		this.chopStickDireita.setIdFilosofo(-1);
		this.chopStickDireita.setUsada(false);
		this.chopStickEsquerda.setIdFilosofo(-1);
		this.chopStickEsquerda.setUsada(false);

			
		long cal = Calendar.getInstance().getTimeInMillis();

		
		
		System.out.println(this + " stopped eating. Hora" + cal);
	}

	@Override
	public void run() {
		// this.think();
		//while (true) {
			try {
				if (this.eat()) {
					Thread.sleep(1000);
					this.stopEating();
				}
				
				this.think();
				if (this.eat()) {
					Thread.sleep(1000);
					this.stopEating();
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		//}
	}

	@Override
	public String toString() {
		return "Philosopher [index=" + index + "]";
	}

}
