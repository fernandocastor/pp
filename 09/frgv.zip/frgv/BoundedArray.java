package E121;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedArray<T> {

	ReentrantLock enqLock, deqLock;
	Condition notEmptyCondition, notFullCondition;
	AtomicInteger size, enqueuePoint, dequeuePoint;
	volatile int head, tail;
	private int capacity;
	private Object[] items;

	public BoundedArray() {

  		this.enqueuePoint = new AtomicInteger(0);
      this.dequeuePoint = new AtomicInteger(0);
  		this.capacity = capacity;
  		this.items = new Object[capacity];
	    this.size = new AtomicInteger(capacity);
	    this.enqLock = new ReentrantLock();
	    this.deqLock = new ReentrantLock();
	    this.notFullCondition = enqLock.newCondition();
	    this.notEmptyCondition = deqLock.newCondition();
	}

	public void enq(Object newItem) throws InterruptedException {

		boolean mustWakeDeq = false;
		try {
            while (size.get() == capacity)
                notFullCondition.await();
            items[enqueuePoint.getAndIncrement()] = newItem;
            if (size.getAndIncrement() == 0)
                mustWakeDeq = true;
        } finally {
            enqLock.unlock();
        }
        if (mustWakeDeq) {
            deqLock.lock();
            try {
                notEmptyCondition.signalAll();
            } finally {
                deqLock.unlock();
            }
        }
    }

    public Object deq() throws InterruptedException {

        Object result;
        boolean mustWakeEnq = false;
        deqLock.lock();
        try {
            while (size.get() == 0)
                notEmptyCondition.await();
            result = items[dequeuePoint.getAndIncrement()];
            if (size.getAndDecrement() == capacity) {
                mustWakeEnq = true;
            }
        } finally {
            deqLock.unlock();
        }
        if (mustWakeEnq) {
            enqLock.lock();
            try {
                notFullCondition.signalAll();
            } finally {
                enqLock.unlock();
            }
        }
        return result;
    }

}
