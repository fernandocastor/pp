
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedArrayQueue<T> implements Queue<T> {
	
	private ReentrantLock enqLock, deqLock;
	private Condition notFullCondition, notEmptyCondition;
	private AtomicInteger size;
	private volatile T[] content;
	private int head, tail;
	
	@SuppressWarnings("unchecked")
	public BoundedArrayQueue(int capacity) {
		this.enqLock = new ReentrantLock();
		this.deqLock = new ReentrantLock();
		this.notFullCondition = this.enqLock.newCondition();
		this.notEmptyCondition = this.deqLock.newCondition();
		this.size = new AtomicInteger(0);
		this.content = (T[]) new Object[capacity];
		this.head = 0;
		this.tail = 0;
	}

	@Override
	public void enq(T t) {
		boolean mustWakeDequeuers = false;
		
		this.enqLock.lock();
		try {
			while(this.size.get()==this.content.length)
				this.notFullCondition.await();
			
			this.content[this.tail] = t;
			this.tail = (this.tail + 1) % this.content.length;
			
			if(this.size.getAndIncrement()==0)
				mustWakeDequeuers = true;
		} catch(InterruptedException e) {
			e.printStackTrace();
		} finally {
			this.enqLock.unlock();
		}
		
		if(mustWakeDequeuers) {
			this.deqLock.lock();
			
			try {
				this.notEmptyCondition.signalAll();
			} finally {
				this.deqLock.unlock();
			}
		}
	}

	@Override
	public T deq() {
		boolean mustWakeEnqueuers = false;
		T result = null;
		
		this.deqLock.lock();
		try {
			while(this.size.get()==0)
				this.notEmptyCondition.await();
			
			result = this.content[this.head];
			this.content[this.head] = null;
			this.head = (this.head + 1) % this.content.length;
			
			if(this.size.getAndDecrement()==this.content.length)
				mustWakeEnqueuers = true;
		} catch(InterruptedException e) {
			e.printStackTrace();
		} finally {
			this.deqLock.unlock();
		}
		
		if(mustWakeEnqueuers) {
			this.enqLock.lock();
			
			try {
				this.notFullCondition.signalAll();
			} finally {
				this.enqLock.unlock();
			}
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		int items = 15;
		int capacity = 5;
		Queue<Integer> queue = new BoundedArrayQueue<Integer>(capacity);
		
		for(int i=0; i<items; i++) {
			Thread tEnq = new Thread(new Runnable() {
				@Override
				public void run() {
					int e = new Random().nextInt(100);
					queue.enq(e);
					System.out.println("enq " + e);
				}
			});
			
			tEnq.start();
		}
		
		for(int i=0; i<items; i++) {
			Thread tEnq = new Thread(new Runnable() {
				@Override
				public void run() {
					System.out.println("deq " + queue.deq());
				}
			});
			
			tEnq.start();
		}
	}
	
}
