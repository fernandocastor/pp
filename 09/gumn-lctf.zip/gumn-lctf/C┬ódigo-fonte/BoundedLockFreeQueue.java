
import java.lang.reflect.Array;
import java.util.Random;
import java.util.concurrent.atomic.AtomicMarkableReference;

public class BoundedLockFreeQueue<T> implements Queue<T> {
	
	private volatile T[] content;
	private volatile AtomicMarkableReference<Integer> head, tail;
	
	@SuppressWarnings("unchecked")
	public BoundedLockFreeQueue(int capacity) {
		this.content = (T[]) Array.newInstance(Object.class, capacity);
		this.head = new AtomicMarkableReference<Integer>(0, true);
		this.tail = new AtomicMarkableReference<Integer>(0, true);
	}

	@Override
	public void enq(T t) {
		while(true) {
			boolean[] headSign = {false};
			boolean[] tailSign = {false};
			int previousTail;
			
			do {
				previousTail = this.tail.get(tailSign);
			} while(previousTail - this.head.get(headSign) == this.content.length || !headSign[0] || !tailSign[0]);
			
			int nextTail = previousTail + 1;
			if(this.tail.compareAndSet(previousTail, nextTail, true, false)) {
				this.content[previousTail % this.content.length] = t;
				this.tail.attemptMark(nextTail, true);
				break;
			}
		}
	}

	@Override
	public T deq() {
		T result;
		
		while(true) {
			boolean[] headSign = {false};
			boolean[] tailSign = {false};
			int previousHead;
			
			do {
				previousHead = this.head.get(headSign);
			} while(this.tail.get(tailSign) - previousHead == 0 || !headSign[0] || !tailSign[0]);
			
			int nextHead = previousHead + 1;
			if(this.head.compareAndSet(previousHead, nextHead, true, false)) {
				result = this.content[previousHead % this.content.length];
				this.head.attemptMark(nextHead, true);
				break;
			}
		}
		
		return result;
	}
	
	public static void main(String[] args) {
		int items = 15;
		int capacity = 5;
		Queue<Integer> queue = new BoundedLockFreeQueue<Integer>(capacity);
		
		for(int i=0; i<items; i++) {
			Thread tEnq = new Thread(new Runnable() {
				@Override
				public void run() {
					int e = new Random().nextInt(100);
					queue.enq(e);
					System.out.println("enq " + e);
				}
			});
			
			tEnq.start();
		}
		
		for(int i=0; i<items; i++) {
			Thread tEnq = new Thread(new Runnable() {
				@Override
				public void run() {
					System.out.println("deq " + queue.deq());
				}
			});
			
			tEnq.start();
		}
	}

}
