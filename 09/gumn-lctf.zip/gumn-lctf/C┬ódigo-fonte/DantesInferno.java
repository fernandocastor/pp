
public class DantesInferno {
	
	private static final int NUMBER_OF_UNFORTUNATES = 5;
	private static final int TIME_TO_EXECUTE = 3000;
	private static final int TIME_TO_REST = 200;
	
	private static volatile Unfortunate[] unfortunates;
	private static volatile boolean stop;
	
	static {
		unfortunates = new Unfortunate[NUMBER_OF_UNFORTUNATES];
		
		for(int i=0; i<NUMBER_OF_UNFORTUNATES; i++) {
			unfortunates[i] = new Unfortunate(i);
		}
		
		stop = false;
	}
	
	public static class Unfortunate extends Thread {
		
		private volatile int id, fedTimes;
		private volatile boolean fed;
		
		public Unfortunate(int id) {
			this.id = id;
			this.fedTimes = 0;
			this.fed = false;
		}
		
		@Override
		public void run() {
			while(!stop) {
				if(this.fed && unfortunates[(this.id + 1) % NUMBER_OF_UNFORTUNATES].fed) {
					try {
						Thread.sleep(TIME_TO_REST);
						this.fed = false;
					} catch(InterruptedException e) {
						e.printStackTrace();
					}
				} else if(!unfortunates[(this.id + 1) % NUMBER_OF_UNFORTUNATES].fed) {
					unfortunates[(this.id + 1) % NUMBER_OF_UNFORTUNATES].fedTimes++;
					unfortunates[(this.id + 1) % NUMBER_OF_UNFORTUNATES].fed = true;
					System.out.println("Unfortunate #" + this.id + " fed unfortunate #" + unfortunates[(this.id + 1) % NUMBER_OF_UNFORTUNATES].id + ".");
				} else {
					continue;
				}
			}
		}
		
	}
	
	public static void main(String[] args) throws InterruptedException {
		for(Unfortunate unfortunate : unfortunates) {
			unfortunate.start();
		}
		
		Thread.sleep(TIME_TO_EXECUTE);
		stop = true;
		
		for(Unfortunate unfortunate : unfortunates) {
			unfortunate.join();
		}
		
		for(Unfortunate unfortunate : unfortunates) {
			System.out.println("Unfortunate #" + unfortunate.id + " was fed " + unfortunate.fedTimes + " times.");
		}
	}
}
