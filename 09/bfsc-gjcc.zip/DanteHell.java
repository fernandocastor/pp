package dante;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DanteHell {

	private static final int DEMON_COUNT = 10;
	private static UnboundedPartialQueue<Integer> demonsToBeFeed = new UnboundedPartialQueue<Integer>();
	
	public static void main(String[] args) {
		enqueDemons();
		feedDemons();
	}

	private static void feedDemons() {
		Set<Integer> drawnDemons = new HashSet<Integer>();
		Random random = new Random();
		
		while (drawnDemons.size() < DEMON_COUNT) {
			int ramdonDid = random.nextInt(DEMON_COUNT);
			
			if (drawnDemons.add(ramdonDid)) {
				new Thread(new FeedThread(ramdonDid)).start();
			}
		}
	}

	private static void enqueDemons() {
		Set<Integer> drawnDemons = new HashSet<Integer>();
		Random random = new Random();
		
		System.out.println("begining engueing demons");
		while (drawnDemons.size() < DEMON_COUNT) {
			int ramdonDid = random.nextInt(DEMON_COUNT);
			
			if (drawnDemons.add(ramdonDid)) {
				System.out.println(ramdonDid);
				demonsToBeFeed.enq(ramdonDid);
			}
		}
		System.out.println("ending engueing demons");
	}
	
	private static class FeedThread implements Runnable {

		private int did;
		
		public FeedThread(int did) {
			this.did = did;
		}

		public void run() {
			while (true) {
				try {
					System.out.println("demon " + did + " trying to feed someone");
					int fedDid = demonsToBeFeed.deq(); // demon been fed
					
					if (fedDid == this.did) {
						demonsToBeFeed.enq(fedDid);
					} else {
						System.out.println("DEMON " + fedDid + " was just fed by demon " + this.did);
						break;
					}
				} catch (Exception e) {
					// try again
				}
			}
		}
		
	}
	
	private static class UnboundedPartialQueue<T> {
		
		private Lock enqLock;
		private Lock deqLock;

		private Condition notEmptyCondition;
		
		private AtomicInteger size;
		
		private volatile Node<T> head;
		private volatile Node<T> tail;
		
		public UnboundedPartialQueue() {
			enqLock =  new ReentrantLock(true);
			deqLock =  new ReentrantLock(true);
			
			notEmptyCondition = deqLock.newCondition();
			
			size = new AtomicInteger(0);
			
			head = new Node<T>(null);
			tail = head;
		}
		
		public void enq(T value) {
			boolean mustWakeDequeuers = false;
			enqLock.lock();
			
			try {
				Node<T> newNode = new Node<T>(value);
				tail.next = newNode;
				tail = newNode;
				
				if (size.getAndIncrement() == 0) {
					mustWakeDequeuers = true;
				}
			} finally {
				enqLock.unlock();
			}
			
			if (mustWakeDequeuers) {
				deqLock.lock();
				try {
					notEmptyCondition.signalAll();
				} finally {
					deqLock.unlock();
				}
			}
		}

		public T deq() throws InterruptedException {
			T result;
			deqLock.lock();
			
			try {
				while (size.get() == 0) {
					notEmptyCondition.await();
				}
				
				result = head.next.value;
				head = head.next;
				
				size.decrementAndGet();
			} finally {
				deqLock.unlock();
			}
			
			return result;
		}
		
	}
	
	private static class Node<T> {
		public T value;
		public volatile Node<T> next;
		
		public Node(T value) {
			this.value = value;
			this.next = null;
		}
		
	}
	
}
