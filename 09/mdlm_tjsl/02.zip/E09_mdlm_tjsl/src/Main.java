import java.util.concurrent.locks.Lock;

public class Main {
	final static long TIMEOUT = 120000;
	
	static class ThreadIncrement2Mins extends Thread {
		Counter counter;
		public long calls;
		
		public ThreadIncrement2Mins(Counter counter) {
			this.counter = counter;
			this.calls = 0;
		}
		
		public void run() {
			long time = System.currentTimeMillis();
			
			while (System.currentTimeMillis() - time < TIMEOUT) {
				counter.increment();
				calls++;
			}
		}
	}
	
	static class ThreadIncrement1000Times extends Thread {
		Counter counter;
		public long calls;
		
		public ThreadIncrement1000Times(Counter counter) {
			this.counter = counter;
			this.calls = 0;
		}
		
		public void run() {
			for (int i = 0; i < 1000; ++i) {
				counter.increment();
			}
		}
	}
	
	public static void increment2Mins(Lock lock, int n) throws InterruptedException {
		Counter counter = new Counter(lock);
		ThreadIncrement2Mins threads[] = new ThreadIncrement2Mins[n];		
		
		for (int i = 0; i < n; ++i) {
			threads[i] = new ThreadIncrement2Mins(counter);
			threads[i].start();
		}
		
		double median = 0;
		
		for (int i = 0; i < n; ++i) {
			threads[i].join();
			median += threads[i].calls;
		}
		
		System.out.println("Average increments: " + (median / ((double) n)));
		System.out.println("Total increments: " + counter.counter);
	}
	
	public static void increment1000Times(Lock lock, int n) throws InterruptedException {
		Counter counter = new Counter(lock);
		ThreadIncrement1000Times threads[] = new ThreadIncrement1000Times[n];		
		
		long time = System.nanoTime();
		
		for (int i = 0; i < n; ++i) {
			threads[i] = new ThreadIncrement1000Times(counter);
			threads[i].start();
		}
		
		for (int i = 0; i < n; ++i) {
			threads[i].join();
		}
		System.out.println("Elapsed time for running 1000 times: " + (((double)(System.nanoTime() - time)) / 1000000000.0) + "s");
	}
	
	public static void main(String[] args) throws InterruptedException {
		int numThreads[] = {10, 50, 100, 200};
		System.out.println("Using Alock");
		for (int i = 0; i < numThreads.length; ++i) {
			System.out.println("Number of Threads: " + numThreads[i]);
			increment2Mins(new ALock(numThreads[i]), numThreads[i]);
			increment1000Times(new ALock(numThreads[i]), numThreads[i]);
			System.out.println();
		}
	}	
}
