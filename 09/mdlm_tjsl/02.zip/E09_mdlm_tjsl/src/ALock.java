import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class ALock implements Lock {
	ThreadLocal<Integer> mySlotIndex = new ThreadLocal<Integer> (){
		protected Integer initialValue() {
			return 0;
		}
	};
	
	AtomicInteger tail;
	volatile boolean[] flag;
	int size;

	public ALock(int capacity) {
		size = capacity * 4;
		tail = new AtomicInteger(0);
		flag = new boolean[size];
		flag[0] = true;
	}
	
	public void lock() {
		int slot = (tail.getAndIncrement() * 4) % size;
		mySlotIndex.set(slot);
		while (!flag[slot]) {};
	}
	
	public void unlock() {
		int slot = mySlotIndex.get();
		flag[slot] = false;
		flag[(slot + 4) % size] = true;
	}
	
	@Override
	public void lockInterruptibly() throws InterruptedException {
	}
	
	@Override
	public Condition newCondition() {
		return null;
	}
	
	@Override
	public boolean tryLock() {
		return false;
	}
	
	@Override
	public boolean tryLock(long arg0, TimeUnit arg1) throws InterruptedException {
		return false;
	}
}