import java.util.concurrent.locks.Lock;


public class Counter {
	
	long counter;
	Lock lock;
	
	public Counter(Lock lock) {
		this.lock = lock;
	}
	
	public void increment() {
		lock.lock();
		counter++;
		lock.unlock();
	}
	
}
