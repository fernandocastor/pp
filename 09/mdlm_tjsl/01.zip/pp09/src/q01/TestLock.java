package q01;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import q01.backoffs.AdditiveBackoff;
import q01.backoffs.ExponentialBackoff;
import q01.backoffs.IBackoff;
import q01.backoffs.NoBackoff;

public class TestLock {
	public static final long TIMEOUT = 120000;
	private static final int MAX_EXECUTIONS = 1000;

	public static abstract class Incrementer extends Thread {
		protected Lock lock;
		protected Counter counter;

		public Incrementer(Lock lock, Counter counter) {
			this.lock = lock;
			this.counter = counter;
		}
	}

	public static class TimeoutIncrementer extends Incrementer {
		private int executions = 0;

		public TimeoutIncrementer(Lock lock, Counter counter) {
			super(lock, counter);
		}

		@Override
		public void run() {
			long startTime = System.currentTimeMillis();
			while (System.currentTimeMillis() - startTime < TIMEOUT) {
				lock.lock();
				counter.increment();
				lock.unlock();
				executions++;
			}
		}

		public int getExecutions() {
			return executions;
		}
	}
	
	public static class TimesIncrementer extends Incrementer {
		private long elapsedTime;

		public TimesIncrementer(Lock lock, Counter counter) {
			super(lock, counter);
		}
		
		@Override
		public void run() {
			long startTime = System.currentTimeMillis();
			for (int i = 0; i < MAX_EXECUTIONS; i++) {
				lock.lock();
				counter.increment();
				lock.unlock();
			}
			this.elapsedTime = System.currentTimeMillis() - startTime;
		}
		
		public long getElapsedTime() {
			return this.elapsedTime;
		}
	}
	
	public static void executeTest(Incrementer [] threads, int nThreads, Lock lock, Class<?> klass) throws InterruptedException {
		Counter counter = new Counter();
		System.out.println("---- Test using "+nThreads+" threads:");
		for (int i = 0; i < nThreads; i++) {
			if (klass == TimeoutIncrementer.class)
				threads[i] = new TimeoutIncrementer(lock, counter);
			else if (klass == TimesIncrementer.class)
				threads[i] = new TimesIncrementer(lock, counter);
			threads[i].start();
		}

		String units = (klass == TimeoutIncrementer.class ? " executions" : "ms");
		long total = 0;
		for (int i = 0; i < nThreads; i++) {
			threads[i].join();
			long current;
			if (threads[i] instanceof TimeoutIncrementer) {
				current = ((TimeoutIncrementer) threads[i]).getExecutions();
				total += current;
			} else {
				current = ((TimesIncrementer) threads[i]).getElapsedTime();
				total += current;
			}
			System.out.println("----- Thread " + i + ": " + current + units);
		}
		System.out.println("----- Average: " + (total/nThreads) + units);
		System.out.println("----- Counter: " + counter.getCounter());
	}

	public static void main(String[] args) throws InterruptedException {
		Incrementer[] threads = new Incrementer[200];
		
		for (int i = 0; i < 3; i++) { // TASBackoffLock, ReentrantLock or TTASBackoffLock
			Lock lock;
			if (i == 0) {
				System.out.println("- TASBackoffLock");
			} else if (i == 1) {
				System.out.println("- ReentrantLock");
			} else {
				System.out.println("- TTASBackoffLock");
			}
			
			for (int j = 0; j < 2; j++) { // TimeoutIncrementer or TimesIncrementer
				Class<?> incrementerClass;
				if (j == 0) {
					System.out.println("-- Timeout (" + TIMEOUT + "ms)");
					incrementerClass = TimeoutIncrementer.class;
				} else {
					System.out.println("-- Executions limit (" + MAX_EXECUTIONS + " executions)");
					incrementerClass = TimesIncrementer.class;
				}
				
				for (int k = 0; k < 3; k++) { // ExponentialBackoff, NoBackoff or AdditiveBackoff
					IBackoff backoff;
					if (k == 0) {
						System.out.println("--- Exponential backoff");
						backoff = new ExponentialBackoff(1, 1000);
					} else if (k == 1) {
						System.out.println("--- No backoff");
						backoff = new NoBackoff();
					} else {
						System.out.println("--- Additive backoff");
						backoff = new AdditiveBackoff(1, 1000, 10);
					}
					
					if (i == 0)
						lock = new TASBackoffLock(backoff);
					else if (i == 1)
						lock = new ReentrantLock();
					else
						lock = new TTASBackoffLock(backoff);
					
					int [] nThreads = new int[] {10, 50, 100, 200};
					for (int s = 0; s < nThreads.length; s++) {
						executeTest(threads, nThreads[s], lock, incrementerClass);
					}
				}
			}
		}
	}
}
