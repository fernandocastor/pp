package q01.backoffs;
public class NoBackoff implements IBackoff {
	@Override
	public void backoff() throws InterruptedException {
		// No backoff ;)
	}
}
