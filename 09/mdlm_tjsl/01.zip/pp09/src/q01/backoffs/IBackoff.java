package q01.backoffs;
public interface IBackoff {
	public void backoff() throws InterruptedException;
}
