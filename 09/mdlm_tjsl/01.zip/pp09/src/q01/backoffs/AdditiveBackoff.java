package q01.backoffs;
import java.util.Random;

public class AdditiveBackoff implements IBackoff {
	private final int minDelay;
	private final int maxDelay;
	private final int increment;
	private final Random random;
	private int limit;

	public AdditiveBackoff(int min, int max, int increment) {
		this.minDelay = min;
		this.maxDelay = max;
		this.increment = increment;

		this.random = new Random();
		this.limit = minDelay;
	}

	@Override
	public void backoff() throws InterruptedException {
		int delay = random.nextInt(limit);
		limit = Math.min(maxDelay, increment + limit);
		Thread.sleep(delay);
	}
}
