package q01;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

import q01.backoffs.IBackoff;

public class TTASBackoffLock implements Lock {
	private IBackoff backoff;
	AtomicBoolean state = new AtomicBoolean(false);

	public TTASBackoffLock(IBackoff backoff) {
		this.backoff = backoff;
	}

	@Override
	public void lock() {
		while (true) {
			while (state.get()) {};

			if (!state.getAndSet(true)) {
				return;
			} else {
				try {
					backoff.backoff();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	@Override
	public void unlock() {
		state.set(false);
	}

	@Override
	/**
	 * Not implemented!
	 */
	public void lockInterruptibly() throws InterruptedException {
	}

	@Override
	public Condition newCondition() {
		throw new UnsupportedOperationException();
	}

	@Override
	/**
	 * Not implemented!
	 */
	public boolean tryLock() {
		return false;
	}

	@Override
	/**
	 * Not implemented!
	 */
	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		return false;
	}

}
