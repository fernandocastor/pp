package q01;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

import q01.backoffs.IBackoff;

public class TASBackoffLock implements Lock {
	AtomicBoolean state = new AtomicBoolean(false);
	
	private IBackoff backoff;
	
	public TASBackoffLock(IBackoff backoff) {
		this.backoff = backoff;
	}
	
	public void lock() {
		while (true) {
			if (!state.getAndSet(true)) {
				return;
			} else {
				try {
					backoff.backoff();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void unlock() {
		state.set(false);
	}

	@Override
	/**
	 * Not implemented!
	 */
	public void lockInterruptibly() throws InterruptedException {
	}

	@Override
	public Condition newCondition() {
		throw new UnsupportedOperationException();
	}

	@Override
	/**
	 * Not implemented!
	 */
	public boolean tryLock() {
		return false;
	}

	@Override
	/**
	 * Not implemented!
	 */
	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		return false;
	}
}
