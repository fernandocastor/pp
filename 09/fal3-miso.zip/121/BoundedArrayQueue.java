package q121;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedArrayQueue {
	private int enqueueIndex; // �ndice separado para garantir que o enfileiramento ocorra no final
    private int dequeueIndex; // �ndice separado para garantir que o desenfileiramento ocorra no in�cio
    private int[] items;
    private int count;
	ReentrantLock enqueueLock;
	ReentrantLock dequeueLock;
	Condition notEmptyCondition;
	Condition notFullCondition;
	AtomicInteger size;
	int capacity;
	
	public BoundedArrayQueue(int _capacity) {
		capacity = _capacity;
		enqueueIndex = 0;
        dequeueIndex = 0;
        items = new int[capacity];
		size = new AtomicInteger(0);
		enqueueLock = new ReentrantLock();
		notFullCondition = enqueueLock.newCondition();
		dequeueLock = new ReentrantLock();
		notEmptyCondition = dequeueLock.newCondition();
	}

	public void enqueue(int value) throws InterruptedException {
		boolean mustWakeDequeuers = false;
		enqueueLock.lock();
		try {
			while (size.get() == capacity)
				notFullCondition.await();
			items[enqueueIndex] = value;
	        enqueueIndex = ++enqueueIndex == items.length ? 0 : enqueueIndex; // Verifica se � poss�vel incrementar, caso sim, retorna o valor incrementado, sen�o, retorna 0 (in�cio do array)
			if (size.getAndIncrement() == 0)
				mustWakeDequeuers = true;
		} finally {
			enqueueLock.unlock();
		}
		if (mustWakeDequeuers) {
			dequeueLock.lock();
			try {
				notEmptyCondition.signalAll();
			} finally {
				dequeueLock.unlock();
			}
		}
	}

	public int dequeue() throws InterruptedException {
		int element;
		boolean mustWakeEnqueuers = false;
		dequeueLock.lock();
		try {
			while (size.get() == 0)
				notEmptyCondition.await();
			int item = items[dequeueIndex];
	        items[dequeueIndex] = 0;
	        dequeueIndex = ++dequeueIndex == items.length ? 0 : dequeueIndex; // Verifica se � poss�vel incrementar, caso sim, retorna o valor incrementado, sen�o, retorna 0 (in�cio do array)
	        element = item;
			if (size.getAndDecrement() == capacity) {
				mustWakeEnqueuers = true;
			}
		} finally {
			dequeueLock.unlock();
		}
		if (mustWakeEnqueuers) {
			enqueueLock.lock();
			try {
				notFullCondition.signalAll();
			} finally {
				enqueueLock.unlock();
			}
		}
		return element;
	}

}

