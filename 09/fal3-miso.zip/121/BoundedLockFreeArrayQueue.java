package q121;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedLockFreeArrayQueue<T> {
	private int enqIndex; // �ndice separado para garantir que o enfileiramento ocorra no final
    private int deqIndex; // �ndice separado para garantir que o desenfileiramento ocorra no in�cio
    private int[] items;
    private int count;
	ReentrantLock enqLock, deqLock;
	Condition notEmptyCondition, notFullCondition;
	AtomicInteger size;
	int capacity;
	
	public BoundedLockFreeArrayQueue(int _capacity) {
		capacity = _capacity;
		enqIndex = 0;
        deqIndex = 0;
        items = new int[capacity];
		size = new AtomicInteger(0);
		enqLock = new ReentrantLock();
		notFullCondition = enqLock.newCondition();
		deqLock = new ReentrantLock();
		notEmptyCondition = deqLock.newCondition();
	}

	public void enq(T x) throws InterruptedException {
		boolean mustWakeDequeuers = false;
		enqLock.lock();
		try {
			while (size.get() == capacity)
				notFullCondition.await();
			items[enqIndex] = (Integer) x;
	        enqIndex = ++enqIndex == items.length ? 0 : enqIndex; // Verifica se � poss�vel incrementar, caso sim, retorna o valor incrementado
			if (size.getAndIncrement() == 0)
				mustWakeDequeuers = true;
		} finally {
			enqLock.unlock();
		}
		if (mustWakeDequeuers) {
			deqLock.lock();
			try {
				notEmptyCondition.signalAll();
			} finally {
				deqLock.unlock();
			}
		}
	}

	public int deq() throws InterruptedException {
		int result;
		boolean mustWakeEnqueuers = false;
		deqLock.lock();
		try {
			while (size.get() == 0)
				notEmptyCondition.await();
			int item = items[deqIndex];
	        items[deqIndex] = 0;
	        deqIndex = ++deqIndex == items.length ? 0 : deqIndex; // Verifica se � poss�vel incrementar, caso sim, retorna o valor incrementado
	        result = item;
			if (size.getAndDecrement() == capacity) {
				mustWakeEnqueuers = true;
			}
		} finally {
			deqLock.unlock();
		}
		if (mustWakeEnqueuers) {
			enqLock.lock();
			try {
				notFullCondition.signalAll();
			} finally {
				enqLock.unlock();
			}
		}
		return result;
	}

}

