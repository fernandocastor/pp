package q121;

public class BoundedLockFreeArrayQueue {
	private volatile int enqueueIndex; // �ndice separado para garantir que o enfileiramento ocorra no final
	private volatile int dequeueIndex; // �ndice separado para garantir que o desenfileiramento ocorra no in�cio
	private int[] items;
	int capacity;

	public BoundedLockFreeArrayQueue(int capacity) {
		this.capacity = capacity;
		enqueueIndex = 0;
		dequeueIndex = 0;
		items = new int[this.capacity];
	}

	public boolean enqueue(int value) throws InterruptedException {
		int currentReadIndex; 
		int currentWriteIndex; 

		do {
			currentReadIndex = this.dequeueIndex;
			currentWriteIndex = this.enqueueIndex;
			if (countToIndex(currentWriteIndex + 1) == countToIndex(currentReadIndex))
			{
				// Fila cheia
				return false;
			}
		} while (compareAndSwap(this.enqueueIndex, currentWriteIndex, (currentWriteIndex + 1)) == this.enqueueIndex);

		items[currentWriteIndex] = value;
		
		return true;
	}

	public int dequeue() throws InterruptedException {
		int currentMaximumReadIndex;
        int currentReadIndex;
        
        int element;

        do
        {
        	currentReadIndex = this.dequeueIndex;
        	currentMaximumReadIndex = this.enqueueIndex;

            if (countToIndex(currentReadIndex) == 
                countToIndex(currentMaximumReadIndex))
            {
                // a fila est� vazia ou
                // uma thread produtora alocou espa�o na fila
        		// mas est� aguardando para commitar a inser��o
                return 0;
            }

            // recupera o elemento a ser removido da lista
            element = items[countToIndex(currentReadIndex)];

            // tenta executar a opera��o de compareAndSwap na �ndice de leitura. Se obtiver sucesso,
            // element j� cont�m o que readIndex possui antes de ser incrementado.
            if (compareAndSwap(this.dequeueIndex, currentReadIndex, (currentReadIndex + 1)) != 1)
            {
                return element;
            }

            // it failed retrieving the element off the queue. Someone else must
            // have read the element stored at countToIndex(currentReadIndex)
            // before we could perform the CAS operation        

        } while(1==1); // keep looping to try again!
	}

	public synchronized int getDequeueValue() { return items[dequeueIndex]; }
	public synchronized int getEnqueueValue() { return items[enqueueIndex]; }

	public synchronized int compareAndSwap(int value, int expectedValue, int newValue) {
		int oldValue = value;
		if (value == expectedValue) {
			value = newValue;
			return 1;
		}
		return oldValue;
	}

	public synchronized int countToIndex(int index) {
		if (index == items.length)
			return 0;
		else
			return dequeueIndex;
	}

}



