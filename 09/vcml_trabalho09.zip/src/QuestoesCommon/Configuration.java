package QuestoesCommon;

public class Configuration {

	public static final int NUMBER_THREADS = 200;
	public static final int NUMBER_COUNTERS = 1;
	public static final int MIN_DELAY = 10;
	public static final int MAX_DELAY= 100;
	public static final int INCREMENT_DELAY = 10;
	public static final int TIME_EXECUTION = 120000;
	
}
