package QuestoesCommon;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Counter {

	private long counter = 0;
	private int id;
	private Lock lock;
	
	public Counter(int id, Lock lock) {
		this.id = id;		
		this.lock = lock;
	}
	
	public void incrementa() {
		this.lock.lock();
		try
		{
			this.counter++;
		}
		finally
		{
			this.lock.unlock();
		}
	}

	@Override
	public String toString() {
		return counter + "";
	}
}
