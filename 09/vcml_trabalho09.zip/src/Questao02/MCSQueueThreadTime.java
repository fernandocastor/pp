package Questao02;

import QuestoesCommon.Configuration;
import QuestoesCommon.Counter;


public class MCSQueueThreadTime extends Thread {

	private Counter[] contadores = null;
	private double count = 0;
	private int id;
	private long startedTime;

	public MCSQueueThreadTime(long startedTime, Counter[] c, int id) {
		this.contadores = c;
		this.id = id;
		this.startedTime = startedTime;
	}

	
	@Override
	public void run() {

		while (System.currentTimeMillis() - startedTime <= Configuration.TIME_EXECUTION)
		{
			// int random = rnd.nextInt(contadores.length);
			// this.contadores[random].incrementa();
			this.contadores[0].incrementa();			
			this.count++;
		}
	}
	
	@Override
	public String toString() {
		return "T" + id + "->" + count;
	}
}
