package Questao02.Results;

import java.util.ArrayList;
import java.util.List;

import Questao01.Threads.BackoffThreadCount;
import Questao02.MCSLock;
import Questao02.MCSQueueThreadCount;
import Questao02.MCSQueueThreadTime;
import QuestoesCommon.Configuration;
import QuestoesCommon.Counter;

public class ResultsByTime {

	private static StringBuilder excelAnalysisCount = new StringBuilder();

	public static void Execute() {

		long startTime;
		long stopTime;
		long elapsedTime;

		int[] lst = new int[] { 50, 100, 200 };

		for (int idx = 0; idx < lst.length; idx++) {
			System.out.println(">>> #Threads " + lst[idx]);
			System.out.println();
			for (int execution = 1; execution <= 3; execution++) {

				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new MCSLock());
					}

					List<MCSQueueThreadTime> threads = new ArrayList<MCSQueueThreadTime>();

					for (int i = 0; i < lst[idx]; i++) {
						threads.add(new MCSQueueThreadTime(System
								.currentTimeMillis(), contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (MCSQueueThreadTime thread : threads) {
						thread.start();
					}

					for (MCSQueueThreadTime thread : threads) {
						thread.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "MCSLock", contadores, threads,
							elapsedTime);
					// printThreadResults(threads);

				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}

		System.out.println();
		System.out.println("for csv purpose");
		System.out.println(excelAnalysisCount);
	}

	public static void printThreadResults(List<MCSQueueThreadTime> threads) {
		// System.out.println("thread results: " + threads);
	}

	public static void printResults(int execution, String tipo,
			Counter[] contadores, List<MCSQueueThreadTime> threads, long time) {

		String s = "";
		for (int i = 0; i < contadores.length; i++) {
			s = s + contadores[i] + "; ";
		}
		// System.out.println("counter results: " + s);

		System.out.println("Type:" + tipo + " /Number of Threads:"
				+ Configuration.NUMBER_THREADS + " /Execution:" + execution
				+ " /Time: " + time);
		for (int i = 0; i < threads.size(); i++) {
			System.out.print(threads.get(i).toString() + ";");
		}
		System.out.println();
		System.out.println();
		excelAnalysisCount.append(tipo + ";" + execution + ";"
				+ Configuration.NUMBER_THREADS + ";" + time + "\n");

	}

}
