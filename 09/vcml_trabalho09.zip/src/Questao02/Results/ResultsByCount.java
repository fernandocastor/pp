package Questao02.Results;

import java.util.ArrayList;
import java.util.List;

import Questao01.Threads.BackoffThreadCount;
import Questao02.MCSLock;
import Questao02.MCSQueueThreadCount;
import QuestoesCommon.Configuration;
import QuestoesCommon.Counter;

public class ResultsByCount {

	private static StringBuilder excelAnalysisCount = new StringBuilder();

	public static void Execute() {

		long startTime;
		long stopTime;
		long elapsedTime;

		int[] lst = new int[] { 50, 100, 200 };

		for (int idx = 0; idx < lst.length; idx++) {
			System.out.println(">>> #Threads " + lst[idx]);
			System.out.println();
			for (int execution = 1; execution <= 3; execution++) {

				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new MCSLock());
					}

					List<MCSQueueThreadCount> threads = new ArrayList<MCSQueueThreadCount>();

					for (int i = 0; i < lst[idx]; i++) {
						threads.add(new MCSQueueThreadCount(contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (MCSQueueThreadCount thread : threads) {
						thread.start();
					}

					for (MCSQueueThreadCount thread : threads) {
						thread.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "MCSLock", contadores, threads,
							elapsedTime);
					// printThreadResults(threads);

				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println();
		System.out.println("for csv purpose");
		System.out.println(excelAnalysisCount);
	}

	public static void printThreadResults(List<MCSQueueThreadCount> threads) {
		// System.out.println("thread results: " + threads);
	}

	public static void printResults(int execution, String tipo,
			Counter[] contadores, List<MCSQueueThreadCount> threads, long time) {

		String s = "";
		for (int i = 0; i < contadores.length; i++) {
			s = s + contadores[i] + "; ";
		}
		// System.out.println("counter results: " + s);

		System.out.println("Type:" + tipo + " /Number of Threads:"
				+ Configuration.NUMBER_THREADS + " /Execution:" + execution
				+ " /Time: " + time);
		// for (int i = 0; i < threads.size(); i++) {
		// System.out.print(threads.get(i).toString() + ";");
		// }
		// System.out.println();
		// System.out.println();
		excelAnalysisCount.append(tipo + ";" + execution + ";"
				+ Configuration.NUMBER_COUNTERS + ";" + time + "\n");

	}

}
