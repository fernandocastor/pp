package Questao02;

import Questao02.Results.ResultsByCount;
import Questao02.Results.ResultsByTime;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ResultsByTime.Execute();
		//ResultsByCount.Execute();
		
	}

}
