package Questao02;

import QuestoesCommon.Counter;


public class MCSQueueThreadCount extends Thread {

	private Counter[] contadores = null;
	private double count = 0;
	private int id;

	public MCSQueueThreadCount(Counter[] c, int id) {
		this.contadores = c;
		this.id = id;
	}


	@Override
	public void run() {

		while (this.count < 1000)
		{
			// int random = rnd.nextInt(contadores.length);
			// this.contadores[random].incrementa();
			this.contadores[0].incrementa();			
			this.count++;
		}
	}
	
	@Override
	public String toString() {
		return "T" + id + "->" + count;
	}
}
