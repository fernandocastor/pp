package Questao01.Threads;
import java.util.Random;

import QuestoesCommon.Configuration;
import QuestoesCommon.Counter;

public class BackoffThreadTime extends Thread {

	private Counter[] contadores = null;	
	private int id;
	private long count = 0;
	private Random rnd;
	private long startedTime;

	public BackoffThreadTime(long startedtime, Counter[] c, int id) {
		this.startedTime = startedtime;
		this.contadores = c;
		this.id = id;
		this.rnd = new Random();
	}

	// Considere que a escolha do objeto a partir do qual cada thread fara o incremento eh aleatoria	
	@Override
	public void run() {		
		while (System.currentTimeMillis() - startedTime <= Configuration.TIME_EXECUTION)
		{
			int random = rnd.nextInt(contadores.length);
			this.contadores[random].incrementa();
			count++;
		}
	}	
	
	@Override
	public String toString() {
		return "Thread " + id + ": " + count;
	}
	
	public long getCount() {
		return count;
	}
	
}
