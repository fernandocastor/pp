package Questao01.Threads;
import java.util.Random;

import QuestoesCommon.Counter;

public class BackoffThreadCount extends Thread {

	private Counter[] contadores = null;
	private long count = 0;
	private int id;
	private Random rnd;

	public BackoffThreadCount(Counter[] c, int id) {
		this.contadores = c;
		this.id = id;
		this.rnd = new Random();
	}
	
	@Override
	public void run() {

		while (this.count < 1000)
		{
			// int random = rnd.nextInt(contadores.length);
			this.contadores[0].incrementa();
			this.count++;
		}
	}	
	
	@Override
	public String toString() {
		return " T" + (id+1) + ":" + count;
	}
	
}
