package Questao01;

import Questao01.Results.ResultsByCount;
import Questao01.Results.ResultsByTime;

public class Main {

	public static void main(String[] args) {

		ResultsByCount.Execute();
		// ResultsByTime.Execute();
	}

}
