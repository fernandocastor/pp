package Questao01;

import java.util.Random;

import QuestoesCommon.Configuration;

// Figure 7.5
public class Backoff {	

	private final int minDelay, maxDelay, increment;
	private int limit;

	private final Random random;

	public Backoff() {
		this.minDelay = Configuration.MIN_DELAY;
		this.maxDelay = Configuration.MAX_DELAY;
		this.increment = Configuration.INCREMENT_DELAY;
		this.limit = minDelay;
		random = new Random();
	}

	public void exponentialBackoff() throws InterruptedException {
		int delay = this.random.nextInt(this.limit);
		this.limit = Math.min(this.maxDelay, 2 * this.limit);
		try {
			Thread.sleep(delay);
		} catch (InterruptedException ex){
			
		}
	}

	public void additiveBackoff() throws InterruptedException {
		int delay = this.random.nextInt(this.limit);
		this.limit = Math.min(this.maxDelay, increment + this.limit);
		try {
			Thread.sleep(delay);
		} catch (InterruptedException ex){
			
		}
	}
}
