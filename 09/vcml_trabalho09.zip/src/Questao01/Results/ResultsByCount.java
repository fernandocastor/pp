package Questao01.Results;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import Questao01.Locks.TASLock;
import Questao01.Locks.TTASAddBackoffLock;
import Questao01.Locks.TTASExpBackoffLock;
import Questao01.Locks.TTASLock;
import Questao01.Threads.BackoffThreadCount;
import QuestoesCommon.Configuration;
import QuestoesCommon.Counter;

public class ResultsByCount {

	static StringBuilder excelAnalysisCount = new StringBuilder();

	public static void Execute() {

		long startTime;
		long stopTime;
		long elapsedTime;
		int[] nThreads = new int[] { 10, 50, 100, 200 };

		for (int execution = 1; execution <= 1; execution++) {
			for (int n = 0; n < nThreads.length; n++) {			
				//
				// ReentrantLock
				//
				try {

					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new ReentrantLock());
					}

					List<BackoffThreadCount> threads = new ArrayList<BackoffThreadCount>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadCount(contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadCount test : threads) {
						test.start();
					}

					for (BackoffThreadCount test : threads) {
						test.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "ReentrantLock", nThreads[n], contadores,
							threads, elapsedTime);
					// printThreadResults(threads);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				//
				// TASLock
				//
				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new TASLock());
					}

					List<BackoffThreadCount> threads = new ArrayList<BackoffThreadCount>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadCount(contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadCount test : threads) {
						test.start();
					}

					for (BackoffThreadCount test : threads) {
						test.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "TASLock", nThreads[n], contadores, threads,
							elapsedTime);
					// printThreadResults(threads);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				//
				// TTASLock
				//
				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new TTASLock());
					}

					List<BackoffThreadCount> threads = new ArrayList<BackoffThreadCount>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadCount(contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadCount test : threads) {
						test.start();
					}

					for (BackoffThreadCount test : threads) {
						test.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "TTASLock", nThreads[n], contadores, threads,
							elapsedTime);
					// printThreadResults(threads);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				//
				// TTASAddBackoffLock
				//
				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new TTASAddBackoffLock());
					}

					List<BackoffThreadCount> threads = new ArrayList<BackoffThreadCount>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadCount(contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadCount test : threads) {
						test.start();
					}

					for (BackoffThreadCount test : threads) {
						test.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "TTASAddBackoffLock", nThreads[n], contadores,
							threads, elapsedTime);
					// printThreadResults(threads);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

				//
				// TTASExpBackoffLock
				//
				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new TTASExpBackoffLock());
					}

					List<BackoffThreadCount> threads = new ArrayList<BackoffThreadCount>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadCount(contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadCount test : threads) {
						test.start();
					}

					for (BackoffThreadCount test : threads) {
						test.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "TTASExpBackoffLock", nThreads[n], contadores, 
							threads, elapsedTime);
					// printThreadResults(threads);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}
		System.out.println();
		// System.out.println("for csv purpose");
		// System.out.println(excelAnalysisCount);

	}

	public static void printThreadResults(List<BackoffThreadCount> threads) {
		System.out.println("thread results: " + threads);
	}

	public static void printResults(int execution, String tipo, int nThreads,
			Counter[] contadores, List<BackoffThreadCount> threads, long time) {

		// System.out.println("counter results: " + s);

		System.out.println("Type:" + tipo + " /Number of Threads:"
				+ nThreads + " /Execution:" + execution
				+ " /Time: " + time);
		for (int i = 0; i < threads.size(); i++) {
			// System.out.println(threads.get(i).toString() + ";");
		}

		for (int i = 0; i < contadores.length; i++) {
			System.out.println("Final count: " + contadores[0]);
		}

		System.out.println();
		excelAnalysisCount.append(tipo + ";" + execution + ";"
				+ Configuration.NUMBER_COUNTERS + ";" + time + "\n");

	}

}
