package Questao01.Results;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import Questao01.Locks.TASLock;
import Questao01.Locks.TTASAddBackoffLock;
import Questao01.Locks.TTASExpBackoffLock;
import Questao01.Locks.TTASLock;
import Questao01.Threads.BackoffThreadCount;
import Questao01.Threads.BackoffThreadTime;
import QuestoesCommon.Configuration;
import QuestoesCommon.Counter;

public class ResultsByTime {

	static StringBuilder excelAnalysisTime = new StringBuilder();

	public static void Execute() {

		long startTime;
		long stopTime;
		long elapsedTime;

		int[] nThreads = new int[] { 10, 50, 100, 200 };

		for (int execution = 1; execution <= 3; execution++) {

			for (int n = 0; n < nThreads.length; n++) {

				//
				// ReentrantLock
				//
				try {

					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new ReentrantLock());
					}

					List<BackoffThreadTime> threads = new ArrayList<BackoffThreadTime>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadTime(System
								.currentTimeMillis(), contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadTime thread : threads) {
						thread.start();
					}

					for (BackoffThreadTime thread : threads) {
						thread.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "ReentrantLock", nThreads[n], contadores,
							threads, elapsedTime);
					// printThreadResults(threads);
				} catch (Exception e) {
					e.printStackTrace();
				}

				//
				// TASLock
				//
				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new TASLock());
					}

					List<BackoffThreadTime> threads = new ArrayList<BackoffThreadTime>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadTime(System
								.currentTimeMillis(), contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadTime thread : threads) {
						thread.start();
					}

					for (BackoffThreadTime thread : threads) {
						thread.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "TASLock", nThreads[n], contadores, threads,
							elapsedTime);
					// printThreadResults(threads);
				} catch (Exception e) {
					e.printStackTrace();
				}

				//
				// TTASLock
				//
				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new TTASLock());
					}

					List<BackoffThreadTime> threads = new ArrayList<BackoffThreadTime>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadTime(System
								.currentTimeMillis(), contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadTime thread : threads) {
						thread.start();
					}

					for (BackoffThreadTime thread : threads) {
						thread.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "TTASLock", nThreads[n], contadores, threads,
							elapsedTime);
					// printThreadResults(threads);
				} catch (Exception e) {
					e.printStackTrace();
				}

				//
				// TTASAddBackoffLock
				//
				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new TTASAddBackoffLock());
					}

					List<BackoffThreadTime> threads = new ArrayList<BackoffThreadTime>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadTime(System
								.currentTimeMillis(), contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadTime thread : threads) {
						thread.start();
					}

					for (BackoffThreadTime thread : threads) {
						thread.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "TTASAddBackoffLock", nThreads[n], contadores,
							threads, elapsedTime);
					// printThreadResults(threads);
				} catch (Exception e) {
					e.printStackTrace();
				}

				//
				// TTASExpBackoffLock
				//
				try {
					Counter[] contadores = new Counter[Configuration.NUMBER_COUNTERS];
					for (int i = 0; i < contadores.length; i++) {
						contadores[i] = new Counter(i, new TTASExpBackoffLock());
					}

					List<BackoffThreadTime> threads = new ArrayList<BackoffThreadTime>();
					for (int i = 0; i < nThreads[n]; i++) {
						threads.add(new BackoffThreadTime(System
								.currentTimeMillis(), contadores, i));
					}

					startTime = System.currentTimeMillis();

					for (BackoffThreadTime thread : threads) {
						thread.start();
					}

					for (BackoffThreadTime thread : threads) {
						thread.join();
					}

					stopTime = System.currentTimeMillis();
					elapsedTime = stopTime - startTime;

					printResults(execution, "TTASExpBackoffLock", nThreads[n], contadores,
							threads, elapsedTime);
					// printThreadResults(threads);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println();
		// System.out.println("for csv purpose");
		// System.out.println(excelAnalysisTime);

	}

	public static void printThreadResults(List<BackoffThreadTime> threads) {
		System.out.println("thread results: " + threads);
	}

	public static void printResults(int execution, String tipo, int numThreads, 
			Counter[] contadores, List<BackoffThreadTime> threads, long time) {

		double sum = 0;
		double avg = 0;
		long max = threads.get(0).getCount();
		long min = threads.get(0).getCount();
		long tmpValue = 0;

		System.out.println("Type:" + tipo + " /Number of Threads:"
				+ numThreads + " /Execution:" + execution
				+ " /Time: " + time);
		for (int i = 0; i < threads.size(); i++) {
			System.out.println(threads.get(i).toString() + ";");
			tmpValue = threads.get(i).getCount();
			sum = sum + tmpValue;

			if (tmpValue < min) {
				min = tmpValue;
			}

			if (tmpValue > max) {
				max = tmpValue;
			}
		}

		avg = sum /numThreads;

		for (int i = 0; i < contadores.length; i++) {
			System.out.println("Total count: " + contadores[0]);
		}
		System.out.println("Avarage count: " + avg);
		System.out.println("Max count: " + max);
		System.out.println("Min count: " + min);

		System.out.println();

		excelAnalysisTime.append(tipo + ";" + execution + ";"
				+ Configuration.NUMBER_COUNTERS + ";" + time + "\n");

	}

}
