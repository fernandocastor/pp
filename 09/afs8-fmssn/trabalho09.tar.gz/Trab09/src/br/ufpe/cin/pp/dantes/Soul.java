package br.ufpe.cin.pp.dantes;

public class Soul extends Thread {

	private boolean fed;

	public Soul(boolean fed_) {
		this.fed = fed_;
	}

	@Override
	public void run() {

		while (true) {
			if (this.fed) {

				// feeding others
				try {
					Inferno.queue.put("food");
					this.fed = false;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} else {

				// being fed
				try {
					Object o = Inferno.queue.take();

					System.out.println("Soul " + this.getId() + " ate " + o);
					this.fed = true;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}
}
