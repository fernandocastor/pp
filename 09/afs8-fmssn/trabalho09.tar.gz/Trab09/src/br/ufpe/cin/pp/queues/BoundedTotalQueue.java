package br.ufpe.cin.pp.queues;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedTotalQueue {

	Lock headLock;
	Lock tailLock;

	volatile int head;
	volatile int tail;

	Object[] items;

	public BoundedTotalQueue(int capacity) {

		items = new Object[capacity];
		head = tail = 0;
		headLock = new ReentrantLock();
		tailLock = new ReentrantLock();

	}

	public void enq(Object o) throws Exception {

		tailLock.lock();

		try {

			if (tail - head == items.length) {
				throw new Exception("full queue");
			}
			items[tail % items.length] = o;
			tail++;

		} finally {
			tailLock.unlock();
		}

	}

	public Object deq() throws Exception {

		headLock.lock();
		
		try{
			
			if(tail-head==0){
				throw new Exception("empty queue");
			}
			Object o = items[head%items.length];
			head++;
			return o;
		}
		finally{
			headLock.unlock();
		}
		
	}
}
