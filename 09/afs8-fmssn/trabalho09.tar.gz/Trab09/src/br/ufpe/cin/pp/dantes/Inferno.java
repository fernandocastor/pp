package br.ufpe.cin.pp.dantes;

import java.util.LinkedList;
import java.util.concurrent.SynchronousQueue;

public class Inferno {

	/** look up the SynchronousQueue implementation */
	public static final SynchronousQueue<Object> queue = new SynchronousQueue<Object>(
			true);

	public static void main(String[] args) {

		LinkedList<Soul> s = new LinkedList<Soul>();
		for (int i = 0; i < 10; i++) {
			s.add(new Soul(true));
			s.add(new Soul(false));
		}

		for (Soul x : s) {
			x.start();
		}

	}
}
