package br.ufpe.cin.pp.queues;

import java.util.concurrent.atomic.AtomicStampedReference;

public class LockFreeBoundedTotalQueue {

	AtomicStampedReference<Integer> headSR;
	AtomicStampedReference<Integer> tailSR;

	Object[] items;

	public LockFreeBoundedTotalQueue(int capacity) {
		items = new Object[capacity];
		headSR = new AtomicStampedReference<Integer>(0, 0);
		tailSR = new AtomicStampedReference<Integer>(0, 0);
	}

	public void enq(Object o) throws Exception {
		while (true) {
			int[] headStamp = { 0 };
			int[] tailStamp = { 0 };
			Integer tail;

			if ((tail = tailSR.get(tailStamp)) - headSR.get(headStamp) == items.length) {
				throw new Exception("Full queue.");
			}

			if (tailSR
					.compareAndSet(tail, tail, tailStamp[0], tailStamp[0] + 1)) {

				items[tail % items.length] = o;

				if (tailSR.compareAndSet(tail, tail + 1, tailStamp[0] + 1,
						tailStamp[0] + 2)) {
					return;
				}
			}
		}
	}

	public Object deq() throws Exception {
		while (true) {
			int[] headStamp = { 0 };
			int[] tailStamp = { 0 };
			Integer head;

			if (tailSR.get(tailStamp) - (head = headSR.get(headStamp)) == 0) {
				throw new Exception("Empty queue.");
			}

			// if this doesn't work, someone has already moved either head or
			// stamp
			if (headSR
					.compareAndSet(head, head, headStamp[0], headStamp[0] + 1)) {

				Object o = items[head % items.length];

				// here too. If someone moved either, 'o' might be invalid.
				if (headSR.compareAndSet(head, head + 1, headStamp[0] + 1,
						headStamp[0] + 2)) {
					return o;
				}
			}
		}
	}

}
