import java.util.concurrent.locks.Lock;


public class SimpleCounter {
	private static long[] counter = new long[10];
	private static Lock locker = new TASLock();
	public static  void incrementar(int pos){
		locker.lock();
		counter[pos]++;
		locker.unlock();
	}

}
