import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class LockStrategy {
	

	private final static int THREADS = 10;
	private SimpleCounter counter;
	
	public LockStrategy() throws InterruptedException, ExecutionException{
		ExecutorService pool = Executors.newFixedThreadPool(THREADS);

			for (int i = 0; i < THREADS; i++) {
				Future<Long> future = pool.submit(new MyThread());
			}
			
			pool.shutdownNow();
			
			
	}
	class MyThread implements Callable<Long> {
		private ThreadLocal<Long> myInternalCounter;
		
		public  MyThread() {
			myInternalCounter = new ThreadLocal<Long>(){
				@Override 
				protected Long initialValue(){
					return new Long(0);
				}
			};
			
		}
		@Override
		public Long call() throws Exception {
			// TODO Auto-generated method stub
			long tid = Thread.currentThread().getId();
			long startTime = System.currentTimeMillis(); //fetch starting time
			//10000 - 10Segs
			while(false||(System.currentTimeMillis()-startTime)<10000){
			//for(int i=0; i<1000;i++){		
					
		    		SimpleCounter.incrementar(1);
		    		
				
				myInternalCounter.set(myInternalCounter.get()+1);
			//}
			}
			//System.out.println("T"+Thread.currentThread().getId()+"COUNTER: "+counter);
			System.out.println("T"+Thread.currentThread().getId()+": "+myInternalCounter.get());
			return myInternalCounter.get();
			
			
		}
		
	  }
	
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		LockStrategy mp = new LockStrategy();
	}


}
