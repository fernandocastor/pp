package boundedLockQueue;

import java.util.LinkedList;
import java.util.List;




public class TestBoundedLockQueue implements Runnable{
	private static final int NUMBER_OF_THREADS = 10;
	
	static BoundedLockFreeQueue<Integer> blq = new BoundedLockFreeQueue<Integer>(100);
	
	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("Inicio" + blq.toString());
		
		List<Thread> threads = new LinkedList<Thread>();
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {			
			threads.add(new Thread(new TestBoundedLockQueue()));
			threads.get(i).start();
		}
		
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {
			threads.get(i).join();
		}
		System.out.println("Final: " + blq.toString());

		
	}
	
	
	
	
	@Override
	public void run() {
		//for (int i = 0; i < 10; i++) {
			int x = (int)(Math.random()*100);
			if(x%2 == 0.0){
				System.out.println("Enq-" +  Thread.currentThread().getName());
				blq.enq(x);
			} else {
				System.out.println("Deq-" +  Thread.currentThread().getName());
				blq.deq();
			}
	//	}
	}
	
	

}

class Pessoa{
	int idade;

	public Pessoa(int idade) {
		super();
		this.idade = idade;
	}
	
}
