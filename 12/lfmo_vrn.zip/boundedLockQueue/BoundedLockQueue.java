package boundedLockQueue;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedLockQueue<T> {

	private T elements[];
	private AtomicInteger head, tail;
	private ReentrantLock enqLock, deqLock;

	public BoundedLockQueue(int capacity) {
		super();
		elements = (T[])new Object[capacity];
		head = new AtomicInteger(0);
		tail = new AtomicInteger(0);
		enqLock = new ReentrantLock();
		deqLock = new ReentrantLock();
	}

	public void enq(T x) {
		enqLock.lock();
		try {
			while (tail.get() - head.get() == elements.length) {}
			elements[tail.get() % elements.length] = x;
			tail.getAndIncrement();
		} finally {
			enqLock.unlock();
		}
	}

	public T deq() {
		deqLock.lock();
		T x;
		try {
			while (tail.get() - head.get() == 0) {}
			x = elements[head.get() % elements.length];
			head.getAndIncrement();
		} finally {
			deqLock.unlock();
		}
		return x;
		
	}

	@Override
	public String toString() {
		String e = "";
		for (T i : elements) {
			e = e + "->" + i;
		}
		return e;
	}


	
	
	

}
