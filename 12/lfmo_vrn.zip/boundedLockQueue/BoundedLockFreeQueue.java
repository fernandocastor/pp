package boundedLockQueue;

import java.util.concurrent.atomic.AtomicInteger;

public class BoundedLockFreeQueue<T> {

	private T elements[];
	private AtomicInteger head, tail;

	@SuppressWarnings("unchecked")
	public BoundedLockFreeQueue(int capacity) {
		super();
		elements = (T[]) new Object[capacity];
		head = new AtomicInteger(0);
		tail = new AtomicInteger(0);
	}

	public void enq(T x) {
		while (true) {
			int t = tail.get();
			if (tail.get() - head.get() < elements.length) { // Não entra caso esteja cheio [Threads opostas]
				if (tail.compareAndSet(t, t + 1)) { // Não entra caso alguém tenha alterado tail [Threads "concorrentes"]
					elements[t % elements.length] = x;
					return;
				}
			}
		}
	}

	public T deq() {
		T x;
		while (true) {
			int h = head.get();
			if (tail.get() - head.get() > 0) { // Não entra caso esteja vazio...
				if(head.compareAndSet(h, h+1)){ // Não entra caso alguém alterado head antes
					x = elements[h % elements.length];
					return x;
				}
			}
		}
	}

	@Override
	public String toString() {
		String e = "";
		for (T i : elements) {
			e = e + "->" + i;
		}
		return e;
	}

}
