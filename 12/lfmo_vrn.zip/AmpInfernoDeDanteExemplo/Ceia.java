package AmpInfernoDeDanteExemplo;

import java.util.LinkedList;
import java.util.List;


/**
Exercise 123. In Dante’s Inferno, he describes a visit to Hell. In a very recently
discovered chapter, he encounters five people sitting at a table with a pot of stew
in the middle. Although each one holds a spoon that reaches the pot, each spoon’s
handle is much longer than each person’s arm, so no one can feed him- or herself.
They are famished and desperate.
Dante then suggests “why do not you feed one another?”
The rest of the chapter is lost.
1. Write an algorithm to allow these unfortunates to feed one another. Two or
more people may not feed the same person at the same time. Your algorithm
must be, well, starvation-free.

2. Discuss the advantages and disadvantages of your algorithm. Is it centralized,
decentralized, high or low in contention, deterministic or randomized?

 * @author leofernandesmo
 *
 */
public class Ceia implements Runnable{
	private static final int NUMBER_OF_THREADS = 10000;
	static LinkedList<Pessoa> pessoas = new LinkedList<Pessoa>();
	
	public static void main(String[] args) throws InterruptedException {
		pessoas.add(new Pessoa(1));
		pessoas.add(new Pessoa(2));
		pessoas.add(new Pessoa(3));
		pessoas.add(new Pessoa(4));
		pessoas.add(new Pessoa(5));
		
		//Inicia contagem...
		long startTime = System.currentTimeMillis();
		List<Thread> threads = new LinkedList<Thread>();
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {			
			threads.add(new Thread(new Ceia(), ""+i));
			threads.get(i).start();
		}
		
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {
			threads.get(i).join();
		}
		long finishTime = System.currentTimeMillis();
		
		imprimeStatusPessoas();
		System.out.println("Tempo: " + (finishTime - startTime) + "ms");
		
	}

	@Override
	public void run() {
		 int threadNum = Integer.parseInt(Thread.currentThread().getName());
		 Pessoa alimentador = pessoas.get(threadNum % pessoas.size());
		 Pessoa alimentado = pessoas.get((threadNum+1) % pessoas.size());
		 alimentador.alimenta(alimentado);
	}
	
	private static void imprimeStatusPessoas(){
		for (Pessoa p : pessoas) {
			System.out.println("Pessoa " + p.getCodigo() + " se alimentou: " + p.getColheradasRecebidas());
		}
	}
}
