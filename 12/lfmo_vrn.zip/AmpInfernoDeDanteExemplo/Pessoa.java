package AmpInfernoDeDanteExemplo;

import java.util.concurrent.atomic.AtomicInteger;

public class Pessoa {
	private final int codigo;
	private AtomicInteger colheradasRecebidas;

	public Pessoa(int codigo) {
		super();
		this.codigo = codigo;
		colheradasRecebidas = new AtomicInteger(0);
	}

	public void alimenta(Pessoa p) {
		p.addColherada();
	}
	
	public void addColherada() {
		colheradasRecebidas.getAndIncrement();
	}

	public int getColheradasRecebidas() {
		return colheradasRecebidas.get();
	}

	public int getCodigo() {
		return codigo;
	}

}
