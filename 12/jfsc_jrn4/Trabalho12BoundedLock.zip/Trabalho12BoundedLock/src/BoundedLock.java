

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.LongAdder;
import java.util.concurrent.locks.ReentrantLock;

public class BoundedLock<T> {

	private volatile T elements[];
	private LongAdder head, tail;
	private ReentrantLock enqLock, deqLock;

	public BoundedLock(int capacity) {
		head = new LongAdder(); 
		tail = new LongAdder();
		elements = (T[])new Object[capacity];
		enqLock = new ReentrantLock();
		deqLock = new ReentrantLock();
	}

	public void enq(T x) {
		enqLock.lock();
		try {
			while (tail.intValue() - head.intValue() == elements.length) {}
			elements[tail.intValue() % elements.length] = x;
			tail.increment();
		} finally {
			enqLock.unlock();
		}
	}

	public T deq() {
		deqLock.lock();
		T x;
		try {
			while (tail.intValue() - head.intValue() == 0) {}
			x = elements[head.intValue() % elements.length];
			head.increment();
		} finally {
			deqLock.unlock();
		}
		return x;
		
	}
}