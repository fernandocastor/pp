
import java.util.concurrent.atomic.AtomicInteger;

public class BoundedLockFree<T> {

	private T elements[];
	private AtomicInteger head, tail;

	@SuppressWarnings("unchecked")
	public BoundedLockFree(int capacity) {
		super();
		elements = (T[]) new Object[capacity];
		head = new AtomicInteger(0);
		tail = new AtomicInteger(0);
	}

	public void enq(T x) {
		while (true) {
			int t = tail.get();
			if (tail.get() - head.get() < elements.length) { 
				if (tail.compareAndSet(t, t + 1)) {
					elements[t % elements.length] = x;
					return;
				}
			}
		}
	}
  public T deq() {
		T x;
		while (true) {
			int h = head.get();
			if (tail.get() - head.get() > 0) { 
				if(head.compareAndSet(h, h+1)){ 
					x = elements[h % elements.length];
					return x;
				}
			}
		}
	}


}
