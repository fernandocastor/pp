import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    private final static int THREADS = 2;
    private final static BoundedLockFree<Integer> queue =  new BoundedLockFree<Integer>(10);
    
    public Main(){
      ExecutorService pool = Executors.newFixedThreadPool(THREADS);
        for (int i = 0; i < THREADS; i++) {
          if(i%2==0) pool.submit(new MyThread("ENQ",i));
          else pool.submit(new MyThread("DEQ",i));
        }        
        pool.shutdown();
        
        
    }
    
    class MyThread implements Callable<String> {
      private ThreadLocal<String> myGender;
      private ThreadLocal<Integer> myValue;
      public  MyThread(String gender, int value) {
        myGender = new ThreadLocal<String>(){
          @Override 
          protected String initialValue(){
            return gender;
          }
        };
        myValue = new ThreadLocal<Integer>(){
          @Override 
          protected Integer initialValue(){
            return value;
          }
        };
      }
      @Override
      public String call() throws Exception {
        if(myGender.get().equals("ENQ")){
          for(int i=0; i<20 ; i++){
            System.out.println("EnQ_"+i);
            queue.enq(i);
          }
          
       }else{
         for(int i=0; i<20 ; i++){
           System.out.println("DeQ_"+queue.deq());
         }
        }
        return myGender.get();
    
      }
      
      }
    public static void main(String[] args) throws InterruptedException, ExecutionException {
      // TODO Auto-generated method stub
      Main mp = new Main();

    }

}
