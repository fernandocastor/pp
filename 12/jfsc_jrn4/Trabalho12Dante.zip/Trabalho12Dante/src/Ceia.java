import java.util.LinkedList;
import java.util.List;

public class Ceia implements Runnable{
	private static final int THREADS = 10;
	static LinkedList<Faminto> famintos = new LinkedList<Faminto>();
	
	public static void main(String[] args) throws InterruptedException {
		famintos.add(new Faminto(1));
		famintos.add(new Faminto(2));
		famintos.add(new Faminto(3));
		famintos.add(new Faminto(4));
		famintos.add(new Faminto(5));
		
		
		long startTime = System.currentTimeMillis();
		List<Thread> threads = new LinkedList<Thread>();
		for (int i = 0; i < THREADS; i++) {			
			threads.add(new Thread(new Ceia(), ""+i));
			threads.get(i).start();
		}
		
		for (int i = 0; i < THREADS; i++) {
			threads.get(i).join();
		}
		long finishTime = System.currentTimeMillis();
		
		printStatus();
		
	}

	@Override
	public void run() {
		 int threadNum = Integer.parseInt(Thread.currentThread().getName());
		 Faminto distribuidor = famintos.get(threadNum % famintos.size());
		 Faminto comerdor = famintos.get((threadNum+1) % famintos.size());
		 distribuidor.distribui(comerdor);
	}
	
	private static void printStatus(){
		for (Faminto p : famintos) {
			System.out.println("Faminto " + p.getCodigo() + " alimentado");
		}
	}
}
