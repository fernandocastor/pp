
import java.util.concurrent.atomic.AtomicInteger;

public class Faminto {
	private final int code;
	private AtomicInteger colheradasRecebidas;

	public Faminto(int code) {
		this.code = code;
		colheradasRecebidas = new AtomicInteger(0);
	}

	public void distribui(Faminto p) {
		p.addColherada();
	}
	
	public void addColherada() {
		colheradasRecebidas.getAndIncrement();
	}

	public int getColheradasRecebidas() {
		return colheradasRecebidas.get();
	}

	public int getCodigo() {
		return code;
	}

}
