package br.ufpe.pp.cap05.exact;

public class ExactClient {

	public static void main(String[] args) {

		if (args.length < 2) {
			System.out.println("Please provide arguments:");
			System.out.println("\t* Number of counting threads.");
			System.out.println("\t* Counting limit.");
		}
		else{

			Thread thread = new Thread(new CounterManager(
					Integer.valueOf(args[0]), Integer.valueOf(args[1])));
			thread.start();
		}

	}
}
