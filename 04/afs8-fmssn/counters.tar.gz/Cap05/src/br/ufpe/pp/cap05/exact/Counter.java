package br.ufpe.pp.cap05.exact;

public class Counter implements Cloneable {

	private long counter;
	private long countermax;

	public Counter() {
		this.counter = 0;
		this.countermax = 0;
	}

	public synchronized void atomic_set(long c, long cm) {
		this.counter = c;
		this.countermax = cm;
	}

	public long getCounter() {
		return counter;
	}

	public long getCountermax() {
		return countermax;
	}

	public synchronized boolean compareAndChange(long c, long cm, long c_new,
			long cm_new) {

		boolean success = false;
		if (c == this.counter && cm == this.countermax) {
			this.atomic_set(c_new, cm_new);
			success = true;
		}
		return success;
	}

	/**
	 * Zero'es the object.
	 * 
	 * @return a clone of its old value
	 */
	public synchronized Counter atomic_zero() {

		Counter c_new = null;
		try {
			c_new = (Counter) this.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}

		this.atomic_set(0, 0);

		return c_new;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		Counter novo = new Counter();
		novo.atomic_set(this.counter, this.countermax);
		return novo;
	}

}
