package br.ufpe.pp.cap05;

public class CounterThreadFloatVolatile implements Runnable, CounterThread {

	private volatile float myCounter;
	
	private long limit;
	
	public CounterThreadFloatVolatile(float pMyCounter, long pLimit) {
		super();
		this.myCounter = pMyCounter;
		this.limit = pLimit;
	}

	@Override
	public void run() {
		while(((int) myCounter) < limit){
			myCounter++;
		}
	}

	public int getMyCounter() {
		return (int) myCounter;
	}

}
