package br.ufpe.pp.cap05.exact;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CounterManager implements Runnable {

	public static long GLOBALCOUNTMAX;

	public static int N_THREADS;

	public static volatile boolean STOP;

	public static long GLOBALCOUNT = 0;

	public static long GLOBALRESERVE = 0;

	public static CounterThread[] counterThreads;

	private final Lock lock;

	public CounterManager(int pQtyCounters, int limit) {
		GLOBALCOUNTMAX = limit;

		N_THREADS = pQtyCounters;

		counterThreads = new CounterThread[N_THREADS];

		lock = new ReentrantLock();

		for (int i = 0; i < N_THREADS; i++) {
			counterThreads[i] = new CounterThread(new Counter(), lock);
		}

	}

	@Override
	public void run() {

		long sum = 0;

		for (CounterThread ct : counterThreads) {
			ct.start();
		}

		while (!STOP) {
			sum = read_count();
			if (sum == GLOBALCOUNTMAX) {
				STOP = true;
			}
		}

		System.out.println("End of counting! Counting reached: " + sum);

	}

	private long read_count() {

		lock.lock();
		long total = GLOBALCOUNT;

		for (CounterThread t : counterThreads) {
			total = total + t.getCounter().getCounter();
		}
		lock.unlock();

		return total;

	}

	public static void flush_local_count() {

		if (CounterManager.GLOBALRESERVE == 0) {
			return;
		}

		for (CounterThread t : CounterManager.counterThreads) {

			Counter tmp = t.getCounter().atomic_zero();

			CounterManager.GLOBALCOUNT = CounterManager.GLOBALCOUNT
					+ tmp.getCounter();
			CounterManager.GLOBALRESERVE = CounterManager.GLOBALRESERVE
					- tmp.getCountermax();

		}
	}

}
