package br.ufpe.pp.cap05;

public class CounterThreadDouble implements Runnable, CounterThread {

	private double myCounter;
	
	private long limit;
	
	public CounterThreadDouble(double pMyCounter, long pLimit) {
		super();
		this.myCounter = pMyCounter;
		this.limit = pLimit;
	}

	@Override
	public void run() {
		while(myCounter < limit){
			myCounter++;
		}
	}

	public int getMyCounter() {
		return (int) myCounter;
	}

}
