package br.ufpe.pp.cap05;

public class CounterManager implements Runnable {

	protected int[] counters;

	private int limit = Integer.MAX_VALUE;

	protected CounterThread[] counterThreads;

	public CounterManager(int pQtyCounters, String type, int pLimit,
			boolean isVolatile, boolean isAtomic) {

		if (pLimit > 0) {
			this.limit = pLimit;
		}

		this.counters = new int[pQtyCounters];

		if (isAtomic) {
			if (type.equalsIgnoreCase("int")) {
				this.counterThreads = new CounterThreadIntAtomic[pQtyCounters];
			} else if (type.equalsIgnoreCase("long")) {
				this.counterThreads = new CounterThreadLongAtomic[pQtyCounters];
			}
		} else if (isVolatile) {
			if (type.equalsIgnoreCase("int")) {
				this.counterThreads = new CounterThreadIntVolatile[pQtyCounters];
			} else if (type.equalsIgnoreCase("long")) {
				this.counterThreads = new CounterThreadLongVolatile[pQtyCounters];
			} else if (type.equalsIgnoreCase("float")) {
				this.counterThreads = new CounterThreadFloatVolatile[pQtyCounters];
			} else if (type.equalsIgnoreCase("double")) {
				this.counterThreads = new CounterThreadDoubleVolatile[pQtyCounters];
			}
		} else {
			if (type.equalsIgnoreCase("int")) {
				this.counterThreads = new CounterThreadInt[pQtyCounters];
			} else if (type.equalsIgnoreCase("long")) {
				this.counterThreads = new CounterThreadLong[pQtyCounters];
			} else if (type.equalsIgnoreCase("float")) {
				this.counterThreads = new CounterThreadFloat[pQtyCounters];
			} else if (type.equalsIgnoreCase("double")) {
				this.counterThreads = new CounterThreadDouble[pQtyCounters];
			}
		}

		for (int i = 0; i < counters.length; i++) {
			counters[i] = 0;

			if (isAtomic) {

				if (type.equalsIgnoreCase("int")) {
					counterThreads[i] = new CounterThreadIntAtomic(
							this.counters[i], limit);
				} else if (type.equalsIgnoreCase("long")) {
					counterThreads[i] = new CounterThreadLongAtomic(
							this.counters[i], limit);
				}

			} else if (isVolatile) {

				if (type.equalsIgnoreCase("int")) {
					counterThreads[i] = new CounterThreadIntVolatile(
							this.counters[i], limit);
				} else if (type.equalsIgnoreCase("long")) {
					counterThreads[i] = new CounterThreadLongVolatile(
							this.counters[i], limit);
				} else if (type.equalsIgnoreCase("float")) {
					this.limit = 16777216;
					counterThreads[i] = new CounterThreadFloatVolatile(
							this.counters[i], limit);
				} else if (type.equalsIgnoreCase("double")) {
					counterThreads[i] = new CounterThreadDoubleVolatile(
							this.counters[i], limit);
				}

			} else {

				if (type.equalsIgnoreCase("int")) {
					counterThreads[i] = new CounterThreadInt(this.counters[i],
							limit);
				} else if (type.equalsIgnoreCase("long")) {
					counterThreads[i] = new CounterThreadLong(this.counters[i],
							limit);
				} else if (type.equalsIgnoreCase("float")) {
					this.limit = 16777216;
					counterThreads[i] = new CounterThreadFloat(
							this.counters[i], limit);
				} else if (type.equalsIgnoreCase("double")) {
					counterThreads[i] = new CounterThreadDouble(
							this.counters[i], limit);
				}

			}

			Thread thread = new Thread(counterThreads[i]);
			thread.start();
		}
	}

	@Override
	public void run() {
		long sum;
		while ((sum = sum()) < (limit * counters.length))
			;

		System.out.println("Final count:" + sum);
		System.exit(0);
	}

	protected long sum() {
		long result = 0;

		for (int i = 0; i < this.counters.length; i++) {
			result += counterThreads[i].getMyCounter();
		}

		// System.out.println(Thread.currentThread().getName() + " - " +
		// result);
		return result;
	}

}
