package br.ufpe.pp.cap05;


public class Client {

	public static void main(String[] args) {
		
		Thread thread = new Thread(new CounterManager(Integer.valueOf(args[0]),
				String.valueOf(args[1]), Integer.valueOf(args[2]),
				Boolean.valueOf(args[3]), Boolean.valueOf(args[4])));
		thread.start();
	}
	
}
