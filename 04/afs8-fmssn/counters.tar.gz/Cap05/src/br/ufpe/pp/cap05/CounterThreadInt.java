package br.ufpe.pp.cap05;

public class CounterThreadInt implements Runnable, CounterThread {

	private int myCounter;
	
	private long limit;
	
	public CounterThreadInt(int pMyCounter, long pLimit) {
		super();
		this.myCounter = pMyCounter;
		this.limit = pLimit;
	}

	@Override
	public void run() {
		while(myCounter < limit){
			myCounter++;
		}
	}

	public int getMyCounter() {
		return myCounter;
	}

}
