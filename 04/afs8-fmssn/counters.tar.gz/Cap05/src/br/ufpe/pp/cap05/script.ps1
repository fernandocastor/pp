Set-ExecutionPolicy Unrestricted

$i = 1
do {
Measure-Command {java -jar client.jar 10 int 16777216 false false} >> int.log
Measure-Command {java -jar client.jar 10 int 16777216 true false} >> intv.log
Measure-Command {java -jar client.jar 10 int 16777216 false true} >> inta.log

Measure-Command {java -jar client.jar 10 long 16777216 false false} >> long.log
Measure-Command {java -jar client.jar 10 long 16777216 true false} >> longv.log
Measure-Command {java -jar client.jar 10 long 16777216 false true} >> longa.log

Measure-Command {java -jar client.jar 10 float 16777216 false false} >> float.log
Measure-Command {java -jar client.jar 10 float 16777216 true false} >> floatv.log

Measure-Command {java -jar client.jar 10 double 16777216 false false} >> double.log
Measure-Command {java -jar client.jar 10 double 16777216 true false} >> doublev.log
$i++
}
while ($i -le 10)


