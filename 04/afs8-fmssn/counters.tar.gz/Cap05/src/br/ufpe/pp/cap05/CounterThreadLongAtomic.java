package br.ufpe.pp.cap05;

import java.util.concurrent.atomic.AtomicLong;

public class CounterThreadLongAtomic implements Runnable, CounterThread {

	private AtomicLong myCounter;
	
	private long limit;
	
	public CounterThreadLongAtomic(long pMyCounter, long pLimit) {
		super();
		this.myCounter=new AtomicLong();
		this.limit = pLimit;
	}

	@Override
	public void run() {
		while(myCounter.get() < limit){
			myCounter.incrementAndGet();
		}
	}

	public int getMyCounter() {
		return (int) myCounter.get();
	}

}
