package br.ufpe.pp.cap05.exact;

import java.util.concurrent.locks.Lock;

public class CounterThread extends Thread {

	private Counter counter;

	private Lock lock;

	public CounterThread(Counter counter, Lock lock) {
		this.counter = counter;
		this.lock = lock;
	}

	@Override
	public void run() {
		while (!CounterManager.STOP) {
			this.inc_count();
		}

	}

	public void inc_count() {

		long c;
		long cm;
		boolean slowpath = false;

		do {

			c = this.counter.getCounter();
			cm = this.counter.getCountermax();
			if (c + (long) 1 > cm) {
				slowpath = true;
				break;
			}

		} while (!this.counter.compareAndChange(c, cm, c + (long) 1, cm));

		if (slowpath) {

			boolean itWorked = true;
			this.lock.lock();
			this.globalize_count();

			if (CounterManager.GLOBALCOUNTMAX - CounterManager.GLOBALCOUNT
					- CounterManager.GLOBALRESERVE < (long) 1) {

				CounterManager.flush_local_count();
				if (CounterManager.GLOBALCOUNTMAX - CounterManager.GLOBALCOUNT
						- CounterManager.GLOBALRESERVE < (long) 1) {
					this.lock.unlock();
					itWorked = false;
				}
			}

			if (itWorked) {
				CounterManager.GLOBALCOUNT = CounterManager.GLOBALCOUNT
						+ (long) 1;
				this.balance_count();
				this.lock.unlock();
			}
		}
	}

	public void balance_count() {

		long c = 0;
		long cm = 0;

		long limit = CounterManager.GLOBALCOUNTMAX - CounterManager.GLOBALCOUNT
				- CounterManager.GLOBALRESERVE;

		limit = limit / CounterManager.N_THREADS;

		cm = limit;

		CounterManager.GLOBALRESERVE = CounterManager.GLOBALRESERVE + cm;

		c = cm / 2;

		if (c > CounterManager.GLOBALCOUNT) {
			c = CounterManager.GLOBALCOUNT;
		}

		CounterManager.GLOBALCOUNT = CounterManager.GLOBALCOUNT - c;

		this.counter.atomic_set(c, cm);
	}

	public void globalize_count() {

		CounterManager.GLOBALCOUNT = CounterManager.GLOBALCOUNT
				+ this.counter.getCounter();
		CounterManager.GLOBALRESERVE = CounterManager.GLOBALRESERVE
				- this.counter.getCountermax();

		this.counter.atomic_set(0, 0);
	}

	public Counter getCounter() {
		return counter;
	}

}
