package br.ufpe.pp.cap05;

public class CounterThreadLong implements Runnable, CounterThread {

	private long myCounter;
	
	private long limit;
	
	public CounterThreadLong(long pMyCounter, long pLimit) {
		super();
		this.myCounter = pMyCounter;
		this.limit = pLimit;
	}

	@Override
	public void run() {
		while(myCounter < limit){
			myCounter++;
		}
	}

	public int getMyCounter() {
		return (int) myCounter;
	}

}
