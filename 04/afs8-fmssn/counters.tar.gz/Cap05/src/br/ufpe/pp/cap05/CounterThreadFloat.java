package br.ufpe.pp.cap05;

public class CounterThreadFloat implements Runnable, CounterThread {

	private float myCounter;
	
	private long limit;
	
	public CounterThreadFloat(float pMyCounter, long pLimit) {
		super();
		this.myCounter = pMyCounter;
		this.limit = pLimit;
	}

	@Override
	public void run() {
		while(((int) myCounter) < limit){
			myCounter++;
		}
	}

	public int getMyCounter() {
		return (int) myCounter;
	}

}
