package br.ufpe.pp.cap05;

public class CounterThreadLongVolatile implements Runnable, CounterThread {

	private volatile long myCounter;
	
	private long limit;
	
	public CounterThreadLongVolatile(long pMyCounter, long pLimit) {
		super();
		this.myCounter = pMyCounter;
		this.limit = pLimit;
	}

	@Override
	public void run() {
		while(myCounter < limit){
			myCounter++;
		}
	}

	public int getMyCounter() {
		return (int) myCounter;
	}

}
