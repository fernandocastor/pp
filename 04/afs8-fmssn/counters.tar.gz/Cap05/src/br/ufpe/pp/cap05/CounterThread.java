package br.ufpe.pp.cap05;

public interface CounterThread extends Runnable {

	public int getMyCounter();
	
}
