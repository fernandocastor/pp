package br.ufpe.pp.cap05;

import java.util.concurrent.atomic.AtomicInteger;

public class CounterThreadIntAtomic implements Runnable, CounterThread {

	private AtomicInteger myCounter;
	
	private long limit;
	
	public CounterThreadIntAtomic(int pMyCounter, long pLimit) {
		super();
		this.myCounter = new AtomicInteger();
		this.limit = pLimit;
	}

	@Override
	public void run() {
		while(myCounter.get() < limit){
			myCounter.incrementAndGet();
		}
	}

	public int getMyCounter() {
		return myCounter.get();
	}

}
