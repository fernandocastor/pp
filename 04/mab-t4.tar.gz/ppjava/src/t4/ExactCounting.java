package t4;

import java.util.concurrent.atomic.AtomicLong;

import javax.sql.rowset.spi.SyncResolver;

import org.junit.Assert;
import org.junit.Test;

public class ExactCounting {
	protected static volatile boolean shouldRun = true;
	final static long MAX_COUNTERMAX = (1l << 32) - 1;
	
	@Test
	public void t() {
		long a = Integer.MAX_VALUE;
		long b = Integer.MAX_VALUE;
		testPacking(a, b);
		
		a = 0;
		testPacking(a, b);
		a = Integer.MAX_VALUE;
		b = 0;
		testPacking(a, b);
//		System.out.println(((long)Integer.MAX_VALUE) * 2);
//		System.out.println(MAX_COUNTERMAX);
//		System.out.println(Long.toBinaryString(MAX_COUNTERMAX));
	}

	public void testPacking(long a, long b) {
		long m = mergeCounter(a, b);
		Split s = splitCounter(m);
		Assert.assertEquals(a, s.count);
		Assert.assertEquals(b, s.countmax);
	}
	
	static class Split {
		final long count;
		final long countmax;

		public Split(long count, long countmax) {
			this.count = count;
			this.countmax = countmax;
		}
	}
	
	static Split splitCounter(long counter) {
		long c = counter >> 32 & MAX_COUNTERMAX;
		long cm = counter & MAX_COUNTERMAX;
		return new Split(c, cm);
	}
	
	static long mergeCounter(long c, long cm) {
		return (c << 32 | cm);
	}

	
	static volatile long end = 0;
	static long globalcountmax;
	static long globalcount;
	static long globalreserve;
	static int nthreads;
	static Counter[] threads;
	
	static class Counter extends Thread {
		AtomicLong counterandmax;
		
		Counter() {
			counterandmax = new AtomicLong();
		}

		public void run() {
			Split split;
			long old, newer;
			
			while (shouldRun) {
				do {
					old = counterandmax.get();
					split = splitCounter(old);
					if (split.count + 1 > split.countmax) {
						break;
					}
					newer = mergeCounter(split.count + 1, split.countmax); 
				} while(!counterandmax.compareAndSet(old, newer));

				synchronized(ExactCounting.class) {
					globalizeCount(counterandmax);
					if ((globalcountmax - globalcount) - globalreserve < 1) {
						flushLocalCount();
						if ((globalcountmax - globalcount) - globalreserve < 1) {
							//System.out.println("failure to update counter");
							continue;
						}
					}
					
					globalcount++;
					balanceCount(counterandmax);
				}
			}
		}

		private void balanceCount(AtomicLong counterandmax) {
			long c;
			long cm;
			long old;
			long limit;
			
			limit = (globalcountmax - globalcount) - globalreserve;
			limit = limit / nthreads;
			cm = limit;
			globalreserve += limit;
			c = 0;
			old = mergeCounter(c, cm);
			counterandmax.set(old);
		}

		private void flushLocalCount() {
			long old;
			long zero;

			if (globalreserve == 0) {
				return;
			} else {
				zero = mergeCounter(0, 0);
			}
			
			for (Counter thread : threads) {
				old = thread.counterandmax.getAndSet(zero);
				Split split = splitCounter(old);
				globalcount += split.count;
				globalreserve -= split.countmax;
			}
		}

		private void globalizeCount(AtomicLong counterandmax) {
			long old;

			Split split = splitCounter(counterandmax.get());
			globalcount += split.count;
			globalreserve -= split.countmax;
			old = mergeCounter(0, 0);
			counterandmax.set(old);
		}
	}



	public static void main(String[] args) {
		nthreads = Integer.parseInt(args[0]);
		final long max = Long.parseLong(args[1]);
		final int sleep = Integer.parseInt(args[2]); // 0 for no sleep
		threads = new Counter[nthreads];

		for (int i = 0; i < 10; i++) {
			end = 0;
			globalcountmax = max;
			globalcount = 0;
			globalreserve = 0;
			shouldRun = true;
			long start = System.nanoTime();
			try {
				for (int j = 0; j < nthreads; j++) {
					Counter c = new Counter();
					threads[j] = c;
				}
				runExperiment(sleep);
			} catch (InterruptedException e) {
				System.err.println("Thread interrupted...");
			}

			double time = (end - start) / 1000000000.0;
			System.out
					.println(nthreads + "," + sleep + "," + time);
		}
	}

	public static void runExperiment(final int sleep) throws InterruptedException {
		Thread aggregator = new Thread(new Runnable() {
			@Override
			public void run() {
				while (shouldRun) {
					synchronized(ExactCounting.class) {
						long sum = globalcount;
						for (Counter c : threads) {
							Split split = splitCounter(c.counterandmax.get());
							sum += split.count;
						}	
						if (sum == globalcountmax) {
							shouldRun = false;
							end = System.nanoTime();
						} 						
					}
					
					if (sleep > 0) {
						try {
							Thread.sleep(sleep);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		});
		for (Counter c : threads) {
			c.start();
		}
		aggregator.start();

		for (Counter c : threads) {
			c.join();
		}
		aggregator.join();
	}
}
