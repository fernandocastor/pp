package t4.tracker;

import java.util.concurrent.atomic.AtomicLong;

public class AtomicLongTracker extends Tracker {

	AtomicLong value = new AtomicLong(0); 
	
	@Override
	public void increment() {
		value.incrementAndGet();
	}

	@Override
	public Number get() {
		return value.get();
	}
}
