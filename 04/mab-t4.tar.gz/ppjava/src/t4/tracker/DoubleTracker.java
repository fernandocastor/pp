package t4.tracker;

public class DoubleTracker extends Tracker {

	double value = 0;
	
	@Override
	public void increment() {
		value++;
	}

	@Override
	public Number get() {
		return value;
	}
}
