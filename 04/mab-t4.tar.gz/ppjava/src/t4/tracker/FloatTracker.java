package t4.tracker;

public class FloatTracker extends Tracker {

	float value = 0;
	
	@Override
	public void increment() {
		value++;
	}

	@Override
	public Number get() {
		return value;
	}
}
