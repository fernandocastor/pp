#!/bin/bash

echo "type,nthreads,sleep,time" > results.csv

#"FLOAT" does not work properly (precision problems)
# "INT" "DOUBLE" "LONG" "V_INT"
for TYPE in  "ATOMIC_INT"; do
	for NTHREADS in "5" "50"; do
		for SLEEP in "0" "10"; do
			echo "running $TYPE $NTHREADS $SLEEP"
			java -cp bin t4.StatisticalCounting $NTHREADS 2147483648 $TYPE $SLEEP >> results.csv
		done
	done
done

echo "type,nthreads,sleep,time" > results_exact.csv

echo "nthreads,sleep,time" > results_exact.csv
for NTHREADS in "5" "50"; do
	for SLEEP in "0" "10"; do
		echo "running $TYPE $NTHREADS $SLEEP"
		java -cp bin t4.StatisticalCounting $NTHREADS 2147483648 $SLEEP >> results_exact.csv
	done
done

