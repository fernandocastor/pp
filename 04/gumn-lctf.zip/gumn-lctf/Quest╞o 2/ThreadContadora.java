import java.util.concurrent.atomic.AtomicLong;

public class ThreadContadora extends Thread {
	private AtomicLong counter;
	private boolean stop;
	
	public ThreadContadora() {
		this.counter = new AtomicLong(0);
		this.stop = false;
	}
	
	public void run() {
		while(!this.stop) {
			this.counter.getAndIncrement();
		}
	}
	
	public long readCounter() {
		return this.counter.get();
	}
	
	public void setStop(boolean stop) {
		this.stop = stop;
	}
}
