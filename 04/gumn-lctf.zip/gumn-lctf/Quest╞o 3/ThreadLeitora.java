
public class ThreadLeitora extends Thread {
	private long k;
	private ThreadContadora[] tcs;
	
	public ThreadLeitora(long k, ThreadContadora[] tcs) {
		this.k = k;
		this.tcs = tcs;
	}

	public void run() {
		try {
			while(true) {
				long sum = 0;
				
				for(ThreadContadora tc : tcs)
					sum += tc.readCounter();
				
				if(sum>=k) {
					System.out.println("sum = " + sum);
					break;
				} else {
					Thread.sleep(1);
				}
			}
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
}
