
public class ThreadContadora extends Thread {
	private long counter;
	private long k;
	
	public ThreadContadora(long k) {
		this.counter = 0;
		this.k = k;
	}
	
	public void run() {
		while(this.counter<this.k) {
			this.counter++;
		}
	}
	
	public long readCounter() {
		return this.counter;
	}
}
