
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ContadorExato {
	//Vari�veis do contador
	static long globalcountmax;
	static long globalcount;
	static long globalreserve;
	static int n;
	static ThreadContadora[] counterp;
	static ThreadLeitora readerp;
	static Lock gblcnt_mutex = new ReentrantLock();
	final static long MAX_COUNTERMAX = (1l << 32) - 1;
	static volatile boolean stop = false;
	
	//Classe pra encapsular counter e countermax
	static class CtrAndMax {
		long counter;
		long countermax;
		
		public CtrAndMax(long count, long countmax) {
			this.counter = count;
			this.countermax = countmax;
		}
	}
	
	//Faz o split de ctrandmax
	static CtrAndMax split_ctrandmax(long ctrandmax) {
		long c = ctrandmax >> 32 & MAX_COUNTERMAX;
		long cm = ctrandmax & MAX_COUNTERMAX;
		return new CtrAndMax(c, cm);
	}
	
	//Faz o merge de counter e countermax
	static long merge_ctrandmax(long c, long cm) {
		return (c << 32 | cm);
	}
	
	//Thread contadora
	static class ThreadContadora extends Thread {
		AtomicLong ctrandmax = new AtomicLong(0);
		
		//Incremento
		public void run() {
			while(!stop) {
				long c;
				long cm;
				long _old;
				long _new;
				
				//fastpath
				do {
					CtrAndMax splitted = split_ctrandmax(ctrandmax.get());
					c = splitted.counter;
					cm = splitted.countermax;
					_old = ctrandmax.get();
					
					if((c + 1) > cm)
						break;
					
					_new = merge_ctrandmax(c + 1, cm);
				} while(!ctrandmax.compareAndSet(_old, _new));
				
				//slowpath
				gblcnt_mutex.lock();
				globalize_count();
				if((globalcountmax - globalcount) - globalreserve < 1) {
					flush_local_count();
					if((globalcountmax - globalcount) - globalreserve < 1) {
						gblcnt_mutex.unlock();
						continue;
					}
				}
				globalcount++;
				balance_count();
				gblcnt_mutex.unlock();
			}
		}
		
		//Repassa o contador da thread para o contador global
		public void globalize_count() {
			CtrAndMax splitted = split_ctrandmax(ctrandmax.get());
			long c = splitted.counter;
			long cm = splitted.countermax;
			
			globalcount += c;
			globalreserve -= cm;
			
			long old = merge_ctrandmax(0, 0);
			ctrandmax.set(old);
		}
		
		//Repassa os contadores de todas as threads para o contador global
		public void flush_local_count() {
			if(globalreserve==0)
				return;
			
			long zero = merge_ctrandmax(0, 0);
			
			for(ThreadContadora tc : counterp) {
				long old = tc.ctrandmax.getAndSet(zero);
				
				CtrAndMax splitted = split_ctrandmax(old);
				long c = splitted.counter;
				long cm = splitted.countermax;
				
				globalcount += c;
				globalreserve -= cm;
			}
		}
		
		public void balance_count() {
			long limit = ((globalcountmax - globalcount) - globalreserve) / n;
			long cm;
			
			if(limit > MAX_COUNTERMAX)
				cm = MAX_COUNTERMAX;
			else
				cm = limit;
			
			globalreserve += cm;
			long c = cm / 2;
			
			if(c > globalcount)
				c = globalcount;
			globalcount -= c;
			
			long old = merge_ctrandmax(c, cm);
			ctrandmax.set(old);
		}
	}
	
	static class ThreadLeitora extends Thread {
		public void run() {
			try {
				//Leitura
				while(true) {
					gblcnt_mutex.lock();
					long sum = globalcount;
					
					for(ThreadContadora tc : counterp) {
						CtrAndMax splitted = split_ctrandmax(tc.ctrandmax.get());
						sum += splitted.counter;
					}
					
					if(sum == globalcountmax) {
						System.out.println("sum = " + sum);
						stop = true;
						break;
					}
					
					gblcnt_mutex.unlock();
					
					//Intervalo de 10 milisegundos
					Thread.sleep(10);
				}
			} catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		try {
			long t1 = System.currentTimeMillis();
			
			//Inicia as vari�veis do algoritmo
			globalcountmax = (long) Math.pow(2, 31);
			globalcount = 0;
			globalreserve = 0;
			n = 4;
			
			//L� par�metro K
			if(args.length>0 && args[1]!=null)
				globalcountmax = Long.parseLong(args[1]);
			
			//L� par�metro N
			if(args.length>0 && args[0]!=null)
				n = Integer.parseInt(args[0]);
			
			System.out.println("n = " + n);
			System.out.println("k = " + globalcountmax);
			
			//Cria e inicia as threads contadoras
			counterp = new ThreadContadora[n];
			for(int i=0; i<n; i++) {
				counterp[i] = new ThreadContadora();
				counterp[i].start();
			}
			
			//Cria e inicia as threads leitoras
			readerp = new ThreadLeitora();
			readerp.start();
			readerp.join();
			
			long t2 = System.currentTimeMillis();
			System.out.println("Tempo de execu��o = " + (t2 - t1) + " ms");
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
}
