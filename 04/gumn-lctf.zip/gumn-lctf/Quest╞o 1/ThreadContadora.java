
public class ThreadContadora extends Thread {
	private long counter;
	private boolean stop;
	
	public ThreadContadora() {
		this.counter = 0;
		this.stop = false;
	}
	
	public void run() {
		while(!this.stop) {
			this.counter++;
		}
	}
	
	public long readCounter() {
		return this.counter;
	}
	
	public void setStop(boolean stop) {
		this.stop = stop;
	}
}
