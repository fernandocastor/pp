
public class ContadorEstatistico {
	
	public static void main(String... args) {
		try {
			long t1 = System.currentTimeMillis();
			
			int n = 4;
			long k = (long) Math.pow(2, 31);
			
			if(args.length>0 && args[0]!=null)
				n = Integer.parseInt(args[0]);
			
			if(args.length>0 && args[1]!=null)
				k = Long.parseLong(args[1]);
			
			System.out.println("n = " + n);
			System.out.println("k = " + k);
			
			ThreadContadora[] tcs = new ThreadContadora[n];
			
			for(int i=0; i<n; i++) {
				tcs[i] = new ThreadContadora();
				tcs[i].start();
			}
			
			Thread tl = new ThreadLeitora(k, tcs);
			tl.start();
			tl.join();
			
			for(ThreadContadora tc : tcs) {
				tc.setStop(true);
			}
			
			long t2 = System.currentTimeMillis();
			System.out.println("Tempo de execu��o = " + (t2 - t1) + " ms");
		} catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
}
