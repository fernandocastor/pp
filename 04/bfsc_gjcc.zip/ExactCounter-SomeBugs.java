package br.ufpe.cin.pp.trabalho04;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ExactCounter {

	// ===== Global  constants and variables
	
	private static final int NR_THREADS = 1;
	private static final int CM_BITS = 4 * 4;
	private static final int MAX_COUNTERMAX = (1 << CM_BITS) - 1;
	
	private ThreadLocal<AtomicInteger> ctrandmax = new ThreadLocal<AtomicInteger>();
	private int globalcountmax = 10000;
	private int globalcount = 0;
	private int globalreserve = 0;
	private AtomicInteger[] counterp = new AtomicInteger[NR_THREADS];
	private Lock gblcnt_mutex = new ReentrantLock();

	// ===== ExactCounter methods and classes
	
	private static class SplitCtrandmaxIntReturn {
		int c;
		int cm;
	}
	
	public static SplitCtrandmaxIntReturn split_ctrandmax_int(int cami) {
		SplitCtrandmaxIntReturn toReturn = new SplitCtrandmaxIntReturn();
		
		toReturn.c = (cami >> CM_BITS) & MAX_COUNTERMAX;
		toReturn.cm = cami & MAX_COUNTERMAX;
		
		return toReturn;
	}

	private static class SplitCtrandmaxReturn {
		int old;
		int c;
		int cm;
	}
	
	public static SplitCtrandmaxReturn split_ctrandmax(AtomicInteger cam) {
		SplitCtrandmaxReturn toReturn = new SplitCtrandmaxReturn();
		
		int cami = cam.get();
		
		toReturn.old = cami;
		SplitCtrandmaxIntReturn split_ctrandmax_int_return = split_ctrandmax_int(cami);
		toReturn.c = split_ctrandmax_int_return.c;
		toReturn.cm = split_ctrandmax_int_return.cm;
		return toReturn;
	}
	
	public static int merge_ctrandmax(int c, int cm) {
		int cami;
		cami = (c << CM_BITS) | cm;
		return ((int)cami);
	}
	
	public void initExactCounter() {
		for(int i = 0; i < NR_THREADS; i++){
			new Thread(new Updater(i)).start();
		}
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		for (int i = 0; i < counterp.length; i++) {
			counterp[i] = new AtomicInteger();
		}
		
		new Thread(new Reader()).start();
	}
	
	public static void main(String[] args) {
		ExactCounter exactCounter = new ExactCounter();
		exactCounter.initExactCounter();
	}
	
	// ===== Updater class
	
	private class Updater implements Runnable {
		
		int id;
		
		public Updater(int id) {
			this.id = id;
		}

		public void run() {
			ctrandmax.set(new AtomicInteger(0));
			
			count_register_thread();
			while(globalcount <= globalcountmax){
				add_count(1);
				System.out.println(globalcount);
			}
			count_unregister_thread();
		}
		
		public int add_count(int delta) {
			int new_;
		
			SplitCtrandmaxReturn split_ctrandmax_return = null;
			
			boolean slowpath = false;
			
			do {
				split_ctrandmax_return = split_ctrandmax(ctrandmax.get());
				
				if (delta > MAX_COUNTERMAX || split_ctrandmax_return.c + delta > split_ctrandmax_return.cm) {
					slowpath = true;
					break;
				}
				
				new_ = merge_ctrandmax(split_ctrandmax_return.c + delta, split_ctrandmax_return.cm);
			} while (ctrandmax.get().compareAndSet(split_ctrandmax_return.old, new_));
			
			if (slowpath) {
				gblcnt_mutex.lock();
				globalize_count();
				if ((globalcountmax - globalcount - globalreserve) < delta) {
					flush_local_count();
					if ((globalcountmax - globalcount - globalreserve) < delta) {
						gblcnt_mutex.unlock();
						return 0;
					}
				}	
				
				globalcount += delta;
				balance_count();
				gblcnt_mutex.unlock();
				return 1;
			} else {
				return 1;	
			}
		}
		
		public void globalize_count(){
			SplitCtrandmaxReturn toReturn = split_ctrandmax(ctrandmax.get());
			globalcount += toReturn.c;
			globalreserve -= toReturn.cm;
			int old = merge_ctrandmax(0, 0);
			ctrandmax.get().set(old);
		}

		public void flush_local_count(){
	    	int c;
	    	int cm;
	    	int old;
	    	int zero;
	    	if (globalreserve == 0)
	    		return;
	    	zero = merge_ctrandmax(0, 0);
	    	for(AtomicInteger count: counterp){
	    		if(count != null){
	    			old = count.getAndSet(zero);
	    			SplitCtrandmaxIntReturn split_ctrandmax_int_return = split_ctrandmax_int(old);
	    			c = split_ctrandmax_int_return.c;
	    			cm = split_ctrandmax_int_return.cm;
	    			globalcount += c;
	    			globalreserve -= cm;
	    		}
	    	}
	    }
		
		public void balance_count() {
			int c;
			int cm;
			int limit;
			limit = globalcountmax - globalcount - globalreserve;
			limit /= num_online_threads();
			if (limit > MAX_COUNTERMAX)
				cm = MAX_COUNTERMAX;
			else
				cm = limit;
			globalreserve += cm;
			c = cm / 2;
			if (c > globalcount)
				c = globalcount;
			globalcount -= c;
			int old = merge_ctrandmax(c, cm);
			ctrandmax.get().set(old);
		}

		private long num_online_threads() {
			gblcnt_mutex.lock();
			
			long toReturn = 0;
			
			try {
				for (AtomicInteger count : counterp) {
					toReturn += (count == null) ? 0 : 1;
				}
			} finally {
				gblcnt_mutex.unlock();
			}
			
			return toReturn;
		}

		public void count_register_thread(){
			int idx = id;
			gblcnt_mutex.lock();
			counterp[idx] = ctrandmax.get();
			gblcnt_mutex.unlock();
		}
		
		public void count_unregister_thread() 	{
			int idx = id;
			gblcnt_mutex.lock();
			globalize_count();
			counterp[idx] = null;
			gblcnt_mutex.unlock();
		}
		
	}
	
	// ===== Reader class
	
	private class Reader implements Runnable {

		public void run() {
			long tini = System.currentTimeMillis();

			int sum = 0;
			
			while ((sum = read_count()) != 0) {
				globalcount = sum;
			}
			
			long tfim = System.currentTimeMillis();
			System.out.println("count = " + globalcount + " in " + (tfim - tini) + "ms");
		}
		
		public int read_count() {
			int sum;
			
			gblcnt_mutex.lock();
			sum = globalcount;
			
			for (AtomicInteger count : counterp) {
				if (count != null) {
					SplitCtrandmaxReturn split_ctrandmax_return = split_ctrandmax(count);
					sum += split_ctrandmax_return.c;
				}
			}
			
			gblcnt_mutex.unlock();
			
			return sum;
		}
		
	}
	
}
