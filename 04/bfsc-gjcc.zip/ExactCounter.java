package pacot;

import java.util.concurrent.atomic.AtomicInteger;

public class ExactCounter {

	private long globalCount;	//sum of all counters
	private long[] counters;	//counters for each thread
	private int n; 			//number of threads
	private long k;			//counter sum's limit
	private AtomicInteger ai = new AtomicInteger(0); //indicates that all threads finished their counting
	
	public ExactCounter(int n, long k){
		this.globalCount = 0;
		this.n = n;
		this.k = k;
		this.counters = new long[this.n];
	}

	public long read_count(){
		return this.globalCount;
	}

	//initializes the counting
	public void count_init(){
		Readerr r = new Readerr(this.counters, this.globalCount, this.k);
		Thread tr = new Thread(r);
		tr.start();
		for(int i = 0; i<this.n; i++){
			Updaterr u  = new Updaterr(i, this.counters, (k/n));
			Thread 	tu  = new Thread(u);
			tu.start();
		}
	}

	public static void main(String[] args) {
		ExactCounter e = new ExactCounter(4, 3000000000l);
		e.count_init();
	}


	class Updaterr implements Runnable{
		private long[] counters;
		int id;
		private long countermax;

		public Updaterr(int id, long[] counters, long countermax){
			this.id = id;
			this.counters = counters;
			this.countermax = countermax;

		}

		//increments his own counter.
		public void inc_count(){
			this.counters[this.id]++; 
		}

		
		public void run() {
			while(counters[this.id] < this.countermax){
				this.inc_count();
			}
			ai.incrementAndGet();
		}
	}



	class Readerr implements Runnable{
		private long[] counters;
		private long globalCount;
		long k;

		public Readerr(long[] counters, long globalCount, long k){
			this.counters=counters;
			this.k = k;
		}

		//cycles through all the threads, summing the per-thread local counter and storing the sum to the
		//global_count variable and waits an arbitrarily chosen one millisecond between passes
		@Override
		public void run() {
			long tini = System.currentTimeMillis();

			while(ai.get() != n){}
			
			try {
				long sum = 0;
				for(long count: this.counters){
					sum = sum + count;
				}
				this.globalCount = sum;
				Thread.sleep(1);
			} catch (Exception e) {
				e.printStackTrace();
			}

			long tfim = System.currentTimeMillis();
			System.out.println("Count = " + this.globalCount + " in " + (tfim - tini));
		}
	}
}







