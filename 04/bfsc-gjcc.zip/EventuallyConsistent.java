package br.ufpe.cin.pp.trabalho04;

import java.util.concurrent.atomic.AtomicBoolean;

import br.ufpe.cin.pp.trabalho04.Reader;
import br.ufpe.cin.pp.trabalho04.Updater;

public class EventuallyConsistent {

	private int globalCount;	//sum of all counters
	private int[] counters;	//counters for each thread
	private int n; 			//number of threads
	private int k;			//counter sum's limit
	private Finished finished = new Finished();

	public EventuallyConsistent(int n, int k){
		this.globalCount = 0;
		this.n = n;
		this.k = k;
		this.counters = new int[this.n];
	}

	public long read_count(){
		return this.globalCount;
	}

	//initializes the counting
	public void count_init(){
		Reader r = new Reader(this.counters, this.globalCount, this.k, this.finished);
		Thread tr = new Thread(r);
		tr.start();
		for(int i = 0; i<this.n; i++){
			Updater u  = new Updater(i, this.counters, this.finished);
			Thread 	tu = new Thread(u);
			tu.start();
		}
	}

	public static void main(String[] args) {
		EventuallyConsistent e = new EventuallyConsistent(4, Integer.MAX_VALUE);
		e.count_init();
	}
	
}

class Finished {
	
	private AtomicBoolean finished = new AtomicBoolean(false);

	public AtomicBoolean isFinished() {
		return finished;
	}

	public void setFinished(AtomicBoolean finished) {
		this.finished = finished;
	}
}

class Updater implements Runnable{
	private int[] counters;
	int id;
	Finished finished;

	public Updater(int id, int[] counters, Finished finished){
		this.id = id;
		this.counters = counters;
		this.finished = finished;
	}

	//increments his own counter.
	public void inc_count(){
		this.counters[this.id]++; 
	}

	@Override
	public void run() {
		while(!finished.isFinished().get()){
			this.inc_count();
		}
	}
}



class Reader implements Runnable{
	private int[] counters;
	private int globalCount;
	int k;
	Finished finished;

	public Reader(int[] counters, int globalCount, int k, Finished finished){
		this.counters=counters;
		this.k = k;
		this.finished = finished;
	}

	//cycles through all the threads, summing the per-thread local counter and storing the sum to the
	//global_count variable and waits an arbitrarily chosen one millisecond between passes
	@Override
	public void run() {
		boolean stopFlag = (this.globalCount <= this.k);
		
		long tini = System.currentTimeMillis();
		
		while(stopFlag){
			try {
				int sum = 0;
				for(int count: this.counters){
					sum = sum + count;
				}
				this.globalCount = sum;
				Thread.sleep(1);
				stopFlag = (this.globalCount <= this.k);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		finished.isFinished().set(true);
		
		long tfim = System.currentTimeMillis();
		System.out.println("Count = " + this.globalCount + " in " + (tfim - tini));
	}
}


