#!/bin/sh

for i in 1 2 3 4 5 6 7 8 9 10 11 12 13
  do
    echo "$i"
    time java Counting 4 2147483647
    time java AtomiCounting 4 2147483647
    time java ExactCounting 4 2147483647
done
