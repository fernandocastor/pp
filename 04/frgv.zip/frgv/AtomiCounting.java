// FRGV

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;


class GeneralCounters implements Runnable {
	
	AtomicLong count = new AtomicLong(0);
	AtomicBoolean end = new AtomicBoolean(false);
	
	@Override
	public void run() {
		do {
			count.incrementAndGet();
		} while (!end.get());
	}
}

class MainCounter implements Runnable {

	AtomicLong mainCount = new AtomicLong(0);
	static ArrayList<GeneralCounters> generalCounters;
	AtomicLong maxCount = new AtomicLong(0);

	public MainCounter(int k, final ArrayList<GeneralCounters> couters) {
		generalCounters = couters;
		maxCount.addAndGet(k);

	}

	@Override
	public void run() {
		do {
			mainCount.getAndSet(0);
			for (GeneralCounters counter : generalCounters) {
				mainCount.addAndGet(counter.count.get());
				System.out.println("+ c "+counter.count);
			}
		} while (mainCount.longValue() < maxCount.longValue());
		
		for (GeneralCounters counter : generalCounters) {
			counter.end.set(true);
		}
		System.out.println("Final Sum ≃ "+ mainCount);
	}
}

public class AtomiCounting {

	public static void main(String[] args){
		
		final ArrayList<GeneralCounters> generalCounters = new ArrayList<GeneralCounters>();
		int n = 0;
		int k = 0;

		if(args.length == 0){
			n = 2;
			k = Integer.MAX_VALUE; // 2147483647
			
		} else {
			n = Integer.parseInt(args[0]);
			k = Integer.parseInt(args[1]);
		}
		
		System.out.println(String.format("Counting until %1$s with %2$s theads", k, n));
		System.out.println("Starting threads...");
		
		int nThreads = n;
		for (int t = 0; t < nThreads; t++ ) {
			generalCounters.add(new GeneralCounters());
		}
		for (GeneralCounters gc : generalCounters) {
			new Thread(gc).start();
		}

		MainCounter sentinelCounter = new MainCounter(k, generalCounters);
		new Thread(sentinelCounter).start();
	}
}

