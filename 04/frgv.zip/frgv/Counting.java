// FRGV

import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;


class GeneralCounters implements Runnable {
	
	long count = 0;
	AtomicBoolean end = new AtomicBoolean(false);
	
	@Override
	public void run() {
		do {
			count = count + 1;
		} while (!end.get());
	}
}

class MainCounter implements Runnable {

	long mainCount = 0;
	static ArrayList<GeneralCounters> generalCounters;
	long maxCount;
	
	public MainCounter(int k, final ArrayList<GeneralCounters> couters) {
		generalCounters = couters;
		maxCount = k;
	}

	@Override
	public void run() {
		do {
			mainCount = 0;
			for (GeneralCounters counter : generalCounters) {
				mainCount += counter.count;
				System.out.println("+ c "+counter.count);
			}
			//System.out.println("Partial Sum: "+ mainCount);
		} while (mainCount < maxCount);
		
		//System.out.println("\nStopping theads");
		for (GeneralCounters counter : generalCounters) {
			counter.end.set(true);
		}
		System.out.println("Final Sum ≃ "+ mainCount);
	}
}

public class Counting {

	public static void main(String[] args){
		
		final ArrayList<GeneralCounters> generalCounters = new ArrayList<GeneralCounters>();
		int n = 0;
		int k = 0;

		if(args.length == 0){
			n = 2;
			k = Integer.MAX_VALUE; // 2147483647
			
		} else {
			n = Integer.parseInt(args[0]);
			k = Integer.parseInt(args[1]);
		}
		
		System.out.println(String.format("Counting until %1$s with %2$s theads", k, n));
		System.out.println("Starting threads...");
		
		int nThreads = n;
		for (int t = 0; t < nThreads; t++ ) {
			generalCounters.add(new GeneralCounters());
		}
		for (GeneralCounters gc : generalCounters) {
			new Thread(gc).start();
		}

		MainCounter sentinelCounter = new MainCounter(k, generalCounters);
		new Thread(sentinelCounter).start();
	}
}

