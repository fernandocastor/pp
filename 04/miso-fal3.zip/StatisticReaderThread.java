import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class StatisticReaderThread implements Runnable {

	Thread thread;
	
	StatisticCountingThread[] statisticCountingThreads;
	public long limit;
	public long globalCounter;
	public long sum;

	boolean isAlive;

	private long startTime;
	
	public StatisticReaderThread(long limit, long globalCounter, StatisticCountingThread[] statisticCountingThreads) {
		this.statisticCountingThreads = statisticCountingThreads;
		this.limit = limit;
		this.globalCounter = globalCounter;
		this.sum = 0;
	}

	public void start(long startTime){
		if(this.thread == null) {
			this.thread = new Thread(this);
			this.thread.start();
			this.isAlive = this.thread.isAlive();
			this.startTime = startTime;
		}
	}
	
	@Override
	public void run() {
		int i;
		while(globalCounter <= this.limit) {
			this.sum = 0;
			for(i = 0; i < statisticCountingThreads.length; i++) {
				sum += statisticCountingThreads[i].getCount();
//				System.out.println("Soma Thread<"+statisticCountingThreads[i].thread.getId()+">: "+statisticCountingThreads[i].getCount());
			}
			this.globalCounter = sum;
		}
		
		for(i = 0; i < statisticCountingThreads.length; i++) {
			statisticCountingThreads[i].stop();
		}
		
		this.stop();
		// Contagem do tempo de execu��o
		long estimatedTime = System.currentTimeMillis() - startTime;
		System.out.println(estimatedTime+"ms");
		System.out.println(this.globalCounter);

	}
	
	public void stop() {
		this.isAlive = false;
	}
}