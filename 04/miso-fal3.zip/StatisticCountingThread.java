import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class StatisticCountingThread implements Runnable {

	Thread thread;
	AtomicBoolean isAlive;
	
	public long limit;
	
	// Tipo do contador da thread 
	// Simula��es com: long, int, double, volatile long|int, AtomicInt|Long
	public long count;
//	public int count;
//	public double count;
//	public volatile long count;
//	public volatile int count;
//	public AtomicInt count;
//	public AtomicLong count;
	
	public StatisticCountingThread(long limit) {
		// Limite usado para o fastpath
		this.isAlive = new AtomicBoolean(false);
		this.limit = limit;
		this.count = 0;
	}

	public void start(){
		if(this.thread == null) {
			this.thread = new Thread(this);
			this.thread.start();
			this.isAlive.set(this.thread.isAlive());
			
		}
	}
	
	@Override
	public void run() {	
		// Para os casos at�micos:
		// while(this.count.incrementAndGet() < this.limit);
		
		while(isAlive.get()){
			++this.count;
		}
	}
	
	public long getCount() {
		// Para os casos at�micos:
		// return this.count.get();

		// Para tipos primitivos:
		return this.count;
	}
	
	public void stop() {
		this.isAlive.set(false);
	}

}
