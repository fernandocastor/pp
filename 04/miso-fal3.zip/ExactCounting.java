import java.util.concurrent.atomic.AtomicInteger;

public class ExactCounting {

	ExactCountingThread[] exactCountingThreads;
	private ExactReaderThread exactReaderThread;
	private int threadQuantity;
	long limitK;
	static long globalCounter;
	
	public ExactCounting(String threadQuantity, String limitK) {
		this.threadQuantity = Integer.parseInt(threadQuantity);
		this.limitK = Long.parseLong(limitK);
		this.globalCounter = 0;
		// Instanciando o array de threads contadoras
		exactCountingThreads = new ExactCountingThread[this.threadQuantity];
	}
	
	public static void main (String[] args){
		// Contagem do tempo de execu��o
		long startTime = System.currentTimeMillis();

		/*
		 *  args[0]: n�mero de threads
		 *  args[1]: limite da soma total
		 */
		if(args.length <= 0) { return; }
		ExactCounting statisticCounting = new ExactCounting(args[0], args[1]);
	
		statisticCounting.execute(startTime);
	}

	private void execute(long startTime) {
		// Delay para acompanhar a execu��o via jconsole
		//					try {
		//					    Thread.sleep(10000);
		//					} catch(InterruptedException ex) {
		//					    Thread.currentThread().interrupt();
		//					}

		if(limitK >= Math.pow(2, 31)) {
			for(int i = 0; i < this.threadQuantity; i++) {
				// Par�metros da inst�ncia utilizada para o fastpath					
				this.exactCountingThreads[i] = new ExactCountingThread(this.limitK/this.threadQuantity);
				this.exactCountingThreads[i].start();

			}

			// Inicializa��o da thread leitora
			exactReaderThread = new ExactReaderThread(limitK, globalCounter, exactCountingThreads);
			exactReaderThread.start(startTime);
		}

		
	}
}
