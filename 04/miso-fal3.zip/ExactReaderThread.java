import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class ExactReaderThread implements Runnable {

	Thread thread;
	
	ExactCountingThread[] exactCountingThreads;
	public long limit;
	public long globalCounter;
	public long sum;

	boolean isAlive;

	private long startTime;
	
	public ExactReaderThread(long limit, long globalCounter, ExactCountingThread[] exactCountingThreads) {
		this.exactCountingThreads = exactCountingThreads;
		this.limit = limit;
		this.globalCounter = globalCounter;
		this.sum = 0;
	}

	public void start(long startTime){
		if(this.thread == null) {
			this.thread = new Thread(this);
			this.thread.start();
			this.isAlive = this.thread.isAlive();
			this.startTime = startTime;
		}
	}
	
	@Override
	public void run() {
		int i;
		while(globalCounter < this.limit) {
			this.sum = 0;
			for(i = 0; i < exactCountingThreads.length; i++) {
				sum += exactCountingThreads[i].getCount();
//				System.out.println("Soma Thread<"+exactCountingThreads[i].thread.getId()+">: "+exactCountingThreads[i].getCount());
			}
			this.globalCounter = sum;
		}
		
		this.stop();
		// Contagem do tempo de execu��o
		long estimatedTime = System.currentTimeMillis() - startTime;
		System.out.println(estimatedTime+"ms");
		System.out.println(this.globalCounter);

	}
	
	public void stop() {
		this.isAlive = false;
	}
}