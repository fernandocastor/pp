public class StatisticCounting {

	static StatisticCountingThread[] statisticCountingThreads;
	private StatisticReaderThread statisticReaderThread;
	private int threadQuantity;
	long limitK;
	static long globalCounter;
	
	public StatisticCounting(String threadQuantity, String limitK) {
		this.threadQuantity = Integer.parseInt(threadQuantity);
		this.limitK = Long.parseLong(limitK);
		this.globalCounter = 0;
		// Instanciando o array de threads contadoras
		statisticCountingThreads = new StatisticCountingThread[this.threadQuantity];
	}
	
	public static void main (String[] args){
		// Contagem do tempo de execu��o
		long startTime = System.currentTimeMillis();

		/*
		 *  args[0]: n�mero de threads
		 *  args[1]: limite da soma total
		 */
		if(args.length <= 0) { return; }
		StatisticCounting statisticCounting = new StatisticCounting(args[0], args[1]);
		statisticCounting.execute(startTime);
	}

	private void execute(long startTime) {
		// Delay para acompanhar a execu��o via jconsole
		//					try {
		//					    Thread.sleep(10000);
		//					} catch(InterruptedException ex) {
		//					    Thread.currentThread().interrupt();
		//					}

		if(limitK >= Math.pow(2, 31)) {
			for(int i = 0; i < threadQuantity; i++) {
				// Par�metros da inst�ncia utilizada para o fastpath					
				statisticCountingThreads[i] = new StatisticCountingThread(limitK/threadQuantity);
				statisticCountingThreads[i].start();

			}

			// Inicializa��o da thread leitora
			statisticReaderThread = new StatisticReaderThread(limitK, globalCounter, statisticCountingThreads);
			statisticReaderThread.start(startTime);
		}

		
	}
}
