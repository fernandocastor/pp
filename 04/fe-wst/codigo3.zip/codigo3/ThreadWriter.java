package trabalho04.q3.novo;

import java.util.concurrent.locks.Lock;

public class ThreadWriter extends Thread {

	private CounterObject co;
	private long id;
	private Lock lock;

	public ThreadWriter(CounterObject c, int id, Lock l) {
		this.co = c;
		this.id = id;
		this.lock = l;
	}

	@Override
	public void run() {
		
		while (!Main.STOP) {
			this.add_count();
		}
		//System.out.println("final fuderoso!!! = " + Main.GLOBALCOUNT);
	}

	public void add_count() {

		long c;
		long cm;
		boolean slowpath = false;

		do {

			c = this.co.getCounter().getCounter();
			cm = this.co.getCountermax();
			if (c + Main.DELTA > cm) {
				slowpath = true;
				break;
			}

		} while (!this.co.compareAndChange(c, cm, c + Main.DELTA, cm));

		if (slowpath) {

			boolean go = true;
			this.lock.lock();
			this.globalize_count();

			if (Main.GLOBALCOUNTMAX - Main.GLOBALCOUNT - Main.GLOBALRESERVE < Main.DELTA) {
				
				this.flush_local_count();
				if (Main.GLOBALCOUNTMAX - Main.GLOBALCOUNT - Main.GLOBALRESERVE < Main.DELTA) {
					this.lock.unlock();
					go = false;
				}
			}

			if (go) {
				Main.GLOBALCOUNT = Main.GLOBALCOUNT + Main.DELTA;
				this.balance_count();
				this.lock.unlock();
			}
		}
	}

	public void balance_count() {

		long c = 0;
		long cm = 0;

		long limit = Main.GLOBALCOUNTMAX - Main.GLOBALCOUNT - Main.GLOBALRESERVE;
		
		// TODO: threads dont die!!
		limit = limit / Main.N_THREADS;

		cm = limit;

		Main.GLOBALRESERVE = Main.GLOBALRESERVE + cm;

		c = cm / 2;

		if (c > Main.GLOBALCOUNT) {
			c = Main.GLOBALCOUNT;
		}

		Main.GLOBALCOUNT = Main.GLOBALCOUNT - c;
		
//		if (Main.GLOBALCOUNT < 0) {
//			Main.GLOBALCOUNT = 0;
//			// Main.GLOBALCOUNT = Main.GLOBALCOUNT * -1;
//		}

		this.co.atomic_set(c, cm);
	}

	public void globalize_count() {

		Main.GLOBALCOUNT = Main.GLOBALCOUNT + this.co.getCounter().getCounter();
		Main.GLOBALRESERVE = Main.GLOBALRESERVE - this.co.getCountermax();
		// if (Main.GLOBALRESERVE < 0) {
		// Main.GLOBALRESERVE = 0;
		// }

		this.co.atomic_set(0, 0);
	}

	public void flush_local_count() {

		if (Main.GLOBALRESERVE == 0) {
			return;
		}

		for (ThreadWriter t : Main.THREADS) {

			// TODO: verificar aqui!!!
			// if (t.getCounter().getCounter().getCounter() != 0) {

			CounterObject tmp = t.co.atomic_change();
			
			Main.GLOBALCOUNT = Main.GLOBALCOUNT + tmp.getCounter().getCounter();
			Main.GLOBALRESERVE = Main.GLOBALRESERVE - tmp.getCountermax();
			
//			if (Main.GLOBALRESERVE < 0) {
//				Main.GLOBALRESERVE = 0;
//			}

			// }
		}
	}

	@Override
	public String toString() {
		return "ThreadCounter [id=" + id + "]";
	}

	public long getId() {
		return id;
	}

	public CounterObject getCounter() {
		return co;
	}

}
