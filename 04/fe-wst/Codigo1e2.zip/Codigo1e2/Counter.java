package trabalho04.q1;

public interface Counter
{
	public long getCounter();
	
	public void increment();
}
