package trabalho04.q1.counters;

import trabalho04.q1.Counter;

public class CounterLong implements Counter {
	
	private long counter = 0;

	public void increment() {
		++counter;
	}
	
	public long getCounter() {
		return counter;
	}

}
