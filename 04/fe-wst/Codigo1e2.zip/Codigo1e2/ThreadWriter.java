package trabalho04.q1;


public class ThreadWriter extends Thread {

	private Counter counter;
	private long id;

	public ThreadWriter(Counter c, int id) {
		this.counter = c;
		this.id = id;
	}

	
	@Override
	public void run() {
		
		while (true) {
			if (Thread.interrupted()) {
				break;
			}
			this.counter.increment();
//			System.out.println(this + " coutner = " + this.counter.getCounter());
		}

	}

	@Override
	public String toString() {
		return "ThreadCounter [id=" + id + "]";
	}
	
	public long getId() {
		return id;
	}

	public Counter getCounter() {
		return counter;
	}

}
