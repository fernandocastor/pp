package trabalho04.q1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import trabalho04.q1.counters.CounterAtomicInt;
import trabalho04.q1.counters.CounterAtomicLong;
import trabalho04.q1.counters.CounterDouble;
import trabalho04.q1.counters.CounterFloat;
import trabalho04.q1.counters.CounterInt;
import trabalho04.q1.counters.CounterLong;
import trabalho04.q1.counters.CounterVolatileAtomicInt;
import trabalho04.q1.counters.CounterVolatileAtomicLong;
import trabalho04.q1.counters.CounterVolatileDouble;
import trabalho04.q1.counters.CounterVolatileFloat;
import trabalho04.q1.counters.CounterVolatileInt;
import trabalho04.q1.counters.CounterVolatileLong;
import trabalho04.q1.counters.Counters;

public class Main {

	public static long N = 10;
	public static long K = 2147483648l;
	private static String COUNTER = Counters.LONG.toString();

	public static Counter getCounter() {
		Counters counterTypeEnum = Counters.valueOf(COUNTER);

		switch (counterTypeEnum) {
		case INT:
			return new CounterInt();
		case LONG:
			return new CounterLong();
		case DOUBLE:
			return new CounterDouble();
		case FLOAT:
			return new CounterFloat();
		case ATOMIC_INT:
			return new CounterAtomicInt();
		case ATOMIC_LONG:
			return new CounterAtomicLong();
		case VOLATILE_INT:
			return new CounterVolatileInt();
		case VOLATILE_LONG: 
			return new CounterVolatileLong();
		case VOLATILE_DOUBLE:
			return new CounterVolatileDouble();
		case VOLATILE_FLOAT:
			return new CounterVolatileFloat();
		case VOLATILE_ATOMIC_INT:
			return new CounterVolatileAtomicInt();
		case VOLATILE_ATOMIC_LONG:
			return new CounterVolatileAtomicLong();
		}
		
		return null;
	}

	public static void main(String[] args) throws InterruptedException {

		// args[0] = N (number of threads)
		// args[1] = K (limit of the sum of the counters)
		int n_args = args.length;
		if (n_args > 0) {
			N = Long.valueOf(args[0]);
			if (n_args > 1) {
				K = Long.valueOf(args[1]);
				if (n_args > 2) {
					COUNTER = args[2];
				}
			}
		}

		// create N writer threads
		List<ThreadWriter> threads = new ArrayList<ThreadWriter>();
		for (int x = 0; x < N; x++) {
			Counter c = getCounter();
			threads.add(new ThreadWriter(c, x));
		}

		// create the reader thread
		ThreadReader reader = new ThreadReader(threads);

		// start all of the threads
		reader.start();
		Iterator<ThreadWriter> i1 = threads.iterator();
		while (i1.hasNext()) {
			ThreadWriter mt = (ThreadWriter) i1.next();
			mt.start();
		}

	}

}
