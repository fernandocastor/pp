package trabalho04.q1.counters;

import trabalho04.q1.Counter;

public class CounterVolatileInt implements Counter {
	
	private volatile int counter = 0;

	public void increment() {
		++counter;
	}
	
	public long getCounter() {
		return counter;
	}

}
