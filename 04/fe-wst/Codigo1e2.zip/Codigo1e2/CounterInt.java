package trabalho04.q1.counters;

import trabalho04.q1.Counter;

public class CounterInt implements Counter {
	
	private int counter = 0;

	public void increment() {
		++counter;
	}
	
	public long getCounter() {
		return counter;
	}

}
