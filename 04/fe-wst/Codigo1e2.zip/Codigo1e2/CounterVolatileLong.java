package trabalho04.q1.counters;

import trabalho04.q1.Counter;

public class CounterVolatileLong implements Counter {
	
	private volatile long counter = 0;

	public void increment() {
		++counter;
	}
	
	public long getCounter() {
		return counter;
	}

}
