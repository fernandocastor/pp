package trabalho04.q1.counters;

import trabalho04.q1.Counter;

public class CounterDouble implements Counter {
	
	private double counter = 0;

	public void increment() {
		++counter;
	}
	
	public long getCounter() {
		return (long) counter;
	}

}
