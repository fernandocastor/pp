package trabalho04.q1.counters;

import java.util.concurrent.atomic.AtomicLong;

import trabalho04.q1.Counter;

public class CounterVolatileAtomicLong implements Counter {
	
	private volatile AtomicLong counter = new AtomicLong();

	public void increment() {
		counter.incrementAndGet();
	}
	
	public long getCounter() {
		return counter.get();
	}

}
