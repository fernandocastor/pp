package trabalho04.q1.counters;

import java.util.concurrent.atomic.AtomicInteger;

import trabalho04.q1.Counter;

public class CounterAtomicInt implements Counter {
	
	private AtomicInteger counter = new AtomicInteger();

	public void increment() {
		counter.incrementAndGet();
	}
	
	public long getCounter() {
		return counter.get();
	}

}
