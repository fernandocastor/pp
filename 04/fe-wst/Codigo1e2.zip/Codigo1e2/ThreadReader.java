package trabalho04.q1;

import java.util.ArrayList;
import java.util.List;

public class ThreadReader extends Thread {

	private List<ThreadWriter> threads = new ArrayList<ThreadWriter>();
	private long counter_global = 0;

	public ThreadReader(List<ThreadWriter> threads) {
		this.threads = threads;
	}

	@Override
	public void run() {
		while (true) {
			if (Thread.interrupted()) {
				break;
			}

			for (ThreadWriter t : threads) {
				counter_global = counter_global + t.getCounter().getCounter();
			}
			

			if (counter_global > Main.K) {
//				System.out.println("stop!!");
				for (ThreadWriter t : threads) {
					t.interrupt();
				}
				break;
			} 
		}
		System.out.println("counter global = " + counter_global);
	}

	public long getCounter_global() {
		return counter_global;
	}
	
	
}
