package trabalho04.q1.counters;

import trabalho04.q1.Counter;

public class CounterFloat implements Counter {
	
	private float counter = 0;

	public void increment() {
		++counter;
	}
	
	public long getCounter() {
		return (long) counter;
	}

}
