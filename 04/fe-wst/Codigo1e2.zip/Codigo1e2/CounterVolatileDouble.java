package trabalho04.q1.counters;

import trabalho04.q1.Counter;

public class CounterVolatileDouble implements Counter {
	
	private volatile double counter = 0;

	public void increment() {
		++counter;
	}
	
	public long getCounter() {
		return (long) counter;
	}

}
