package trabalho04.q1.counters;

import trabalho04.q1.Counter;

public class CounterVolatileFloat implements Counter {
	
	private volatile float counter = 0;

	public void increment() {
		++counter;
	}
	
	public long getCounter() {
		return (long) counter;
	}

}
