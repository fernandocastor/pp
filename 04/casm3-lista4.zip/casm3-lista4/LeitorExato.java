/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contadorestatistico;

/**
 *
 * @author Carlos
 */
public class LeitorExato extends Thread implements Runnable {

    private long contadorGlobal = 0;
    private double k;
    private ContadorExato vetor[];

    public LeitorExato(ContadorExato[] v, double k) {
        vetor = v;
        this.k = k;
    }

    public void run() {
        long delay = 0;
        while (contadorGlobal < k) {

            long start = System.currentTimeMillis();
            contadorGlobal = 0;
            for (int i = 0; i < vetor.length; i++) {
                contadorGlobal += vetor[i].getContadorLocal();
            }
            delay += System.currentTimeMillis() - start;

        }


        System.out.println(contadorGlobal);

        System.out.println("Tempo total leitura(Paralelizado)= " + delay + " (ms)");
    }

}
