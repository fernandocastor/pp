/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contadorestatistico;



/**
 *
 * @author Carlos
 */
public class ContadorExato extends Thread implements Runnable {


    private long k;
    private volatile long contadorLocal = 0;
    private int index;
    
    public ContadorExato(int index, long k) {
        this.index = index;
        this.k = k;
    }

    private void incrementaContador() {
            contadorLocal++;
    }

    public void run() {
        while(contadorLocal<k)
            incrementaContador();
    }

    /**
     * @return the contadorLocal
     */
    public double getContadorLocal() {
        return contadorLocal;
    }
}
