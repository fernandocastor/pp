/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package contadorestatistico;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Carlos
 */
public class ContadorEstatistico {

    /**
     * @param args the command line arguments
     */
  
    final static int N = 14;
    static double K;
    
    public static void main(String[] args) {
        K = Math.pow(2, 31);
        ContadorExato threads[] = new ContadorExato[N];
        long start = System.currentTimeMillis();
        threads[0] = new ContadorExato(0,  (long) (K/N)+(long) (K%N));
        threads[0].start();
        for(int i=1;i<N;i++){
            threads[i] = new ContadorExato(i, (long) (K/N));
            threads[i].start();
        }
        
        LeitorExato leitor = new LeitorExato(threads, K);
        leitor.start();
        try {
            leitor.join();
        } catch (InterruptedException ex) {
            //Logger.getLogger(ContadorEstatistico.class.getName()).log(Level.SEVERE, null, ex);
            Logger.getLogger(ContadorExato.class.getName()).log(Level.SEVERE, null, ex);
        }

        long delay = System.currentTimeMillis()- start;
        System.out.println("Tempo total(Paralelizado)= "+ delay +" (ms)");
    }
    

}
