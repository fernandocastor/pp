/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contadorestatistico;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 *
 * @author Carlos
 */
public class Contador extends Thread implements Runnable {

    private static boolean parar = false;
    
    private java.util.concurrent.atomic.AtomicLong contadorLocal = new AtomicLong(0);
    private int index;
    
    public Contador(int index) {
        this.index = index;
    }

    private void incrementaContador() {
            contadorLocal.incrementAndGet();
    }

    public static void parar(){
        parar = true;
    }
    
    public void run() {
        while(!parar)
            incrementaContador();
    }

    /**
     * @return the contadorLocal
     */
    public double getContadorLocal() {
        return contadorLocal.get();
    }
}
