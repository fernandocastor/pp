#!/bin/bash

value=$1 
multiplier=$2 
proc_qty=$3
sums_per_proc=$(($multiplier / $proc_qty))

for ((i = 1 ; i <= $proc_qty ; i++))
do 
	./mult.sh $value $sums_per_proc & 
done
 
wait
