#!/bin/bash

value=$1
multiplier=$2
result=0

for ((i = 1 ; i <= $multiplier ; i++))
do
	result=$(( result + value ))
done

echo "Result: $result"
