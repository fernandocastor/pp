public class MultiplicadorThreads {
	public static void main(String[] args) {
		try {
			long multiplicando = args.length >= 1 ? Long.parseLong(args[0]) : 1;
			long multiplicador = args.length >= 2 ? Long.parseLong(args[1]) : 2146839556;
			long numeroThreads = args.length >= 3 ? Long.parseLong(args[2]) : 4;

			long tinicio = System.currentTimeMillis();

			long qtdSomas = multiplicador / numeroThreads; //Quantidade de operaушes que cada thread deverр computar.
			long sobra = multiplicador % numeroThreads;

			Operadora [] operadoras = new Operadora[(int) numeroThreads];

			long resultado = 0;

			for(int i = 0; i < numeroThreads; i++){
				if(i == numeroThreads - 1) {
					operadoras[i] = new Operadora(qtdSomas+sobra, multiplicando);
					operadoras[i].start();
				}else {
					operadoras[i] = new Operadora(qtdSomas, multiplicando);
					operadoras[i].start();
				}
			}	
 

			for(int i = 0; i < numeroThreads; i++){
				operadoras[i].join();
				resultado = resultado + operadoras[i].pegarResultado();
			}	

       			long tfinal = System.currentTimeMillis();	
			
			System.out.println("duration=" + (tfinal - tinicio) + " ms");
			System.out.println("result=" + resultado);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

class Operadora extends Thread{

	private long multiplicando;
	private long multiplicador;
	private long resultado;

	public Operadora (long n, long m){
		resultado = 0;
		multiplicador = n;
		multiplicando = m;
	}


	public void multiplica(){
		for(int i = 0; i < multiplicador; i++)
			resultado = resultado + multiplicando;

	}

	public long pegarResultado(){
		return resultado;
	}

	public void run(){
		multiplica();
	}
}
