#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

typedef long int integer;

integer multiply(integer multiplier, integer value)
{
	integer i;
	integer result = 0;

	for(i = 0; i < multiplier; i++)

		result += value;

//	printf("partial=%ld\n", result);

	return result;

}

int main(int argc, char** argv)
{
	time_t start;
	time_t end;

	int proc_qty = 4;
	integer value = 1;
	integer multiplier = 2146839556;
	integer sums_per_proc = multiplier / proc_qty;
	integer remainder = multiplier % proc_qty;
	integer result = 0;
	integer partial_result = 0;

	pid_t* pids;
	int i;

	pids = malloc(sizeof(pid_t)*proc_qty);

	if(argc == 4)
	{
		value = atoll(argv[1]);
		multiplier = atoll(argv[2]);
		proc_qty = atoll(argv[3]);
		sums_per_proc = multiplier / proc_qty;
		remainder = multiplier % proc_qty;
	}

	start = time(NULL);

	for(i = 0; i < proc_qty; i++)
	{
		if(i == proc_qty - 1)
		{
			if((pids[i] = fork()) == 0)
				exit(multiply(sums_per_proc+remainder, value));
		}
		else
		{
			if((pids[i] = fork()) == 0)
				exit(multiply(sums_per_proc+remainder, value));
		}
	}

	for(i = 0; i < proc_qty; i++)
	{
		waitpid(pids[i], &partial_result, 0);
		result += WEXITSTATUS(partial_result);
	}

	end = time(NULL);

//	free(pids);

//	printf("%ld * %ld = %ld | %.2fs", value, multiplier, result, difftime(end, start));
//	printf("%d * %d = %d | %.2fs", value, multiplier, result, difftime(end, start));
	printf("duration=%.2fs\n", difftime(end, start));

	return 0;
}

