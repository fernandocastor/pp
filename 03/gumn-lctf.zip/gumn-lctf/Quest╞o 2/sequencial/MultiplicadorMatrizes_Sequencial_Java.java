package sequencial;

public class MultiplicadorMatrizes_Sequencial_Java {
	
	public static int[][] multiplicatMatrizes(int[][] a, int[][] b) {
		int[][] c = new int[a.length][b[0].length];
		
		for(int i=0; i<a.length; i++) {
			for(int j=0; j<b[0].length; j++) {
				c[i][j] = 0;
				
				for(int k=0; k<b.length; k++) {
					c[i][j] = c[i][j] + a[i][k] * b[k][j];
				}
			}
		}
		
		return c;
	}
	
	public static void main(String[] args) {
		long tempoInicial = System.nanoTime();
		
		int[][] a = {
			{2, 5, 9},
			{3, 6, 8}
		};
		
		int[][] b = {
			{2, 7},
			{4, 3},
			{5, 2}
		};
		
		int[][] c = MultiplicadorMatrizes_Sequencial_Java.multiplicatMatrizes(a, b);
		MultiplicadorMatrizes_Sequencial_Java.printMatriz(c);

		long tempoFinal = System.nanoTime();
		System.out.println("Tempo de execu��o: " + (tempoFinal - tempoInicial) + " nanosegundos.");
	}
	
	private static void printMatriz(int[][] m) {
		for(int i=0; i<m.length; i++) {
			System.out.print("[");
			
			for(int j=0; j<m[i].length; j++) {
				if(j==0)
					System.out.print(m[i][j]);
				else
					System.out.print(", " + m[i][j]);
			}
			
			System.out.println("]");
		}
	}
}
