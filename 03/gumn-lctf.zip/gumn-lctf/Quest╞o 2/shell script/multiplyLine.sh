#!/bin/bash

result=0

declare -A matrizA
matrizA[0,0]=2
matrizA[0,1]=5
matrizA[0,2]=9
matrizA[1,0]=3
matrizA[1,1]=6
matrizA[1,2]=8

declare -A matrizB
matrizB[0,0]=2
matrizB[0,1]=7
matrizB[1,0]=4
matrizB[1,1]=3
matrizB[2,0]=5
matrizB[2,1]=2

for (( c=0; c<$1; c++ ))
do
	result=$((result + ((${matrizA[$2,$c]} * ${matrizB[$c,$3]}))))
done

echo "Elemento C$2$3: $result"
