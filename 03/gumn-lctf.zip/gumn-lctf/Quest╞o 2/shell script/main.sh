#!/bin/bash

iA=2
jA=3

iB=3
jB=2

for (( i=0; i<$iA; i++ ))
do
	for (( j=0; j<$jB; j++ ))
	do
		./multiplyLine.sh $iB $i $j &
	done
done

wait
