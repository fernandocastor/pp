#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
	
	int a[2][3] = {
		{2, 5, 9},
		{3, 6, 8}
	};
	
	int b[3][2] = {
		{2, 7},
		{4, 3},
		{5, 2}
	};
	
	int c[2][2];
	int i, j, k;
	
	for(i=0; i<2; i++) {
		for(j=0; j<2; j++) {
			c[i][j] = 0;
			
			pid_t pid = fork();
			int status;
			
			if(pid==0) {
				for(k=0; k<3; k++) {
					c[i][j] = c[i][j] + a[i][k] * b[k][j];
				}
				
				printf("Elemento C%d%d: %d\n", i, j, c[i][j]);
				exit(0);
			} else {
				waitpid(pid, &status, 0);
			}
		}
	}
	
	return 1;
}
