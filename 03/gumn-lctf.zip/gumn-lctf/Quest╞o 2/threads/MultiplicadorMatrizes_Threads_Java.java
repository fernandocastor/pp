package threads;

public class MultiplicadorMatrizes_Threads_Java {
	
	public static int[][] multiplicatMatrizes(int[][] a, int[][] b) {
		//Cria a matriz que guardar� o resultado
		int[][] c = new int[a.length][b[0].length];
		
		//Cria um grupo de threads
		ThreadGroup g = new ThreadGroup("multiplicar-matrizes");
		
		//Percorre as linhas da matriz
		for(int i=0; i<a.length; i++) {
			//Cria e inicia uma thread para multiplicar cada linha da matriz
			Thread t = new Thread(g, new MultiplicarLinha(a, b, c, i));
			t.start();
		}
		
		//Espera as threads terminarem a invers�o
		while(g.activeCount()>0) {}
		
		//Retorna o resultado
		return c;
	}
	
	public static void main(String[] args) {
		long tempoInicial = System.nanoTime();
		
		int[][] a = {
			{2, 5, 9},
			{3, 6, 8}
		};
		
		int[][] b = {
			{2, 7},
			{4, 3},
			{5, 2}
		};
		
		int[][] c = MultiplicadorMatrizes_Threads_Java.multiplicatMatrizes(a, b);
		MultiplicadorMatrizes_Threads_Java.printMatriz(c);
		
		long tempoFinal = System.nanoTime();
		System.out.println("Tempo de execu��o: " + (tempoFinal - tempoInicial) + " nanosegundos.");
	}
	
	private static void printMatriz(int[][] m) {
		for(int i=0; i<m.length; i++) {
			System.out.print("[");
			
			for(int j=0; j<m[i].length; j++) {
				if(j==0)
					System.out.print(m[i][j]);
				else
					System.out.print(", " + m[i][j]);
			}
			
			System.out.println("]");
		}
	}
}
