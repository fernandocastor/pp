package threads;

public class MultiplicarLinha implements Runnable {
	private int[][] a, b, c;
	private int i;
	
	public MultiplicarLinha(int[][] a, int[][] b, int[][] c, int i) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.i = i;
	}
	
	public void run() {
		for(int j=0; j<b[0].length; j++) {
			c[i][j] = 0;
			
			for(int k=0; k<b.length; k++) {
				c[i][j] = c[i][j] + a[i][k] * b[k][j];
			}
		}
	}
}
