import java.util.Arrays;

public class Pintor {
	
	private int[] lista;
	
	public Pintor(int n) {
		lista = new int[n];
	}

	public void pintar() {
		for (int i = 0; i < lista.length; i++) {
			lista[i] = 1;
		}
	}
	
	@Override
	public String toString() {
		return "Pintor [lista=" + Arrays.toString(lista) + "]";
	}


	public static void main(String[] args) {
		

		
		int tamanhoLista = 1000;
		
		Pintor p = new Pintor(tamanhoLista);
		p.pintar();
		


	}

}
