import java.util.Arrays;

public class Pintor implements Runnable {
	
	private int[] lista;
	private int inicio;
	private int fim;
	
	public Pintor(int[] l, int i, int f) {
		this.lista = l;
		this.inicio = i;
		this.fim = f - 1;
	}

	public void pintar() {
		int numeroRepeticao = 0;
		for (int i = this.inicio; numeroRepeticao < this.fim + 1; i++) {
			lista[i] = 1;
			numeroRepeticao++;
		}
//		System.out.println(this);
	}
	
	@Override
	public void run() {
		this.pintar();
		
	}

	public int[] getLista() {
		return lista;
	}

	public void setLista(int[] lista) {
		this.lista = lista;
	}

	public int getInicio() {
		return inicio;
	}

	public void setInicio(int inicio) {
		this.inicio = inicio;
	}

	public int getFim() {
		return fim;
	}

	public void setFim(int fim) {
		this.fim = fim;
	}

	@Override
	public String toString() {
		return "Pintor [lista=" + Arrays.toString(lista) + "]";
	}


}
