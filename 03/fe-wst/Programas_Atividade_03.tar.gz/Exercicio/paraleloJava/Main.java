import java.util.ArrayList;
import java.util.List;


public class Main {

	static int tamanhoLista = 1000;
	static int nThreads = 10;
	static int[] lista;

	
	public static void main(String[] args) {

		long tempoInicio = System.currentTimeMillis();
		
		List<Thread> threads = new ArrayList<Thread>(nThreads);
		
		int tamanho = tamanhoLista / nThreads;
		lista = new int[tamanhoLista];
		
		for (int i = 1; i < nThreads + 1; i++) {

			int inicio = (i * tamanho) - tamanho;
			
			Runnable task = new Pintor(lista, inicio, tamanho);
			Thread pintor = new Thread(task);
			pintor.setName(String.valueOf(i));
			pintor.start();
			threads.add(pintor);
		}


		long tempoFinal = System.currentTimeMillis();
		//System.out.println("tempo duracao = " + (tempoFinal - tempoInicio) + " ms");
	}
}
