#!/bin/bash

tamanhoLista=1000
nThreads=10
lista=(0 ... 1000)

tamanho=$(($tamanhoLista / $nThreads))

for ((i = 1 ; i <= nThreads; i++))
do
	inicio=$(($i * $tamanho ))
        inicio=$(($inicio - $tamanho))
	./pintor.sh $tamanhoLista $nThreads $lista $inicio & 
done
 
wait
