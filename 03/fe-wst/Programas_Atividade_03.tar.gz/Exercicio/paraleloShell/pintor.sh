#!/bin/bash

tamanhoLista=$1
nThreads=$2
lista=$3
inicio=$4

tamanho=$(($tamanhoLista / $nThreads))


numeroRepeticao=0
for ((i = inicio ; $numeroRepeticao <= $tamanho ; i++))
do
	lista[$i]=1
	numeroRepeticao=$[$numeroRepeticao+1]
done


