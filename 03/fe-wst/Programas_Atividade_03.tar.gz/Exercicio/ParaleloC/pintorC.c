#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int vetor[1000];

int pintar(int inicio, int fim) {
	int numeroRepeticao = 0;
	for (int i = inicio; numeroRepeticao <= fim; i++) {
		vetor[i] = 1;
		numeroRepeticao++;
	}
	return 1;
}

void imprimir(){

	for(int i = 0; i < 10; i++)
	printf("%d ", vetor[i]);	
}

main()
{
   int nThreads=10;
   int tamanho = 1000/nThreads;

   pid_t* pids;
   pids = malloc(sizeof(pid_t)*nThreads);

for(int i = 0; i < 10; i++)
	
	for(int i = 1; i <= nThreads; i++){
		int inicio = (i * tamanho) - tamanho;
				if((pids[i-1] = fork()) == 0)
					pintar(inicio, tamanho);
			

	}

	for(int i = 0; i < nThreads; i++){
		wait(i);
	}

}

