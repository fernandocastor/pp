#!/usr/bin/env bash

./rayfork
echo "P6 512 512 255" > header
cat header rayfork-7.part rayfork-6.part rayfork-5.part rayfork-4.part rayfork-3.part rayfork-2.part rayfork-1.part rayfork-0.part > rayfork.ppm
rm rayfork-*.part
echo "work is done! raytraced image at rayfork.ppm"
