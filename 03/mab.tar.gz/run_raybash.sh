#!/usr/bin/env bash

# dependencies: GNU parallel (https://www.gnu.org/software/parallel/)

parallel --progress --colsep '\t' -j 8 -k -a raybash.input ./raybash {1} {2} > content
echo "P6 512 512 255" > header
cat header content  > raybash.ppm
echo "work is done! raytraced image at raybash.ppm"
