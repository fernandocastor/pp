#!/bin/sh


cd LennaB/src
javac Thread_Binarization.java
cd ../../

for i in 1 2 3
  do
    cd /home/varjao/workspace/

    python lenna_binary.py

    rm Q1.png
    rm Q2.png
    rm Q3.png
    rm Q4.png
    rm lenna.png

    python lenna_binary_thread.py

    rm Q1.png
    rm Q2.png
    rm Q3.png
    rm Q4.png
    rm lenna.png

    cd LennaB/src

    java Thread_Binarization
    
done  
