#!/usr/bin/env python
# -*- coding: latin-1 -*-

import Image
import datetime

image_file = Image.open("../Pictures/Lenna.png")
(width, height) = image_file.size

w, t = width/2, height/2
ext = ".png"

q1 = (0, 0, w, t)
q2 = (0, t, w, t + t)
q3 = (w, 0, t + t, w)
q4 = (w, t, w+w, t+t)

def convert_to_gray_scale(img, name):

  (region_width, region_height) = img.size
  new_region = Image.new("RGB", (region_width, region_height))
  nr = new_region.load()
  count = 0
  s = 0

  for x_pixels in xrange(region_width):
    for y_pixels in xrange(region_height):

      r = img.getpixel((x_pixels, y_pixels))[0]
      g = img.getpixel((x_pixels, y_pixels))[1]
      b = img.getpixel((x_pixels, y_pixels))[2]

      k = int(r * 0.3 + g * 0.59 + b * 0.11) # k is a gray scale
      count += 1
      s += k

  for x_pixels in xrange(region_width):
    for y_pixels in xrange(region_height):
      r = img.getpixel((x_pixels, y_pixels))[0]
      g = img.getpixel((x_pixels, y_pixels))[1]
      b = img.getpixel((x_pixels, y_pixels))[2]

      k = int(r * 0.3 + g * 0.59 + b * 0.11)
      if k >= (s/count):
        nr[x_pixels, y_pixels] = (0, 0, 0)
      else:
        nr[x_pixels, y_pixels] = (255, 255, 255)

  #new_region.save(name + ext)  removing this line to get only running time

print "################################Python - sequencial#####################"
region1 = image_file.crop(q1)
start1 = datetime.datetime.now()
convert_to_gray_scale(region1, "Q1")
print "Region 1:", datetime.datetime.now() - start1

region2 = image_file.crop(q2)
start2 = datetime.datetime.now()
convert_to_gray_scale(region2, "Q2")
print "Region 2", datetime.datetime.now() - start2

region3 = image_file.crop(q3)
start3 = datetime.datetime.now()
convert_to_gray_scale(region3, "Q3")
print "Region 3", datetime.datetime.now() - start3

region4 = image_file.crop(q4)
start4 = datetime.datetime.now()
convert_to_gray_scale(region4, "Q4")
end4 = datetime.datetime.now()
print "Region 4", end4 - start4
print "\n Total time:", end4 - start1

# Output file image
#result = Image.new("RGB", (width, height)) removing this line to get only running time

#for key, value in { q1:"Q1", q2:"Q2", q3:"Q3", q4:"Q4" }.iteritems(): removing this lines to get only running time
#  img = Image.open(value+ext)
#  result.paste(img, key)
  

#result.save("lenna"+ext)  removing this line to get only running time
