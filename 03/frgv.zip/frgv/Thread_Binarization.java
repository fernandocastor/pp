import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.imageio.ImageIO;

public class Thread_Binarization{

	static String ext = ".png";
	
	public static void main(String[] args) throws IOException, InterruptedException {
		// Open image
		BufferedImage image = ImageIO.read( Thread_Binarization.class.getResourceAsStream("/images/Lenna.png") );		
		int width = image.getWidth();
		int height = image.getHeight();
		int w = width / 2;
		int t = height / 2;
		System.out.println("##############################  Java - Threads  ##############################");
		// Call thread
		final BufferedImage region1 = image.getSubimage(0, 0, w, t);
		long start1 = System.nanoTime();
		Thread thread1 = new Thread(){
			public void run(){
				convert_to_gray_scale(region1, "Q1");
			}
		};		
		thread1.start();
		System.out.println("Region 1: " + (System.nanoTime() - start1)); 
		
		final BufferedImage region2 = image.getSubimage(0, t, w, t);
		long start2 = System.nanoTime();
		Thread thread2 = new Thread(){
			public void run(){
				convert_to_gray_scale(region2, "Q2");
			}
		};		
		thread2.start();
		System.out.println("Region 2: " + (System.nanoTime() - start2) ); 
		
		final BufferedImage region3 = image.getSubimage(w, 0, w, t);
		long start3 = System.nanoTime();
		Thread thread3 = new Thread(){
			public void run(){
				convert_to_gray_scale(region3, "Q3");
			}
		};		
		thread3.start();
		System.out.println("Region 3: " + (System.nanoTime() - start3)); 
		
		final BufferedImage region4 = image.getSubimage(w, t, w, t);
		long start4 = System.nanoTime();
		Thread thread4 = new Thread(){
			public void run(){
				convert_to_gray_scale(region4, "Q4");
			}
		};		
		thread4.start();
		long end4 = System.nanoTime();
		System.out.println("Region 4: " + (System.nanoTime() - start4));
		System.out.println("\n Total time: " + (end4 - start1));
		
		thread4.join();

		BufferedImage combined = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_BINARY);

		Graphics g = combined.getGraphics();
		g.drawImage(region1, 0, 0, null);
		g.drawImage(region2, 0, t, null);
		g.drawImage(region3, w, 0, null);
		g.drawImage(region4, w, t, null);

		ImageIO.write(combined, "PNG", new File("Lenna.png"));
	}
	
	// Method Binarization
	public static void convert_to_gray_scale(BufferedImage img, String name){
		
		BufferedImage new_region = img;
		int region_width = img.getWidth();
		int region_height = img.getHeight();
		
		try {
			int count = 0;
			int s = 0;
			
			for(int i=0; i < region_width; i++){
				for(int j=0; j < region_height; j++){
					Color c = new Color(img.getRGB(i,j));
					int r = c.getRed();
					int g = c.getGreen();
					int b = c.getBlue();
					
					int k = (int) (r * (float)0.3+ g * (float)0.59 + b * (float)0.11);
					count++;
					s += (int) k;
				}
			}
			
			for(int i=0; i < region_width; i++){
				for(int j=0; j < region_height; j++){
					Color c = new Color(img.getRGB(i,j));
					int r = c.getRed();
					int g = c.getGreen();
					int b = c.getBlue();
					
					int k = (int) (r * (float)0.3+ g * (float)0.59 + b * (float)0.11);
					
					if(k >= s/count){
						img.setRGB(i, j, new Color(0, 0, 0).getRGB());
					}else{
						img.setRGB(i, j, new Color(255, 255, 255).getRGB());
					}
				}
			}
			
			// Save image
			ImageIO.write(img, "PNG", new File(name + ext));
	
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
