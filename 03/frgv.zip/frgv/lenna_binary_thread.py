#!/usr/bin/env python
# -*- coding: latin-1 -*-

import Image
import datetime
from threading import Thread

image_file = Image.open("../Pictures/Lenna.png")
(width, height) = image_file.size

w, t = width/2, height/2
ext = ".png"

q1 = (0, 0, w, t)
q2 = (0, t, w, t + t)
q3 = (w, 0, w+w, t)
q4 = (w, t, w+w, t+t)

def threaded_convert_to_gray_scale(arg, name):

  img = arg
  (region_width, region_height) = img.size
  new_region = Image.new("RGB", (region_width, region_height))
  nr = new_region.load()
  count = 0
  s = 0

  for x_pixels in xrange(region_width):
    for y_pixels in xrange(region_height):

      r = img.getpixel((x_pixels, y_pixels))[0]
      g = img.getpixel((x_pixels, y_pixels))[1]
      b = img.getpixel((x_pixels, y_pixels))[2]

      k = int(r * 0.3 + g * 0.59 + b * 0.11) # k is a gray scale
      count += 1
      s += k

  for x_pixels in xrange(region_width):
    for y_pixels in xrange(region_height):
      r = img.getpixel((x_pixels, y_pixels))[0]
      g = img.getpixel((x_pixels, y_pixels))[1]
      b = img.getpixel((x_pixels, y_pixels))[2]

      k = int(r * 0.3 + g * 0.59 + b * 0.11)
      if k >= (s/count):
        nr[x_pixels, y_pixels] = (0, 0, 0)
      else:
        nr[x_pixels, y_pixels] = (255, 255, 255)

  #new_region.save(name + ext)  removing this line to get only running time

print "############################### Python - Threads ####################"
region1 = image_file.crop(q1)
start1 = datetime.datetime.now()
thread1 = Thread(target=threaded_convert_to_gray_scale, args=(region1, "Q1"))
thread1.start()
print "Region 1", datetime.datetime.now() - start1

region2 = image_file.crop(q2)
start2 = datetime.datetime.now()
thread2 = Thread(target=threaded_convert_to_gray_scale, args=(region2, "Q2"))
thread2.start()
print "Region 2", datetime.datetime.now() - start2

region3 = image_file.crop(q3)
start3 = datetime.datetime.now()
thread3 = Thread(target=threaded_convert_to_gray_scale, args=(region3, "Q3"))
thread3.start()
print "Region 3", datetime.datetime.now() - start3

region4 = image_file.crop(q4)
start4 = datetime.datetime.now()
thread4 = Thread(target=threaded_convert_to_gray_scale, args=(region4, "Q4"))
thread4.start()
end4 = datetime.datetime.now()
print "Region 4", end4 - start4
print "\n Total time:", end4 - start1

# Output file image
#result = Image.new("RGB", (width, height))         removing this line to get only running time
thread4.join() # Wait until the thread terminates
#for key, value in { q1:"Q1", q2:"Q2", q3:"Q3", q4:"Q4" }.iteritems():
#  img = Image.open(value+ext)
#  result.paste(img, key)
  
#result.save("lenna"+ext)
