package br.ufpe.cin.sequentialcc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Sequential version of charcount
 * 
 * @author frsoares
 * 
 */
public class Main {

	private static String[] args = new String[] { "1.txt", "2.txt", "3.txt",
			"4.txt" };

	private String filename;

	private long count;

	public String getFilename() {
		return filename;
	}

	public long getCount() {
		return count;
	}

	public Main(String filename) {
		this.filename = filename;
		this.count = 0;
	}

	public static void main(String[] argvs) {

		long count = 0;

		for (String arg : args) {
			File f = new File(arg);

			// System.out.println("Reading `" + arg + "'.");

			if (f.isFile()) {
				try {
					Scanner sc = new Scanner(f, "ISO8859_1");

					while (sc.hasNextLine()) {
						count += sc.nextLine().length() + 1; // +1 for the
																// line-break
					}
					sc.close();

				} catch (FileNotFoundException e) {
					System.out.println("File `" + arg + "' not found.");
				}

			} else {
				System.out.println("`" + arg + "' is not a file.");
			}
		}

		System.out.println("\nThe sum of characters in all files is: " + count
				+ "\n");

	}

}
