package br.ufpe.cin.parcc;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * Parallel version of charcount
 * 
 * @author frsoares
 * 
 */
public class Main extends Thread {

	private static String[] args = new String[] { "1.txt", "2.txt", "3.txt",
			"4.txt" };

	private String filename;

	private long count;

	public String getFilename() {
		return filename;
	}

	public long getCount() {
		return count;
	}

	public Main(String filename) {
		this.filename = filename;
		this.count = 0;
	}

	public static void main(String[] argvs) {

		LinkedList<Main> ex = new LinkedList<Main>();

		long count = 0;

		for (String arg : args) {
			Main m = new Main(arg);

			m.start();

			ex.add(m);
		}

		for (Main m : ex) {
			try {
				m.join();
				count += m.getCount();
			} catch (InterruptedException e) {
				System.out.println("Thread interrupted while processing file `"
						+ m.getFilename() + "'.");
			}
		}

		System.out.println("\nThe sum of characters in all files is: " + count
				+ "\n");

	}

	@Override
	public void run() {

		File f = new File(filename);

		if (f.isFile()) {
			try {
				Scanner sc = new Scanner(f, "ISO8859_1");

				while (sc.hasNextLine()) {
					count += sc.nextLine().length() + 1; // +1 for the
															// line-break
				}
				sc.close();

			} catch (FileNotFoundException e) {
				System.out.println("File `" + filename + "' not found.");
			}

		} else {
			System.out.println("`" + filename + "' is not a file.");
		}

	}

}
