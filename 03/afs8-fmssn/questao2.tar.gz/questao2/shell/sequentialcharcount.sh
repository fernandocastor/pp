#!/bin/bash

RESULT=0

for i in `ls *.txt`; do

  RESULT=$(($RESULT+`wc --chars < $i`)) 

done

echo ""
echo "The sum of characters in all files is: "$RESULT
echo ""
