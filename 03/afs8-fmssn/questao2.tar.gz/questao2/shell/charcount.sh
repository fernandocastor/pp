#!/bin/bash



for i in `ls *.txt`; do

  wc --chars < $i > $i.counting &

done

wait

RESULT=0

for i in `ls *.txt.counting`; do
  RESULT=$(($RESULT+`cat $i`))
done

echo ""
echo "The sum of characters in all files is: "$RESULT
echo ""
