#include<stdlib.h>
#include<stdio.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<errno.h>


/*

Parallel version of charcount.

Based initially on: http://www.c-program-example.com/2011/10/c-program-to-count-number-of-characters.html

*/


const char* args[] = {"1.txt", "2.txt", "3.txt", "4.txt"};

const char* outs[] = {"1.txt.counting", "2.txt.counting", "3.txt.counting", "4.txt.counting"};



void waitall(void){

  int pid;
  int status;
  for(;;){
    pid = wait(&status);
    if(pid==-1){
      if(errno == ECHILD){
        break;
      }
      perror("wait");
      exit(-1);
    }
  }

}


void recordcount(char* filename, int count){

 FILE* fptr=fopen(filename,"w");
 if(fptr==NULL)
 {
  printf("File can't be created\a");
  exit(0);
 }
 fprintf(fptr, "%d",count);
 fclose(fptr);

}

int getcount(char* filename){
 
  int count = -1;

  FILE* file = fopen(filename,"r");
  
  if(file==NULL){
    printf("error! File `%s' not opened for read.",filename);
  }
  else{
    while(fscanf(file,"%d", &count)!=EOF){
    }
    fclose(file);
  }
  
  return count;
}

int countchars(char* filename){

  char ch;
  int count = 0;

  FILE * fptr = fopen(filename,"r");


//  printf("\nContents of the File is:");
  while((ch=fgetc(fptr))!=EOF)
  {
   count++;
//   printf("%c",ch);
  }

  fclose(fptr);  

  return count;
}

int main(int arg)
{
 char ch;
 int count=0;
 int i, pid;

 for (i = 0; i<4; i++){

  // FORK DA THREAD.
  pid = fork();

  if (pid == 0) {
    /* child */
    char* filename = args[i];
    
    count = countchars(filename);
    
    recordcount(outs[i], count);
    
//    printf("%s\n",filename);
    
    exit(0);
  }
  else if (pid<0){
    /* parent, upon error */
    perror("fork");
    exit(-1);
  }
  else{
    continue;
  }
 }

 waitall();

 for (i = 0; i<4; i++){
   count += getcount(outs[i]);
 }


 printf("\nThe sum of characters in all files is: %d\n\n",count);
// printf("\n length of args: %s\n", args[2]);
}



