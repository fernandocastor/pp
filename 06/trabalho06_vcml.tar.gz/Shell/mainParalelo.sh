#!/bin/bash

OUTPUT="/tmp/.test2"
mkfifo $OUTPUT &> /dev/null  

array=(0)

# setValores $t $array $inicio $fim & 
setValores()
{

	#echo "begin $1"
	echo "setValores $1" > $OUTPUT &
	#echo "end $1"

	num=8
	for ((i=$3;i<$4;i++))
    	do
    	  eval '(('$2'[i]=$num))'
	done
}


tamanhoLista=1000000
nThreads=4
tamanho=$(($tamanhoLista/$nThreads))

for ((t = 1 ; t<= nThreads; t++))
do
	inicio=$(($t * $tamanho))
        inicio=$(($inicio - $tamanho))
	fim=$(($inicio+$tamanho))
	setValores $t array $inicio $fim & 
done

# we wait for all the child processes to finish
#echo waiting
wait
#echo done waiting

# then we read the output
cat $OUTPUT
rm $OUTPUT

#echo ${array[@]}




