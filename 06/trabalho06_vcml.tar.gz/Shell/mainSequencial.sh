#!/bin/bash

setValores()
{   	
	for ((i=$3;i<$4;i++))
    	do
    	  eval '(('$1'[i]=$2))'
	done
} 


Array=(0)
tamanhoLista=1000000
nThreads=1
num=8
tamanho=$(($tamanhoLista / $nThreads))

#echo ${Array[@]}
for ((t = 1 ; t <= nThreads; t++))
do
	inicio=$(($t * $tamanho))
        inicio=$(($inicio - $tamanho))
	fim=$((inicio+$tamanho))
	setValores Array $num $inicio $fim $t
#	echo "inicio" $inicio
#	echo "fim " $fim
#	echo "nThreads" $nThreads
#	echo "j" $t

done

wait

#echo ${Array[@]}

#setValores Array $num $inicio $fim

