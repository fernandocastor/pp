#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
// 1000000
int array[1000000];
int valor = 8;
int nThreads=4;


int setValores(int inicio, int fim) {

    //printf("Inicio %d ", inicio);
    //printf("Fim %d ", fim);
    //printf("\n ", fim);

	int i;
	for (i = inicio; i < fim; i++) {
		array[i] = valor;
	}
	return valor;
}

void imprimir()
{
	int i;
	int tamanhoArray = sizeof(array) / sizeof(array[0]);
	printf("Printing: ");
	for(i = 0; i < tamanhoArray; i++){
        printf("%d ", array[i]);
    }
    printf("\n");
}

main()
{

   int tamanhoArray = sizeof(array) / sizeof(array[0]);
   int tamanhoSet = tamanhoArray/nThreads;
   // printf("%d ", tamanhoSet);

   pid_t* pids;  // The pid_t data type is a signed integer type which is capable of representing a process ID. In the GNU library, this is an int.
   pids = malloc(sizeof(pid_t)*nThreads);
    // printf("Teste");
    // for(int i = 0; i < 10; i++)
    int i;
    for(i = 1; i <= nThreads; i++)
    {
        int inicio = (i * tamanhoSet) - tamanhoSet;
        int fim = inicio + tamanhoSet;
            if((pids[i-1] = fork()) == 0) // When fork() returns 0, we are in the child process.
            {
                setValores(inicio, fim); /* Code executed by child */
                // imprimir();
                exit(EXIT_SUCCESS);
            }
            //else
            //{
            //    break;
            //}
    }

    // imprimir();

    // i = 0;
	for(i = 0; i < nThreads; i++)
	{
        int status;
        (void)waitpid(pids[i], &status, 0);
        // printf("pid %d ", pids[i]);
        // printf("status %d ", status);
		// wait(&pids[i]);
	}

    //printf("My process ID : %d\n", getpid());
    //printf("My parent's ID: %d\n", getppid());
    //pid_t wpid;
    //int status = 0;
    //while ((wpid = wait(&status)) > 0);

    //sleep(10);
	//imprimir();
	// exit(EXIT_SUCCESS);
}

