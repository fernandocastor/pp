#include <stdio.h>
#include <stdlib.h>

int array[1000000];
int valor = 8;

int setValores(int inicio, int fim) {
    //printf("Inicio %d ", inicio);
    //printf("Fim %d ", fim);
    //printf("\n ", fim);

	int i;
	for (i = inicio; i < fim; i++) {
		array[i] = valor;
	}
	return valor;
}

void imprimir()
{
	int i;
	int tamanhoArray = sizeof(array) / sizeof(array[0]);
	printf("Printing: ");
	for(i = 0; i < tamanhoArray; i++){
        printf("%d ", array[i]);
    }
    printf("\n");
}


main()
{
    int tamanhoArray = sizeof(array) / sizeof(array[0]);
    int inicio = 0;
    setValores(inicio, tamanhoArray);
    // imprimir();
}
