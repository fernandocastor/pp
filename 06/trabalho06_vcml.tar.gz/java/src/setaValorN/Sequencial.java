package setaValorN;

import java.util.Arrays;

public class Sequencial {

	/**
	 * @param args
	 */
	private int[] array;
	private int num;
	
	public Sequencial(int[] array, int num) {
		this.array = array;
		this.num = num;
	}

	public void setValores() {
		for (int i = 0; i < array.length; i++) {
			array[i] = num;
		}
	}
	
	@Override
	public String toString() {
		return "Result [Array=" + Arrays.toString(array) + "]";
	}
	

}
