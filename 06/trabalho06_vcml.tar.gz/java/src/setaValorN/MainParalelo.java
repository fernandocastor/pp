package setaValorN;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainParalelo {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		// Parametros gerais
		int tamanhoArray = 1000000;
		int numSet = 8;
		int nThreads = 4;
		
		long tempoInicio = System.currentTimeMillis();		
		List<Thread> threads = new ArrayList<Thread>(nThreads);
		
		int []arrayPar = new int[tamanhoArray];
		int tamanhoSet = tamanhoArray / nThreads;   
		
		for (int i = 1; i <= nThreads; i++) {

			int inicio = (i * tamanhoSet) - tamanhoSet;
			int fim = inicio + tamanhoSet;
			
			//System.out.println("Inicio: " + inicio);
			//System.out.println("Fim: " + fim);
			
			// Runnable task = new Paralelo(arrayPar, inicio, fim, numSet);
			Runnable task = new Paralelo(arrayPar, inicio, fim, numSet);
			Thread t = new Thread(task);
			t.setName(String.valueOf(i));
			t.start();
			threads.add(t);
			
			// System.out.println(task.toString());
		}
		// System.out.println(t.toString());
		
		
		for (Thread t : threads)
		    t.join();
		// After this for loop, you can be sure all threads have finished their jobs.

		long tempoFinal = System.currentTimeMillis();
		System.out.println("tempo duracao = " + (tempoFinal - tempoInicio) + " ms");
		//System.out.println("Result [Array=" + Arrays.toString(arrayPar) + "]");
	}

}
