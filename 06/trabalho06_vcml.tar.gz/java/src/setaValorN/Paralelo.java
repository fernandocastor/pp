package setaValorN;

import java.util.Arrays;

public class Paralelo implements Runnable {
	
	private int[] array;
	private int inicio;
	private int fim;
	private int num;
	
	public Paralelo(int[] array, int i, int f, int num) {
		this.array = array;
		this.inicio = i;
		this.fim = f;
		this.num = num;
	}

	public void setValores() 
	{		
		for (int i = this.inicio; i < this.fim; i++) 
		{
			array[i] = num;			
		}
//		System.out.println(this);
	}
	
	@Override
	public void run()
	{
		this.setValores();		
	}
	

	@Override
	public String toString() {
		return "Result [Array=" + Arrays.toString(array) + "]";
	}


}

