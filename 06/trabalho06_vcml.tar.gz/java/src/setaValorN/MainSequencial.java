package setaValorN;

import java.util.ArrayList;
import java.util.List;

public class MainSequencial {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Parametros gerais
		int tamanhoArray = 1000000;
		int numSet = 8;
		int []array = new int[tamanhoArray];
		
		// Sequencial
		long tempoInicioSeq = System.currentTimeMillis();
		Sequencial p = new Sequencial(array, numSet);
		p.setValores();
		// System.out.println(p.toString());
		long tempoFinalSeq = System.currentTimeMillis();
		System.out.println("tempo duracao = " + (tempoFinalSeq - tempoInicioSeq) + " ms");
				

	}

}
