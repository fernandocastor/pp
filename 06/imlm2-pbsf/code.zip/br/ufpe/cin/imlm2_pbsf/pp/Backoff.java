package br.ufpe.cin.imlm2_pbsf.pp;

import java.util.Random;

public class Backoff {

	private final Random random;
	private final int minDelay;
	private final int maxDelay;
	private final IncreaseStrategy increaseStrategy;
	private int limit;

	public Backoff(int minDelay, int maxDelay, IncreaseStrategy increaseStrategy) {
		this.minDelay = minDelay;
		this.maxDelay = maxDelay;
		this.increaseStrategy = increaseStrategy;
		this.limit = this.minDelay;
		this.random = new Random();
	}

	public void backoff() throws InterruptedException {
		final int delay = random.nextInt(limit);
		limit = Math.min(maxDelay, increaseStrategy.increase(limit));
		Thread.sleep(delay);
	}

	public void reset() {
		this.limit = this.minDelay;
	}

	@FunctionalInterface
	public static interface IncreaseStrategy {
		int increase(int i);
	}
}
