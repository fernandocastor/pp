package br.ufpe.cin.imlm2_pbsf.pp.locks;

import java.util.concurrent.atomic.AtomicBoolean;

import br.ufpe.cin.imlm2_pbsf.pp.Backoff;
import br.ufpe.cin.imlm2_pbsf.pp.Backoff.IncreaseStrategy;

public class CASBackoffLock extends BaseLock {

	private static final int DEFAULT_MIN_DELAY = 10;
	private static final int DEFAULT_MAX_DELAY = 100;

	private final ThreadLocal<Backoff> backoffThreadLocal;

	private final AtomicBoolean state;

	public CASBackoffLock() {
		this((int i) -> i * 2, DEFAULT_MIN_DELAY, DEFAULT_MAX_DELAY);
	}

	public CASBackoffLock(IncreaseStrategy strategy, int min, int max) {
		this.state = new AtomicBoolean(false);
		this.backoffThreadLocal = new ThreadLocal<Backoff>() {
			@Override
			protected Backoff initialValue() {
				return new Backoff(min, max, strategy);
			}
		};
	}

	@Override
	public void lock() {
		final Backoff backoff = backoffThreadLocal.get();
		while(!state.compareAndSet(false, true)) {
			try {
				backoff.backoff();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		backoff.reset();
	}

	@Override
	public void unlock() {
		state.set(false);
	}

}
