package br.ufpe.cin.imlm2_pbsf.pp.locks;

import java.util.concurrent.atomic.AtomicInteger;

public class Alock extends BaseLock {

	private final ThreadLocal<Integer>  mySlotIndex;
	private final AtomicInteger tail;
	private volatile boolean[] flag;
	private final int size;

	public Alock(int capacity) {
		this.size = capacity;
		tail = new AtomicInteger(0);
		flag = new boolean[capacity];
		flag[0] = true;
		mySlotIndex = new ThreadLocal<Integer>() {
			@Override
			protected Integer initialValue() {
				return 0;
			}
		};
	}

	@Override
	public void lock() {
		int myIndex = tail.getAndIncrement() % size;
		mySlotIndex.set(myIndex);
		while(!flag[myIndex]);
	}

	@Override
	public void unlock() {
		final Integer myIndex = mySlotIndex.get();
		flag[myIndex] = false;
		flag[(myIndex + 1) % size] = true;
	}

}
