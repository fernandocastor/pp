package br.ufpe.cin.imlm2_pbsf.pp.benchmarks;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import br.ufpe.cin.imlm2_pbsf.pp.Backoff.IncreaseStrategy;
import br.ufpe.cin.imlm2_pbsf.pp.locks.Alock;
import br.ufpe.cin.imlm2_pbsf.pp.locks.CASBackoffLock;
import br.ufpe.cin.imlm2_pbsf.pp.locks.QueueLock;
import br.ufpe.cin.imlm2_pbsf.pp.locks.TASBackoffLock;
import br.ufpe.cin.imlm2_pbsf.pp.locks.TASLock;

public class Benchmarks {

	public static class Counter {
		private final Lock lock;
		@SuppressWarnings("unused")
		private long counter;

		public Counter(Lock lock, long counter) {
			this.lock = lock;
			this.counter = counter;
		}

		public void increment() {
			lock.lock();
			counter++;
			lock.unlock();
		}
	}

	public static class CounterThread extends Thread {
		private final Counter[] counters;
		private final int countersLength;
		private final StopCriteria stopCriteria;
		private final Random random;

		private int incrementCount;

		protected CounterThread(Counter[] counters, StopCriteria crit) {
			this.counters = counters;
			this.countersLength = this.counters.length;
			this.stopCriteria = crit;
			this.random = new Random();
		}

		@Override
		public void run() {
			while(!stopCriteria.stop(this)) {
				final int counterIndex = random.nextInt(countersLength);
				counters[counterIndex].increment();
				incrementCount++;
			}
		}

		public int getIncrementCount() {
			return incrementCount;
		}
	}

	@FunctionalInterface
	public static interface StopCriteria {
		boolean stop(CounterThread counter);
	}

	public static class SimpleStopCriteria implements StopCriteria {

		private volatile boolean stop;

		@Override
		public boolean stop(CounterThread counter) {
			return stop;
		}

		public void setStop(boolean stop) {
			this.stop = stop;
		}
	}

	public static void main(String[] args) throws InterruptedException {
		final BenchmarkParams params = parse(args);
		final IncreaseStrategy strat;
		if("add".equalsIgnoreCase(params.increaseStrategy))
			strat = (int i) -> i + 10;
		else
			strat = (int i) -> i * 2;

		final String lockType = params.lockType != null ? params.lockType : "backoff";
		final int min = params.minimumBackoffDelay > 0 ? params.minimumBackoffDelay : 30;
		final int max = params.maximumBackoffDelay > 0 ? params.maximumBackoffDelay : 120;
		final int numberOfCounters = params.numberOfCounters > 0 ? params.numberOfCounters : 10;
		final Counter[] counters = new Counter[numberOfCounters];
		for (int i = 0; i < counters.length; i++) {
			final Lock lock;
			if("queue".equalsIgnoreCase(lockType)){
				lock = new QueueLock();
			} else if("cas".equalsIgnoreCase(lockType)){
				lock = new CASBackoffLock(strat, min, max);
			} else if("tas".equalsIgnoreCase(lockType)){
				lock = new TASLock();
			} else if("reentrant".equalsIgnoreCase(lockType)){
				lock = new ReentrantLock();
			} else if("array".equalsIgnoreCase(lockType)){
				lock = new Alock(params.numberOfThreads);
			} else {
				lock = new TASBackoffLock(strat, min, max);
			}
			counters[i] = new Counter(lock, 0);
		}

		final StopCriteria crit;
		if("count".equalsIgnoreCase(params.stopCriteria))
			crit = (CounterThread c) -> c.incrementCount >= 1000;
		else 
			crit = new SimpleStopCriteria();
		final List<CounterThread> threads = new ArrayList<>();
		for (int i = 0; i < params.numberOfThreads; i++) {
			threads.add(new CounterThread(counters, crit));
		}
		final long start = System.currentTimeMillis();
		for (CounterThread counterThread : threads) {
			counterThread.start();
		}
		if(crit instanceof SimpleStopCriteria) {
			while((System.currentTimeMillis() - start) < 120000);
			((SimpleStopCriteria) crit).setStop(true);
		}
		for (CounterThread counterThread : threads) {
			counterThread.join();
		}

		for (CounterThread counterThread : threads) {
			final int incrementCount = counterThread.getIncrementCount();
			System.out.println(incrementCount);
		}
		System.out.println("\n");
	}

	private static class BenchmarkParams {
		private int numberOfThreads;
		private int minimumBackoffDelay;
		private int maximumBackoffDelay;
		private int numberOfCounters;
		private String lockType;
		private String stopCriteria;
		private String increaseStrategy;
		@Override
		public String toString() {
			return "BenchmarkParams [numberOfThreads=" + numberOfThreads
					+ ", minimumBackoffDelay=" + minimumBackoffDelay
					+ ", maximumBackoffDelay=" + maximumBackoffDelay
					+ ", numberOfCounters=" + numberOfCounters + ", lockType="
					+ lockType + ", stopCriteria=" + stopCriteria
					+ ", increaseStrategy=" + increaseStrategy + "]";
		}
	}

	private static BenchmarkParams parse(String[] args) {
		BenchmarkParams params = new BenchmarkParams();
		for (int i = 0; i < args.length - 1; i++) {
			String token = args[i];
			if("-threads".equals(token)) {
				params.numberOfThreads = Integer.parseInt(args[++i]);
			} else if("-min".equals(token)) {
				params.minimumBackoffDelay = Integer.parseInt(args[++i]);
			} else if("-max".equals(token)) {
				params.maximumBackoffDelay = Integer.parseInt(args[++i]);
			} else if("-lock".equals(token)) {
				params.lockType = args[++i];
			} else if("-stop".equals(token)) {
				params.stopCriteria = args[++i];
			} else if("-inc".equals(token)) {
				params.increaseStrategy = args[++i];
			} else if("-counters".equals(token)) {
				params.numberOfCounters = Integer.parseInt(args[++i]);
			}	else {
				throw new IllegalArgumentException(String.format("Invalid parameter '%s'", token));
			}
		}
		return params;
	}
}
