/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package teste;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Carlos
 */
public class TestaBackOff {
    private static final int N = 50;
    
    public static void main(String args[]){
        long start = System.currentTimeMillis();
        for(int i=0;i<N;i++){
            new Contador(start,i).start();
        }
        
        /*
        try {
            Thread.sleep(120000);
        } catch (InterruptedException ex) {
            Logger.getLogger(TestaBackOff.class.getName()).log(Level.SEVERE, null, ex);
        }
                */
    }
}
