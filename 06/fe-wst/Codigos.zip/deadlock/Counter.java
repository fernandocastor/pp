package trabalho06.ttas.deadlock;

public class Counter {

	private double counter = 0;
	private int id;
	private DeadLockLock lock;

	public Counter(int id) {
		this.id = id;
		this.lock = new DeadLockLock();
	}

	public void incrementa() {
		this.counter++;
	}
	
	public DeadLockLock getLock() {
		return lock;
	}

	@Override
	public String toString() {
		return "C" + id + "->" + counter;
	}
}
