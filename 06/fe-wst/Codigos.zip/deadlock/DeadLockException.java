package trabalho06.ttas.deadlock;

public class DeadLockException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public DeadLockException() {
		super();
	}
}
