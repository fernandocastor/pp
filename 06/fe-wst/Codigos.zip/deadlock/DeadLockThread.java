package trabalho06.ttas.deadlock;

public class DeadLockThread extends Thread {

	private Counter[] contadores = null;
	private double count = 0;
	private int id;

	public DeadLockThread(Counter[] c, int id) {
		this.contadores = c;
		this.id = id;
	}

	// @Override
	// public void run() {
	//
	// while (true)
	// {
	// int random = (int) (Math.random() * 10);
	// this.contadores[random].incrementa();
	// this.count++;
	// }
	// }

	@Override
	public void run() {

		while (this.count < 1000)
		{
			int random = (int) (Math.random() * 2);

			if (this.contadores[random].getLock().tryLock())
			{
				if (this.contadores[(random - 1) & 1].getLock().tryLock())
				{
					this.contadores[random].incrementa();
					this.contadores[(random - 1) & 1].incrementa();
					this.contadores[random].getLock().unlock();
					this.contadores[(random - 1) & 1].getLock().unlock();
					this.count++;
				}
				else
				{
					try
					{
						this.contadores[random].getLock().unlock();
						throw new DeadLockException();
					}
					catch (DeadLockException e)
					{
						e.printStackTrace();
						return;
					}
				}
			}
		}
	}

	@Override
	public String toString() {
		return "T" + id + "->" + count;
	}
}
