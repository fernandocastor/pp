package trabalho06.queue;

import java.util.ArrayList;
import java.util.List;

public class Main {

	private static final int NUMBER_THREADS = 100;
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		
		try
		{
			Counter[] contadores = new Counter[10];
			initializeCounters(contadores);
			
			List<MCSQueueThread> threads = new ArrayList<MCSQueueThread>();
			
			for (int i = 0; i < NUMBER_THREADS; i++)
			{
				threads.add(new MCSQueueThread(contadores, i));
			}
			
			
			for (MCSQueueThread test : threads)
			{
				test.start();
			}
			
//			Thread.sleep(120000);
//			
//			for (MCSQueueThread test : threads)
//			{
//				test.stop();
//			}
			
			for (MCSQueueThread test : threads)
			{
				test.join();
			}
			
			printResults(contadores);
			printThreadResults(threads);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}

	}

	public static void printThreadResults(List<MCSQueueThread> threads) {
		System.out.println("thread results: " + threads);
	}
	
	public static void printResults(Counter[] contadores) {
		String s = "";
		for (int i = 0; i < contadores.length; i++)
		{
			s = s + contadores[i] + "; ";
		}
		System.out.println("counter results: " + s);
	}

	public static void initializeCounters(Counter[] contadores) {
		for (int i = 0; i < contadores.length; i++)
		{
			contadores[i] = new Counter(i);
		}
	}

}
