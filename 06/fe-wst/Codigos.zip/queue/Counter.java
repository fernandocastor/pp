package trabalho06.queue;


public class Counter {

	private double counter = 0;
	private int id;
	private MCSLock lock;
	
	public Counter(int id) {
		this.id = id;
		this.lock = new MCSLock();
	}
	
	public void incrementa() {
		this.lock.lock();
		try
		{
			this.counter++;
		}
		finally
		{
			this.lock.unlock();
		}
	}

	@Override
	public String toString() {
		return "C" + id + "->" + counter;
	}
}
