package trabalho06.TasBackoff;


public class BackoffThread extends Thread {

	private Counter[] contadores = null;
	private double count = 0;
	private int id;

	public BackoffThread(Counter[] c, int id) {
		this.contadores = c;
		this.id = id;
	}

//	@Override
//	public void run() {
//
//		while (true)
//		{
//			int random = (int) (Math.random() * 10);
//			this.contadores[random].incrementa();
//			this.count++;
//		}
//	}
	
	@Override
	public void run() {

		while (this.count < 1000)
		{
			int random = (int) (Math.random() * 2);
			this.contadores[(random - 1) & 1].incrementa();
			this.count++;
		}
	}
	
	@Override
	public String toString() {
		return "T" + id + "->" + count;
	}
}
