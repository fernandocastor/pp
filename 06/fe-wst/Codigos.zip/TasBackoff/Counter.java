package trabalho06.TasBackoff;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class Counter {

	private double counter = 0;
	private int id;
//	private BackoffLock lock;
	private Lock lock;
	
	public Counter(int id) {
		this.id = id;
//		this.lock = new BackoffLock();
		this.lock = new ReentrantLock();
	}
	
	public void incrementa() {
		this.lock.lock();
		try
		{
			this.counter++;
		}
		finally
		{
			this.lock.unlock();
		}
	}

	@Override
	public String toString() {
		return "C" + id + "->" + counter;
	}
}
