package trabalho06.TasBackoff;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class BackoffLock implements Lock {

	private AtomicBoolean state = new AtomicBoolean(false);
	private static final int MIN_DELAY = 10;
	private static final int MAX_DELAY = 100;
	
	@Override
	public void lock() {

	//	Backoff backoff = new Backoff(MIN_DELAY, MAX_DELAY);

		while (true)
		{
			while (this.state.get()) {	}
			
			if (!this.state.getAndSet(true))
			{
				return;
			}
//			else
//			{
//				try
//				{
//					backoff.exponentialBackoff();
//					//backoff.additiveBackoff();
//				}
//				catch (InterruptedException e)
//				{
//					e.printStackTrace();
//				}
//			}
		}
	}

	@Override
	public void unlock() {
		this.state.set(false);
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {

	}

	@Override
	public boolean tryLock() {
		return false;
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		return false;
	}

	@Override
	public Condition newCondition() {
		return null;
	}

}
