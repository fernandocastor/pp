package trabalho06.ex86;

public class Counter {

	private volatile double counter = 0;
	private TTASLock lock;
	private volatile int[] array = new int[Main.NUMBER_THREADS];

	public Counter() {
		this.lock = new TTASLock();
	}

	public void incrementa() {
		this.counter++;
		System.out.println("incrementou");
	}
	
	public TTASLock getLock() {
		return lock;
	}
	
	public double getCounter() {
		return counter;
	}

	public int[] getArray() {
		return array;
	}

	@Override
	public String toString() {
		return "" + counter;
	}
}
