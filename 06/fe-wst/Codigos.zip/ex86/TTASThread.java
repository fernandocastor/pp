package trabalho06.ex86;

public class TTASThread extends Thread {

	private Counter counter = null;
	private int id;

	public TTASThread(Counter c, int id) {
		this.counter = c;
		this.id = id;
	}

	@Override
	public void run() {

		this.foo();

		this.firstBarrier();

		//this.secondBarrier();

		this.bar();
	}

	public void secondBarrier() {

		if (this.id == 0)
		{
			this.counter.getArray()[this.id] = 1;
		}
		
		if (this.id > 0)
		{
			while (this.counter.getArray()[this.id - 1] == 0)
			{
				// System.out.println("wait pred...");
			}
		}

		//System.out.println("T" + this.id + "->" + this.counter.getArray()[this.id]);
		this.counter.getArray()[this.id] = 1;
		//System.out.println("T" + this.id + "->" + this.counter.getArray()[this.id]);

		if (this.id + 1 < Main.NUMBER_THREADS)
		{
			while (this.counter.getArray()[this.id + 1] != 2)
			{
				// System.out.println("wait suc...");
			}
		}

		if (this.id == Main.NUMBER_THREADS - 1)
		{
			this.counter.getArray()[this.id] = 2;
		}

		this.counter.getArray()[this.id] = 2;
		//System.out.println("T" + this.id + "->" + this.counter.getArray()[this.id]);
	}

	public void firstBarrier() {

		this.counter.getLock().lock();

		this.counter.incrementa();

		this.counter.getLock().unlock();

		while (this.counter.getCounter() < Main.NUMBER_THREADS)
		{
			// System.out.println("waiting...");
		}
	}

	public void foo() {
		System.out.println("foo");
	}

	public void bar() {
		System.out.println("bar");
	}

	@Override
	public String toString() {
		return "T" + id + "->" + counter;
	}
}
