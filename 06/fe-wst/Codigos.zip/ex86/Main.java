package trabalho06.ex86;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static final int NUMBER_THREADS = 100;
	
	public static void main(String[] args) {
		
		try
		{
			Counter counter = new Counter();
			
			List<TTASThread> threads = new ArrayList<TTASThread>();
			
			for (int i = 0; i < NUMBER_THREADS; i++)
			{
				threads.add(new TTASThread(counter, i));
			}
			
			
			for (TTASThread test : threads)
			{
				test.start();
			}
			
			
			for (TTASThread test : threads)
			{
				test.join();
			}
			
			printThreadResults(threads);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}

	}

	public static void printThreadResults(List<TTASThread> threads) {
		System.out.println("thread results: " + threads);
	}
}
