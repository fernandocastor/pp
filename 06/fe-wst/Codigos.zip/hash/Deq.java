package trabalho06.deque.hash;

import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Deq<E> {

	private Lock lock = new ReentrantLock();
	private LinkedList<E> list = new LinkedList<E>();

	public E deq_pop_l() {
		E elem = null;
		this.lock.lock();
		elem = this.list.pollFirst();
		this.lock.unlock();
		return elem;
	}

	public E deq_pop_r() {
		E elem = null;
		this.lock.lock();
		elem = this.list.pollLast();
		this.lock.unlock();
		return elem;
	}

	public void deq_push_l(E e) {
		this.lock.lock();
		this.list.addFirst(e);
		this.lock.unlock();
	}
	
	public void deq_push_r(E e) {
		this.lock.lock();
		this.list.addLast(e);
		this.lock.unlock();
	}

	@Override
	public String toString() {
		return this.list + "";
	}
	
	
}
