package trabalho06.deque.hash;

import java.util.ArrayList;
import java.util.List;

public class PDeqDoubleLockThread extends Thread {

	private PDeqDoubleLock pDeq;
	private static int NUMBER_THREADS = 100;

	public PDeqDoubleLockThread(PDeqDoubleLock p) {
		this.pDeq = p;
	}

	@Override
	public void run() {
		for (int i = 0; i < 100; i++)
		{
			this.pDeq.pdeq_push_r("R1");
			this.pDeq.pdeq_push_r("R2");
			this.pDeq.pdeq_push_r("R3");
			this.pDeq.pdeq_push_r("R4");
			this.pDeq.pdeq_push_l("L0");
			this.pDeq.pdeq_push_l("L1");
			this.pDeq.pdeq_push_l("L2");
			this.pDeq.pdeq_push_r("R5");
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_push_r("R11");
			this.pDeq.pdeq_push_r("R22");
			this.pDeq.pdeq_push_r("R33");
			this.pDeq.pdeq_push_r("R44");
			this.pDeq.pdeq_push_l("L00");
			this.pDeq.pdeq_push_l("L11");
			this.pDeq.pdeq_push_l("L22");
			this.pDeq.pdeq_push_r("R55");
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
		}
	}

	public static void main(String[] args) {

		try
		{
			PDeqDoubleLock pDeq = new PDeqDoubleLock();
			List<PDeqDoubleLockThread> threads = new ArrayList<PDeqDoubleLockThread>();

			for (int i = 0; i < NUMBER_THREADS; i++)
			{
				threads.add(new PDeqDoubleLockThread(pDeq));
			}

			for (PDeqDoubleLockThread deque : threads)
			{
				deque.start();
			}

			for (PDeqDoubleLockThread test : threads)
			{
				test.join();
			}

//			System.out.println("final " + pDeq);
			
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}
}
