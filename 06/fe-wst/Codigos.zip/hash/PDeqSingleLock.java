package trabalho06.deque.hash;

import java.util.Arrays;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class PDeqSingleLock {

	@SuppressWarnings("rawtypes")
	private Deq[] deqList;
	static int PDEQ_N_BKTS = 64;
	private Lock lock = new ReentrantLock();
	private int lidx = 0;
	private int ridx = 1;

	public PDeqSingleLock() {
		this.deqList = new Deq[PDEQ_N_BKTS];
		for (int i = 0; i < PDEQ_N_BKTS; i++)
		{
			deqList[i] = new Deq<>();
		}
	}

	public int moveLeft(int idx) {
		return (idx - 1) & (PDEQ_N_BKTS - 1);
	}

	public int moveRight(int idx) {
		return (idx + 1) & (PDEQ_N_BKTS - 1);
	}

	public void pdeq_pop_l() {
		this.lock.lock();
		int i = this.moveRight(lidx);
		Object elem = this.deqList[i].deq_pop_l();
		if (elem != null)
		{
			lidx = i;
		}
		this.lock.unlock();
	}

	public void pdeq_pop_r() {
		this.lock.lock();
		int i = this.moveLeft(ridx);
		Object elem = this.deqList[i].deq_pop_r();
		if (elem != null)
		{
			ridx = i;
		}
		this.lock.unlock();
	}
	
	@SuppressWarnings("unchecked")
	public void pdeq_push_l(Object e) {
		this.lock.lock();
		int i = lidx;
		this.deqList[i].deq_push_l(e);
		lidx = this.moveLeft(lidx);
		this.lock.unlock();
	}
	
	@SuppressWarnings("unchecked")
	public void pdeq_push_r(Object e) {
		this.lock.lock();
		int i = ridx;
		this.deqList[i].deq_push_r(e);
		ridx = this.moveRight(ridx);
		this.lock.unlock();
	}

	@Override
	public String toString() {
		return Arrays.toString(deqList);
	}
	
	
}
