package trabalho06.deque.hash;

import java.util.ArrayList;
import java.util.List;

public class PDeqSingleLockThread extends Thread {

	private PDeqSingleLock pDeq;
	private static int NUMBER_THREADS = 10;

	public PDeqSingleLockThread(PDeqSingleLock p) {
		this.pDeq = p;
	}

	@Override
	public void run() {
		for (int i = 0; i < 100; i++)
		{
			this.pDeq.pdeq_push_r("R1");
			this.pDeq.pdeq_push_r("R2");
			this.pDeq.pdeq_push_r("R3");
			this.pDeq.pdeq_push_r("R4");
			this.pDeq.pdeq_push_l("L0");
			this.pDeq.pdeq_push_l("L1");
			this.pDeq.pdeq_push_l("L2");
			this.pDeq.pdeq_push_r("R5");
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_push_r("R11");
			this.pDeq.pdeq_push_r("R22");
			this.pDeq.pdeq_push_r("R33");
			this.pDeq.pdeq_push_r("R44");
			this.pDeq.pdeq_push_l("L00");
			this.pDeq.pdeq_push_l("L11");
			this.pDeq.pdeq_push_l("L22");
			this.pDeq.pdeq_push_r("R55");
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
			this.pDeq.pdeq_pop_l();
			this.pDeq.pdeq_pop_r();
		}
	}

	public static void main(String[] args) {

		try
		{
			PDeqSingleLock pDeq = new PDeqSingleLock();
			List<PDeqSingleLockThread> threads = new ArrayList<PDeqSingleLockThread>();

			for (int i = 0; i < NUMBER_THREADS; i++)
			{
				threads.add(new PDeqSingleLockThread(pDeq));
			}

			for (PDeqSingleLockThread deque : threads)
			{
				deque.start();
			}

			for (PDeqSingleLockThread test : threads)
			{
				test.join();
			}

//			System.out.println("final " + pDeq);
			
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}

	}

}
