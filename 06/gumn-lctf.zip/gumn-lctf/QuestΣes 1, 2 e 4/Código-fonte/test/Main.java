package test;

public class Main {
	private static final int NUMBER_OF_COUNTERS = 10;
	private static final int NUMBER_OF_THREADS = 10;
	private static final boolean TWO_MINUTES = false;
	
	public static void main(String[] args) throws InterruptedException {
		long t1 = System.currentTimeMillis();
		
		Counter[] counters = new Counter[NUMBER_OF_COUNTERS];
		for(int i=0; i<NUMBER_OF_COUNTERS; i++) {
			counters[i] = new Counter();
		}
		
		ThreadCounter[] threads = new ThreadCounter[NUMBER_OF_THREADS];
		for(int i=0; i<NUMBER_OF_THREADS; i++) {
			threads[i] = new ThreadCounter(counters, TWO_MINUTES);
			threads[i].start();
		}
		
		for(int i=0; i<NUMBER_OF_THREADS; i++) {
			if(threads[i].isAlive())
				threads[i].join();
		}
		
		long t2 = System.currentTimeMillis();
		
		int totalCounters = 0;
		for(int i=0; i<counters.length; i++) {
			System.out.println("Counter " + i + ": " + counters[i].getCount());
			totalCounters += counters[i].getCount();
		}
		System.out.println("Total Counters: " + totalCounters + "\n");
		
		int totalThreads = 0;
		for(int i=0; i<NUMBER_OF_THREADS; i++) {
			System.out.println("Thread " + i + ": " + threads[i].getIncrements());
			totalThreads += threads[i].getIncrements();
		}
		System.out.println("Total Threads: " + totalThreads + "\n");
		
		System.out.println("Tempo de execu��o: " + (t2-t1) + "ms");
	}
}
