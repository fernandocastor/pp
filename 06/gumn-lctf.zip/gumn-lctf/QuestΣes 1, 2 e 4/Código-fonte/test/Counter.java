package test;

import java.util.concurrent.locks.Lock;
import backoff.BackoffType;
import lock.BackoffLock;

public class Counter {
	private Lock lock = new BackoffLock(BackoffType.EXPONENTIAL);
	private int count = 0;
	
	public void incrementar() {
		this.lock.lock();
		
		try {
			this.count++;
		} finally {
			this.lock.unlock();
		}
	}
	
	public int getCount() {
		return this.count;
	}
}
