package test;

import java.util.concurrent.locks.Lock;
import lock.MCSQueueLock;

public class Counter {
	private Lock lock = new MCSQueueLock();
	private int count = 0;
	
	public void incrementar() {
		this.lock.lock();
		
		try {
			this.count++;
		} finally {
			this.lock.unlock();
		}
	}
	
	public int getCount() {
		return this.count;
	}
}
