package test;

import lock.DeadlockAvoidLock;

public class CounterDeadlock {
	private DeadlockAvoidLock a, b;
	private int count = 0;
	
	public CounterDeadlock(DeadlockAvoidLock a, DeadlockAvoidLock b) {
		this.a = a;
		this.b = b;
	}
	
	public void incrementar() {
		this.a.lock();
		this.b.lock();
		
		try {
			this.count++;
		} finally {
			this.b.unlock();
			this.a.unlock();
		}
	}
	
	public int getCount() {
		return this.count;
	}
}
