package test;

import java.util.Random;

public class ThreadCounter extends Thread {
	private Counter[] counters;
	private Random random;
	private final int bounds;
	private final boolean twoMinutes;
	private int increments = 0;
	
	public ThreadCounter(Counter[] counters, boolean twoMinutes) {
		this.counters = counters;
		this.random = new Random();
		this.bounds = counters.length;
		this.twoMinutes = twoMinutes;
	}
	
	@Override
	public void run() {
		if(this.twoMinutes) {
			this.runTwoMinutes();
		} else {
			this.run1000();
		}
	}
	
	private void run1000() {
		for(int i=0; i<1000; i++) {
			int index = this.random.nextInt(bounds);
			counters[index].incrementar();
			this.increments++;
		}
	}
	
	private void runTwoMinutes() {
		long t1 = System.currentTimeMillis();
		
		while(true) {
			int index = this.random.nextInt(bounds);
			counters[index].incrementar();
			this.increments++;
			
			if(System.currentTimeMillis() - t1 >= 120000)
				return;
		}
	}
	
	public int getIncrements() {
		return this.increments;
	}
}
