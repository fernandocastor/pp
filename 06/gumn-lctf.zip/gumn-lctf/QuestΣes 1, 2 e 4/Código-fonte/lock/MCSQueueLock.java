package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class MCSQueueLock implements Lock {
	private AtomicReference<QNode> tail = new AtomicReference<QNode>(null);
	
	private ThreadLocal<QNode> myself = new ThreadLocal<QNode>() {
		protected QNode initialValue() {
			return new QNode();
		}
	};
	
	@Override
	public void lock() {
		QNode myself = this.myself.get();
		QNode predecessor = this.tail.getAndSet(myself);
		
		if(predecessor!=null) {
			myself.wait = true;
			predecessor.sucessor = myself;
			
			while(myself.wait) {}
		}
	}

	@Override
	public void unlock() {
		QNode myself = this.myself.get();
		
		if(myself.sucessor==null) {
			if(this.tail.compareAndSet(myself, null))
				return;
			
			while(myself.sucessor==null) {}
		}
		
		myself.sucessor.wait = false;
		myself.sucessor = null;
	}
	
	class QNode {
		volatile boolean wait = false;
		volatile QNode sucessor = null;
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {}

	@Override
	public boolean tryLock() {
		return false;
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		return false;
	}

	@Override
	public Condition newCondition() {
		return null;
	}
}
