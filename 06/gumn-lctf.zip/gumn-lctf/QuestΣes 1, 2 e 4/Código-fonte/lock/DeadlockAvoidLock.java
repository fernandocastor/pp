package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import exception.DeadlockException;

public class DeadlockAvoidLock implements Lock {
	private AtomicReference<QNode> tail = new AtomicReference<QNode>(null);
	private AtomicReference<QNode> owner = new AtomicReference<QNode>(null);
	
	private ThreadLocal<QNode> myself = new ThreadLocal<QNode>() {
		protected QNode initialValue() {
			return new QNode(Thread.currentThread().getId());
		}
	};
	
	@Override
	public void lock() {
		QNode myself = this.myself.get();
		QNode predecessor = this.tail.getAndSet(myself);
		
		if(predecessor!=null) {
			myself.wait = true;
			predecessor.sucessor = myself;
			
			while(myself.wait) {}
		}
		
		this.owner.set(myself);
	}
	
	public void lock(DeadlockAvoidLock lock) throws DeadlockException {
		if(lock.getOwner().threadID==this.myself.get().threadID && lock.getOwner().isInChain(this.getOwner())) {
			throw new DeadlockException();
		}
		
		this.lock();
	}

	@Override
	public void unlock() {
		QNode myself = this.myself.get();
		this.owner.compareAndSet(myself, null);
		
		if(myself.sucessor==null) {
			if(this.tail.compareAndSet(myself, null))
				return;
			
			while(myself.sucessor==null) {}
		}
		
		myself.sucessor.wait = false;
		myself.sucessor = null;
	}
	
	public QNode getOwner() {
		return this.owner.get();
	}
	
	class QNode {
		volatile boolean wait = false;
		volatile QNode sucessor = null;
		long threadID = 0;
		
		public QNode(long threadID) {
			this.threadID = threadID;
		}
		
		public boolean isInChain(QNode node) {
			if(this.sucessor==null) {
				return false;
			} else if(this.sucessor.threadID==node.threadID) {
				return true;
			} else {
				return sucessor.isInChain(node);
			}
		}
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {}

	@Override
	public boolean tryLock() {
		return false;
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		return false;
	}

	@Override
	public Condition newCondition() {
		return null;
	}
}
