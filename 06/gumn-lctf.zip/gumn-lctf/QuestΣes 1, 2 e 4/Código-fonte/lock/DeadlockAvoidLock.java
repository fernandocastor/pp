package lock;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import exception.DeadlockException;

public class DeadlockAvoidLock implements Lock {
	private static volatile ConcurrentHashMap<Thread, DeadlockAvoidLock> waiters = new ConcurrentHashMap<Thread, DeadlockAvoidLock>();
	private static volatile ConcurrentHashMap<DeadlockAvoidLock, Thread> owners = new ConcurrentHashMap<DeadlockAvoidLock, Thread>();
	
	private AtomicReference<QNode> tail = new AtomicReference<QNode>(null);
	private volatile boolean deadlock;
	
	private ThreadLocal<QNode> myself = new ThreadLocal<QNode>() {
		protected QNode initialValue() {
			return new QNode();
		}
	};
	
	public DeadlockAvoidLock() {
		this.deadlock = false;
	}
	
	public void lock() {
		QNode myself = this.myself.get();
		Thread thisThread = Thread.currentThread();
		Thread ownerOfThisLock = owners.get(this);
		
		if(ownerOfThisLock!=null && ownerOfThisLock.equals(thisThread))
			return;
		
		if(ownerOfThisLock!=null) {
			DeadlockAvoidLock otherLock = waiters.get(ownerOfThisLock);
			
			if(otherLock!=null) {
				Thread ownerOfTheOtherLock = owners.get(otherLock);
				
				if(ownerOfTheOtherLock!=null && ownerOfTheOtherLock.equals(thisThread)) {
					this.deadlock = true;
					otherLock.deadlock = true;
					throw new DeadlockException();
				}
			}
		}
		
		QNode predecessor = this.tail.getAndSet(myself);
		if(predecessor!=null) {
			myself.wait = true;
			predecessor.sucessor = myself;
			
			waiters.put(Thread.currentThread(), this);
			while(myself.wait) {
				if(this.deadlock)
					throw new DeadlockException();
			}
			waiters.remove(Thread.currentThread(), this);
		}

		owners.put(this, Thread.currentThread());
	}
	
	@Override
	public void unlock() {
		QNode myself = this.myself.get();
		owners.remove(this, Thread.currentThread());
		
		if(myself.sucessor==null) {
			if(this.tail.compareAndSet(myself, null))
				return;
			
			while(myself.sucessor==null) {}
		}
		
		myself.sucessor.wait = false;
		myself.sucessor = null;
	}
	
	class QNode {
		volatile boolean wait = false;
		volatile QNode sucessor = null;
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {}

	@Override
	public boolean tryLock() {
		return false;
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		return false;
	}

	@Override
	public Condition newCondition() {
		return null;
	}
}
