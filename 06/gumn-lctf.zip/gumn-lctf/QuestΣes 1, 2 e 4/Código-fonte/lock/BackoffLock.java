package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import backoff.Backoff;
import backoff.AdditiveBackoff;
import backoff.BackoffType;
import backoff.ExponentialBackoff;

public class BackoffLock implements Lock {
	private static final int MIN_DELAY = 1;
	private static final int MAX_DELAY = 50;
	
	private AtomicBoolean state = new AtomicBoolean(false);
	private BackoffType backoffType;
	
	public BackoffLock(BackoffType backoffType) {
		this.backoffType = backoffType;
	}

	public void lock() {
		Backoff backoff = null;
		
		if(this.backoffType==BackoffType.ADDITIVE) {
			backoff = new AdditiveBackoff(MIN_DELAY, MAX_DELAY);
		} else {
			backoff = new ExponentialBackoff(MIN_DELAY, MAX_DELAY);
		}
		
		while(true) {
			while(state.get()) {}
			
			if(!state.getAndSet(true)) {
				return;
			} else {
				try {
					backoff.backoff();
				} catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void unlock() {
		state.set(false);
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {}

	@Override
	public boolean tryLock() {
		return false;
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		return false;
	}

	@Override
	public Condition newCondition() {
		return null;
	}
}
