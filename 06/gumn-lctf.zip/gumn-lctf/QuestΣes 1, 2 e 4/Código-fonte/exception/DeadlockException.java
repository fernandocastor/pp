package exception;

public class DeadlockException extends Exception {
	private static final long serialVersionUID = -2744990204068159267L;
}
