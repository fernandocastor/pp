package backoff;

import java.util.Random;

public class AdditiveBackoff implements Backoff {
	private int currentDelay, maxDelay;
	private Random random;
	
	public AdditiveBackoff(int minDelay, int maxDelay) {
		this.currentDelay = minDelay;
		this.maxDelay = maxDelay;
		this.random = new Random();
	}

	@Override
	public void backoff() throws InterruptedException {
		int delay = this.random.nextInt(this.currentDelay);
		this.currentDelay = Math.min(this.maxDelay, (2 + this.currentDelay));
		Thread.sleep(delay);
	}
}
