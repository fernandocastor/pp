package backoff;

public interface Backoff {
	public void backoff() throws InterruptedException;
}
