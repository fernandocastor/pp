package br.ufpe.cin.pp.trab06.testlocks;

import java.util.Random;

public class ThreadCounterMinutesTest extends Thread {

	private static long TWO_MINUTES = 2 * 60 * 1000;

	private volatile Counter[] counters;

	private volatile int callTimes;

	public ThreadCounterMinutesTest(Counter[] counters) {
		this.counters = counters;
	}

	@Override
	public void run() {
		Random rand = new Random();

		int incrementCalls = 0;

		long startTime = System.currentTimeMillis();

		while (System.currentTimeMillis() - startTime < TWO_MINUTES) {
			System.err.println(counters[rand.nextInt(counters.length)]
					.incrementar());
			incrementCalls++;
		}

		this.callTimes = incrementCalls;
	}

	public int getCallTimes() {
		return this.callTimes;
	}

}
