package br.ufpe.cin.pp.trab06.testdeque;

import java.util.Date;

import br.ufpe.cin.pp.deque.HashDoubleQueue;

public class ThreadPushRightTester implements Runnable {

	private HashDoubleQueue<String> hashDoubleQueue;
	
	private Date startDate = new Date();
	
	private int counter = 0;
	
	private int qtyExecutions = 0;
	
	public ThreadPushRightTester(HashDoubleQueue<String> hashDoubleQueue) {
		super();
		this.hashDoubleQueue = hashDoubleQueue;
	}

	@Override
	public void run() {
		
		while ((new Date().getTime() - startDate.getTime()) < 120000){
			qtyExecutions += this.hashDoubleQueue.push_right(String.valueOf("Value " + ++counter));
		}
		
		System.out.println(Thread.currentThread().getName() + "Right " + qtyExecutions);
	}

}
