package br.ufpe.cin.pp.trab06.testlocks;

import java.util.Random;

public class ThreadCounterThousandTest extends Thread {

	private volatile Counter[] counters;

	private volatile long execTime;

	public ThreadCounterThousandTest(Counter[] counters) {
		this.counters = counters;
		this.execTime = 0;
	}

	@Override
	public void run() {
		Random rand = new Random();

		long startTime = System.currentTimeMillis();

		for (int executions = 0; executions < 1000; executions++) {
			System.err.println(counters[rand.nextInt(counters.length)]
					.incrementar());
		}

		long endTime = System.currentTimeMillis();

		this.execTime = endTime - startTime;

		/*
		 * System.out.println(Thread.currentThread().getName() +
		 * " - Exec time: " + endTime + " - " + startTime + " = " + (endTime -
		 * startTime));
		 */
	}

	public long getExecTime() {
		return this.execTime;
	}
}
