package br.ufpe.cin.pp.trab06.testdeque;

import br.ufpe.cin.pp.deque.HashDoubleQueue;

public class Client {

	public static void main(String[] args) {
		
		HashDoubleQueue<String> queue = new HashDoubleQueue<String>(100);

		Thread threadLeft = new Thread(new ThreadPushLeftTester(queue));
		Thread threadRight = new Thread(new ThreadPushRightTester(queue));
		
		threadLeft.start();
		threadRight.start();
		
	}
	
}
