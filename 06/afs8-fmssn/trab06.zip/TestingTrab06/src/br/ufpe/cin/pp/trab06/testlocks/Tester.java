package br.ufpe.cin.pp.trab06.testlocks;

import java.util.concurrent.locks.ReentrantLock;

import br.ufpe.cin.pp.locks.Backoff;
import br.ufpe.cin.pp.locks.BackoffLock;
import br.ufpe.cin.pp.locks.BackoffStrategy;
import br.ufpe.cin.pp.locks.MCSLock;
import br.ufpe.cin.pp.locks.deadlockfree.DeadlockFreeLock;

public class Tester {

	private static int[] SIZES = { 10, 50, 100, 200 };

	public static void main(String[] args) {

		for (int threadCount : SIZES) {
			for (int i = 0; i < 3; i++) {
				testQueued(threadCount);
				testBackoff(threadCount);
				testDeadlockFree(threadCount);
				testReentrant(threadCount);
				
			}
		}

	}

	private static void testReentrant(int threadCount) {
		testReentrantTime(threadCount);
		testReentrantThousand(threadCount);
	}

	private static void testDeadlockFree(int threadCount) {
//		testDeadlockFreeAdditiveTime(threadCount);
//		testDeadlockFreeAdditiveThousand(threadCount);
//		testDeadlockFreeExponentialTime(threadCount);
//		testDeadlockFreeExponentialThousand(threadCount);
		testDeadlockFreeNoBackoffTime(threadCount);
		testDeadlockFreeNoBackoffThousand(threadCount);
		System.out.println("");
	}

	private static void testBackoff(int threadCount) {
		testBackoffAdditiveTime(threadCount);
		testBackoffAdditiveThousand(threadCount);
		testBackoffExponentialTime(threadCount);
		testBackoffExponentialThousand(threadCount);
		testBackoffNoBackoffTime(threadCount);
		testBackoffNoBackoffThousand(threadCount);
	}

	private static void testQueued(int threadCount) {
		testQueuedTime(threadCount);
		testQueuedThousand(threadCount);
	}

	/* Queued */
	private static void testQueuedTime(int threadCount) {
		Counter[] counters = makeNewQueuedCounters();
		String lockName = "MCSLock";
		testTime(threadCount, counters, lockName);
	}

	private static void testQueuedThousand(int threadCount) {
		Counter[] counters = makeNewQueuedCounters();
		String lockName = "MCSLock";
		testThousand(threadCount, counters, lockName);
	}

	/* DeadlockFree */

	private static void testDeadlockFreeAdditiveTime(int threadCount) {
		Counter[] counters = makeNewDeadlockFreeCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.ADDITIVE;
		String lockName = "DeadlockFreeLockAdditive";
		testTime(threadCount, counters, lockName);
	}

	private static void testDeadlockFreeAdditiveThousand(int threadCount) {
		Counter[] counters = makeNewDeadlockFreeCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.ADDITIVE;
		String lockName = "DeadlockFreeLockAdditive";
		testThousand(threadCount, counters, lockName);
	}

	private static void testDeadlockFreeExponentialTime(int threadCount) {
		Counter[] counters = makeNewDeadlockFreeCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.EXPONENTIAL;
		String lockName = "DeadlockFreeLockExponential";
		testTime(threadCount, counters, lockName);
	}

	private static void testDeadlockFreeExponentialThousand(int threadCount) {
		Counter[] counters = makeNewDeadlockFreeCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.EXPONENTIAL;
		String lockName = "DeadlockFreeLockExponential";
		testThousand(threadCount, counters, lockName);
	}

	private static void testDeadlockFreeNoBackoffTime(int threadCount) {
		Counter[] counters = makeNewDeadlockFreeCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.NOBACKOFF;
		String lockName = "DeadlockFreeLockNoBackoff";
		testTime(threadCount, counters, lockName);
	}

	private static void testDeadlockFreeNoBackoffThousand(int threadCount) {
		Counter[] counters = makeNewDeadlockFreeCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.NOBACKOFF;
		String lockName = "DeadlockFreeLockNoBackoff";
		testThousand(threadCount, counters, lockName);
	}

	/* Backoff */

	private static void testBackoffAdditiveTime(int threadCount) {
		Counter[] counters = makeNewBackoffCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.ADDITIVE;
		String lockName = "BackoffLockAdditive";
		testTime(threadCount, counters, lockName);
	}

	private static void testBackoffAdditiveThousand(int threadCount) {
		Counter[] counters = makeNewBackoffCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.ADDITIVE;
		String lockName = "BackoffLockAdditive";
		testThousand(threadCount, counters, lockName);
	}

	private static void testBackoffExponentialTime(int threadCount) {
		Counter[] counters = makeNewBackoffCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.EXPONENTIAL;
		String lockName = "BackoffLockExponential";
		testTime(threadCount, counters, lockName);
	}

	private static void testBackoffExponentialThousand(int threadCount) {
		Counter[] counters = makeNewBackoffCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.EXPONENTIAL;
		String lockName = "BackoffLockExponential";
		testThousand(threadCount, counters, lockName);
	}

	private static void testBackoffNoBackoffTime(int threadCount) {
		Counter[] counters = makeNewBackoffCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.NOBACKOFF;
		String lockName = "BackoffLockNoBackoff";
		testTime(threadCount, counters, lockName);
	}

	private static void testBackoffNoBackoffThousand(int threadCount) {
		Counter[] counters = makeNewBackoffCounters();
		Backoff.BACKOFF_TYPE = BackoffStrategy.NOBACKOFF;
		String lockName = "BackoffLockNoBackoff";
		testThousand(threadCount, counters, lockName);
	}

	/* Reentrant */

	private static void testReentrantTime(int threadCount) {
		Counter[] counters = makeNewReentrantCounters();
		String lockName = "ReentrantLock";
		testTime(threadCount, counters, lockName);
	}

	private static void testReentrantThousand(int threadCount) {
		Counter[] counters = makeNewReentrantCounters();
		String lockName = "ReentrantLock";
		testThousand(threadCount, counters, lockName);
	}

	/* Specific counters */

	private static Counter[] makeNewBackoffCounters() {
		Counter[] contadores = new Counter[10];
		for (int i = 0; i < contadores.length; i++) {
			contadores[i] = new Counter(new BackoffLock());
		}
		return contadores;
	}

	private static Counter[] makeNewQueuedCounters() {
		Counter[] contadores = new Counter[10];
		for (int i = 0; i < contadores.length; i++) {
			contadores[i] = new Counter(new MCSLock());
		}
		return contadores;
	}

	private static Counter[] makeNewDeadlockFreeCounters() {
		Counter[] contadores = new Counter[10];
		for (int i = 0; i < contadores.length; i++) {
			contadores[i] = new Counter(new DeadlockFreeLock());
		}
		return contadores;
	}

	private static Counter[] makeNewReentrantCounters() {
		Counter[] contadores = new Counter[10];
		for (int i = 0; i < contadores.length; i++) {
			contadores[i] = new Counter(new ReentrantLock());
		}
		return contadores;
	}

	/* Generic functions */

	private static void testTime(int threadCount, Counter[] counters,
			String lockName) {
		Thread[] testers = makeNewTesters(threadCount, "time", counters);
		System.out.println("Running for 2 minutes " + lockName + "; "
				+ threadCount + " threads.");
		for (Thread t : testers) {
			t.start();
		}

		try {
			Thread.sleep(2 * 61 * 1000);
		} catch (InterruptedException e) {
			System.err.println("InterruptedException while sleeping.");
			e.printStackTrace();
		}

		for (Thread t : testers) {
			while (t.isAlive()) {
				// skip
				continue;
			}

			System.out.println(t.getName() + " - Times called: "
					+ ((ThreadCounterMinutesTest) t).getCallTimes());
		}
	}

	private static void testThousand(int threadCount, Counter[] counters,
			String lockName) {
		Thread[] testers = makeNewTesters(threadCount, "thousand", counters);
		System.out.println("Running for 1000 inc " + lockName + "; "
				+ threadCount + " threads.");
		for (Thread t : testers) {
			t.start();
		}
		for (Thread t : testers) {
			while (t.isAlive()) {
				// skip
				continue;
			}
			long execTime = ((ThreadCounterThousandTest) t).getExecTime();
			System.out.println(t.getName() + " - Exec time: " + execTime);
		}
	}

	private static Thread[] makeNewTesters(int amount, String type,
			Counter[] counters) {
		Thread testers[] = new Thread[amount];
		for (int i = 0; i < testers.length; i++) {
			if (type.equals("time")) {
				testers[i] = new ThreadCounterMinutesTest(counters);
			} else {
				testers[i] = new ThreadCounterThousandTest(counters);
			}
		}
		return testers;
	}

}
