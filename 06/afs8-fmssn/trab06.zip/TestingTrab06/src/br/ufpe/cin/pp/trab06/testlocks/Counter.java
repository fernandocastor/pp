package br.ufpe.cin.pp.trab06.testlocks;

import java.util.concurrent.locks.Lock;

public class Counter {

	private volatile int counter;

	private final Lock lock;

	public Counter(Lock lock) {
		this.counter = 0;
		this.lock = lock;
	}

	public int incrementar() {
		int old;
		this.lock.lock();

		old = this.counter++;

		this.lock.unlock();

		return old;
	}

	public int getCounter() {
		return this.counter;
	}
}
