package br.ufpe.cin.pp.deque;

public class HashDoubleQueue<E> {

	private HashLeftIndex leftIndex;
	private HashRightIndex rightIndex;
	private DoubleQueueOneLock<E>[] doubleQueues;
	
	
	@SuppressWarnings("unchecked")
	public HashDoubleQueue(int qtyQueues){
		
		doubleQueues = new DoubleQueueOneLock[qtyQueues];
		
		leftIndex= new HashLeftIndex(qtyQueues);
		rightIndex = new HashRightIndex(qtyQueues);
		
		for (int i = 0; i < doubleQueues.length; i++) {
			 doubleQueues[i] = new DoubleQueueOneLock<E>();
		}
	}
	
	public E pop_left() {
		return doubleQueues[leftIndex.getIndex()].pop_left();
	}

	public int push_left(E e) {
		return doubleQueues[leftIndex.getIndex()].push_left(e);
	}

	public E pop_right() {
		return doubleQueues[rightIndex.getIndex()].pop_right();
	}

	public int push_right(E e) {
		return doubleQueues[rightIndex.getIndex()].push_right(e);
	}
	
}

