package br.ufpe.cin.pp.deque;

import java.util.LinkedList;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DoubleQueueOneLock<E> {

	private Lock lock_left  = new ReentrantLock();
	private Lock lock_right  = new ReentrantLock();
	
	private LinkedList<E> list_left = new LinkedList<E>();
	private LinkedList<E> list_right = new LinkedList<E>();

	
	public E pop_left() {
		E element = null; 
		
		lock_left.lock();
			
		if (list_left.isEmpty()){
			
			lock_right.lock();

			if (!list_right.isEmpty()){
				element = list_right.removeLast();
			}
			
			lock_right.unlock();
			lock_left.unlock();
			
		} else {

			element = list_left.pop();
			lock_left.unlock();
		}
			
		return element;
	}

	public int push_left(E e) {
		lock_left.lock();
			list_left.push(e);
		lock_left.unlock();
		return 1;
	}


	public E pop_right() {
		E element = null; 
		
		lock_right.lock();
			
		if (list_right.isEmpty()){
			
			lock_right.unlock();
			lock_left.lock();
			lock_right.lock();
			
			if (list_right.isEmpty()){
				
				if (!list_left.isEmpty()){
					element = list_left.removeLast();
				}
				
			} else {
				element =  list_right.pop();
			}
			
			lock_right.unlock();
			lock_left.unlock();
			
		} else {

			element = list_right.pop();
			lock_right.unlock();
		}
			
		
		return element;
	}

	public int push_right(E e) {
		lock_left.lock();
			list_right.push(e);
		lock_left.unlock();
		return 1;
	}
	
}
