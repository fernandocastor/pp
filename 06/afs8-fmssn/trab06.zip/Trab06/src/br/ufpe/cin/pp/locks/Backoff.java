package br.ufpe.cin.pp.locks;

import java.util.Random;


public class Backoff {

	int minDelay, maxDelay;
	int limit;
	Random random;

	public static BackoffStrategy BACKOFF_TYPE = BackoffStrategy.ADDITIVE;

	public Backoff(int minDelay, int maxDelay) {
		super();
		this.minDelay = minDelay;
		this.maxDelay = maxDelay;
		this.limit = minDelay;
		this.random = new Random();
	}

	public void backoff() throws InterruptedException {
		int delay = random.nextInt(limit);
		boolean doBackoff = true;
		switch (BACKOFF_TYPE) {
		case ADDITIVE: {
			limit = Math.min(maxDelay, minDelay + limit);
			break;
		}
		case EXPONENTIAL: {
			limit = Math.min(maxDelay, 2 * limit);
			break;
		}
		case NOBACKOFF: {
			doBackoff = false;
			break;
		}
		}

		if (doBackoff) {
			Thread.sleep(delay);
		}
	}

}
