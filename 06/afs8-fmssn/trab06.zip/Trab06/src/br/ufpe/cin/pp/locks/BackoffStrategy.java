package br.ufpe.cin.pp.locks;

public enum BackoffStrategy {

	ADDITIVE, EXPONENTIAL, NOBACKOFF

}
