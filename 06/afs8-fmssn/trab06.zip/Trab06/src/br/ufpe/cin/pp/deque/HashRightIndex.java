package br.ufpe.cin.pp.deque;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class HashRightIndex {

	private Lock hashRightLock = new ReentrantLock();
	
	private int index = 1;
	
	private int limit = 4;
	
	public HashRightIndex(int limit) {
		super();
		this.limit = limit;
	}

	public int getIndex(){
		int pos = 0;
		
		hashRightLock.lock();
		
		pos = index;
		
		if (index >= (limit-1)){
			index = 0;	
		} else {
			index++;
		}
		
		hashRightLock.unlock();
		
		return pos;
	}
	
}
