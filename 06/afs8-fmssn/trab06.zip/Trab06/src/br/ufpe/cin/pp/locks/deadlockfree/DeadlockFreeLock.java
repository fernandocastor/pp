package br.ufpe.cin.pp.locks.deadlockfree;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

import br.ufpe.cin.pp.locks.Backoff;

public class DeadlockFreeLock implements Lock, Comparable<DeadlockFreeLock> {

	private AtomicBoolean state = new AtomicBoolean(false);
	private static final int MIN_DELAY = 1000;
	private static final int MAX_DELAY = 10000;

	private static final ConcurrentHashMap<DeadlockFreeLock, Long> LOCK_OWNER;
	private static final ConcurrentHashMap<Long, ConcurrentSkipListSet<DeadlockFreeLock>> THREADS_LOCKS;
	private static final ConcurrentHashMap<DeadlockFreeLock, ConcurrentSkipListSet<Long>> LOCKS_WAITERS;

	static {
		LOCK_OWNER = new ConcurrentHashMap<DeadlockFreeLock, Long>();
		THREADS_LOCKS = new ConcurrentHashMap<Long, ConcurrentSkipListSet<DeadlockFreeLock>>();
		LOCKS_WAITERS = new ConcurrentHashMap<DeadlockFreeLock, ConcurrentSkipListSet<Long>>();
	}

	private static AtomicLong idCount = new AtomicLong();

	private Long id;

	public DeadlockFreeLock() {
		LOCKS_WAITERS.put(this, new ConcurrentSkipListSet<Long>());
		this.id = idCount.getAndIncrement();
	}

	@Override
	public void lock() {
		Backoff backoff = new Backoff(MIN_DELAY, MAX_DELAY);
		while (true) {
			while (state.get()) {
			}

			long myId = Thread.currentThread().getId();
			ConcurrentSkipListSet<DeadlockFreeLock> myLocks = THREADS_LOCKS
					.get(myId);
			if (!state.getAndSet(true)) {
				LOCKS_WAITERS.get(this).remove(myId);
				LOCK_OWNER.put(this, myId);
				if (myLocks != null) {
					myLocks.add(this);
				} else {
					ConcurrentSkipListSet<DeadlockFreeLock> freshMyLocks = new ConcurrentSkipListSet<DeadlockFreeLock>();
					freshMyLocks.add(this);
					THREADS_LOCKS.put(myId, freshMyLocks);
				}
				return;
			} else {
				try {
					// procurar por deadlock
					Long holder = LOCK_OWNER.get(this);
					if (holder != null) {
						boolean isDeadlocked = false;
						if (myLocks != null) {
							for (DeadlockFreeLock lock : myLocks) {
								isDeadlocked |= LOCKS_WAITERS.get(lock)
										.contains(holder);
							}
						} else {
							THREADS_LOCKS
									.put(myId,
											new ConcurrentSkipListSet<DeadlockFreeLock>());
						}
						if (isDeadlocked) {
							throw new RuntimeException(
									"DEADLOCK TRYING TO ACQUIRE BETWEEN THREADS "
											+ myId + " AND " + holder + ".");
						} else {
							LOCKS_WAITERS.get(this).add(myId);
							backoff.backoff();
						}
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
	}

	@Override
	public void unlock() {
		LOCK_OWNER.remove(this);
		THREADS_LOCKS.get(Thread.currentThread().getId()).remove(this);
		state.set(false);
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
	}

	@Override
	public Condition newCondition() {
		return null;
	}

	@Override
	public boolean tryLock() {
		return false;
	}

	@Override
	public boolean tryLock(long arg0, TimeUnit arg1)
			throws InterruptedException {
		return false;
	}

	@Override
	public int compareTo(DeadlockFreeLock o) {
		return this.id.compareTo(o.id);
	}

}
