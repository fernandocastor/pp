package br.ufpe.cin.pp.deque;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class HashLeftIndex {

	private Lock hashLeftLock = new ReentrantLock();
	
	private int index = 0;
	
	private int limit = -4;
	
	public HashLeftIndex(int limit) {
		super();
		this.limit = -limit;
	}

	public int getIndex(){
		int pos = 0;
		
		hashLeftLock.lock();
		
		pos = index * (-1);
		
		if (index <= limit+1){
			index = 0;	
		} else {
			index--;
		}
		
		hashLeftLock.unlock();
		
		return pos;
	}
	
}
