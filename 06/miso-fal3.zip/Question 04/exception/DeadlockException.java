package Question04.exception;

public class DeadlockException extends RuntimeException {
	private static final long serialVersionUID = -2744990204068159267L;
}
