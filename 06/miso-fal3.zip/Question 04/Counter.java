package Question04;

import java.util.concurrent.locks.ReentrantLock;

public class Counter {
	private int id;
	private long i;
	private int threadId;
	
	DeadlockAvoidLock lock = new DeadlockAvoidLock();
	
	public Counter(int id) {
		this.id = id;
		this.i = 0;
	}
	
	public void increment(int id) {
		this.lock.lock();
		try {
			this.i++;
		} finally {
			this.lock.unlock();
		}
	}
	
	public int getId() {
		return this.id;
	}
	
	public DeadlockAvoidLock getLock() {
		return this.lock;
	}
	
	public long getCounter() {
		return this.i;
	}

}
