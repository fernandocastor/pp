package Question02;


public class ThreadIncrement implements Runnable {
	private int id;
	private Counter counter;
	private long quantityExecutions;
	long startTime;
	 	
	public ThreadIncrement(Counter c, int id) {
		this.id = id;
		this.counter = c;
		this.quantityExecutions = 0;
	}
	
	@Override
	public void run() {
		this.startTime = System.currentTimeMillis();
		while ((System.currentTimeMillis()-this.startTime) < 2*60*1000){
//		while (this.quantityExecutions < 1000) {
			this.counter.increment();
			this.quantityExecutions++;
		}
	}

	public long getCounter() {
		return this.counter.getCounter();
	}
	
	public long getExecutions() {
		return this.quantityExecutions;
	}
	
	public int getId() {
		return this.id;
	}
	
	public int getCounterId() {
		return this.counter.getId();
	}
}
