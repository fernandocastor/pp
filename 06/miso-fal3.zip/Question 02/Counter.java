package Question02;

public class Counter {
	private int id;
	private long i;
	TOLock lock = new TOLock();
	
	public Counter(int id) {
		this.id = id;
		this.i = 0;
	}
	
	public void increment() {
		this.lock.lock();
		this.i++;
		this.lock.unlock();
	}
	
	public int getId() {
		return this.id;
	}
	
	public long getCounter() {
		return this.i;
	}

}
