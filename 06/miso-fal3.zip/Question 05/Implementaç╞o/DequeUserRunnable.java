

public class DequeUserRunnable implements Runnable {

	private final IDeque deque;
	private int start;
	private final int end;
	private final int type;
	private final int side;


	public DequeUserRunnable(IDeque deque, int start, int end, int operationType, int side) {
		this.deque = deque;
		this.start = start;
		this.end = end;
		this.type = operationType;
		this.side = side;
	}
	

	@Override
	public void run() {
		try {
			//O c�digo est� horroso porque n�o queria que o if se repetisse dentro do while
			if (type == 0 &&  side == 0) {
				while (start < end){
					deque.pushLeft(start++);
				}
			} else if (type == 1 && side == 0){
				while (start < end){
					deque.popLeft();
					start++;
				}
			} else if (type == 0 && side == 1){
				while (start < end){
					deque.pushRight(start++);
				}
			} else if (type == 1 && side == 1){
				while (start < end){
					deque.popRight();
					start++;
				}
			}
		
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
}
