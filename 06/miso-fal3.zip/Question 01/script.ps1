﻿cd 'C:\Users\Felipe\workspace\Parallel Programming\bin';
$i = 1;
Write-Host "Questão 01:";
$teste = '';
while($i -le 3) {
	Write-Host $i;
	$testetitle = "- 10 Threads (Experimento "+$i+")";
	$teste += $testetile;
	$teste += java Question01.Main ;
	$i++;
}

cd 'C:\Users\Felipe\Documents\Estudo\UFPE\IN0984\06\Questão 01';

$teste >> "Medição - ReentrantLock - 1000 execuções - 10 Threads.txt";

cd 'C:\Users\Felipe\workspace\Parallel Programming\bin';
$i = 1;
Write-Host "Questão 01:";
$teste = '';
while($i -le 3) {
	Write-Host $i;
	$testetitle = "- 50 Threads (Experimento "+$i+")";
	$teste += $testetile;
	$teste += java Question01.Main 50;
	$i++;
}

cd 'C:\Users\Felipe\Documents\Estudo\UFPE\IN0984\06\Questão 01';

$teste >> "Medição - ReentrantLock - 1000 execuções - 50 Threads.txt";

cd 'C:\Users\Felipe\workspace\Parallel Programming\bin';
$i = 1;
Write-Host "Questão 01:";
$teste = '';
while($i -le 3) {
	Write-Host $i;
	$testetitle = "- 100 Threads (Experimento "+$i+")";
	$teste += $testetile;
	$teste += java Question01.Main 100;
	$i++;
}

cd 'C:\Users\Felipe\Documents\Estudo\UFPE\IN0984\06\Questão 01';

$teste >> "Medição - ReentrantLock - 1000 execuções - 100 Threads.txt";

cd 'C:\Users\Felipe\workspace\Parallel Programming\bin';
$i = 1;
Write-Host "Questão 01:";
$teste = '';
while($i -le 3) {
	Write-Host $i;
	$testetitle = "- 100 Threads (Experimento "+$i+")";
	$teste += $testetile;
	$teste += java Question01.Main 200;
	$i++;
}

cd 'C:\Users\Felipe\Documents\Estudo\UFPE\IN0984\06\Questão 01';

$teste >> "Medição - ReentrantLock - 1000 execuções - 200 Threads.txt";
