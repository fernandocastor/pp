﻿cd 'C:\Users\Felipe\workspace\Parallel Programming\bin';
$i = 1;
Write-Host "Questão 01:";
while($i -le 3) {
	Write-Host $i;
	$teste10title = "- 10 Threads (Experimento "+$i+")";
	$teste10 += $teste10tile;
	$teste10 += java Question01.Main 10;
	$i++;
}

cd 'C:\Users\Felipe\Documents\Estudo\UFPE\IN0984\06\Questão 01';

$teste10 >> "Medição - TestAndSet - 2 minutos - 10 Threads.txt";

cd 'C:\Users\Felipe\workspace\Parallel Programming\bin';
$i = 1;
Write-Host "Questão 01:";
while($i -le 3) {
	Write-Host $i;
	$teste50title = "- 50 Threads (Experimento "+$i+")";
	$teste50 += $teste10tile;
	$teste50 += java Question01.Main 50;
	$i++;
}

cd 'C:\Users\Felipe\Documents\Estudo\UFPE\IN0984\06\Questão 01';

$teste50 >> "Medição - TestAndSet - 2 minutos - 50 Threads.txt";

cd 'C:\Users\Felipe\workspace\Parallel Programming\bin';
$i = 1;
Write-Host "Questão 01:";
while($i -le 3) {
	Write-Host $i;
	$teste100title = "- 100 Threads (Experimento "+$i+")";
	$teste100 += $teste10tile;
	$teste100 += java Question01.Main 100;
	$i++;
}

cd 'C:\Users\Felipe\Documents\Estudo\UFPE\IN0984\06\Questão 01';

$teste100 >> "Medição - TestAndSet - 2 minutos - 100 Threads.txt";

cd 'C:\Users\Felipe\workspace\Parallel Programming\bin';
$i = 1;
Write-Host "Questão 01:";
while($i -le 3) {
	Write-Host $i;
	$teste200title = "- 200 Threads (Experimento "+$i+")";
	$teste200 += $teste10tile;
	$teste200 += java Question01.Main 200;
	$i++;
}

cd 'C:\Users\Felipe\Documents\Estudo\UFPE\IN0984\06\Questão 01';

$teste200 >> "Medição - TestAndSet - 2 minutos - 200 Threads.txt";
