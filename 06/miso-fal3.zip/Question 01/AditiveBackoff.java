package Question01;

import java.util.Random;

public class AditiveBackoff {
	final int minDelay, maxDelay;
	int limit;
	final Random random;
	public AditiveBackoff(int min, int max) {
		minDelay = min;
		maxDelay = min;
		limit = minDelay;
		random = new Random();
	}
	public void backoff() throws InterruptedException {
		int delay = random.nextInt(limit);
		limit = Math.min(maxDelay, 1 + limit);
		Thread.sleep(delay);
	}
}