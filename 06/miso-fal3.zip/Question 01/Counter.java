package Question01;

import java.util.concurrent.locks.ReentrantLock;

public class Counter {
	private int id;
	private long i;
//	TestAndSet lock = new TestAndSet();
//	TestAndSetExponentialBackoffLock lock = new TestAndSetExponentialBackoffLock();
//	TestAndSetAditiveBackoffLock lock = new TestAndSetAditiveBackoffLock();
	ReentrantLock lock = new ReentrantLock();
	
	public Counter(int id) {
		this.id = id;
		this.i = 0;
	}
	
	public void increment() {
		this.lock.lock();
		this.i++;
		this.lock.unlock();
	}
	
	public int getId() {
		return this.id;
	}
	
	public long getCounter() {
		return this.i;
	}

}
