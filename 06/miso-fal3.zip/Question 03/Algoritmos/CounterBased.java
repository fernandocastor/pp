import java.util.concurrent.atomic.AtomicBoolean;


public class CounterBased implements Runnable{

	
	private volatile TTASLock lock;
	private volatile static int counter;
	private final int qdadeThreads;
	private final int id;


	public CounterBased(int id, TTASLock lock, int qdadeThreads) {
		this.id = id;
		this.lock = lock;
		this.qdadeThreads = qdadeThreads;
		counter = 0; 
	}
	
	public void foo(){
//	  System.err.println("THREAD ID #" + id + " foo");
	}

	public void bar(){
//		System.err.println("THREAD ID #" + id + " bar");
	}

	public void run(){
	  foo();
	  lock.lock();
	  counter++;
//	  System.err.println("THREAD ID #" + id + " inc counter");
	  lock.unlock();
	  while (counter < qdadeThreads);
	  bar();
	}
	
	
	public static void main(String[] args) throws InterruptedException {
	
		long startTime = System.currentTimeMillis();
		TTASLock lock = new TTASLock();
		int qdadeThreads = 1000;
		Thread[] threads = new Thread[qdadeThreads];
		for (int i = 0; i < qdadeThreads; i++) {
			threads[i] = new Thread(new CounterBased(i, lock, qdadeThreads));
		}
		
		for (int i = 0; i < qdadeThreads; i++) {
			threads[i].start();
		}
		
		for (int i = 0; i < qdadeThreads; i++) {
			threads[i].join();
		}

		long endTime = System.currentTimeMillis();
		System.err.println(endTime - startTime);
	}
}

class TTASLock {

	AtomicBoolean state;
	
	public TTASLock() {
		state = new AtomicBoolean(false);
	}
	
	public void lock() {
		while (true){
			while(state.get());
			if(!state.getAndSet(true)){
				return;
			}
		}
	}
	
	public void unlock() {
		state.set(false);
	}
}
