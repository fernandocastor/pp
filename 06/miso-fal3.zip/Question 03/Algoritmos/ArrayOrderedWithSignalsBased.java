import java.util.concurrent.atomic.AtomicInteger;


public class ArrayOrderedWithSignalsBased implements Runnable {

	private final int id;
	private volatile boolean[] flags;
	private final Object ctrl;
	private final StringBuffer buffer;
	private final AtomicInteger indexGenerator;

	public ArrayOrderedWithSignalsBased(int id, boolean[] flags, Object ctrl, AtomicInteger indexGenerator, StringBuffer buffer) {
		this.id = id;
		this.flags = flags;
		this.ctrl = ctrl;
		this.indexGenerator = indexGenerator;
		this.buffer = buffer;
	}

	public void foo() {
		//System.err.println("THREAD ID #" + id + " foo");
		//buffer.append("THREAD ID #" + id + " foo\n");
	}

	public void bar() {
		//System.err.println("THREAD ID #" + id + " bar");
		//buffer.append("THREAD ID #" + id + " bar\n");
	}

	public void run() {
		int barrierChecker = flags.length-1;
		
		try{
			foo();
			int index = indexGenerator.getAndIncrement();
			int previusID = index-1;
			if (index != 0) {
				while (!flags[previusID]);
			} 

			flags[index] = true;
			
			//Waits the last thread
			if (index == barrierChecker){
				synchronized (ctrl) {
					ctrl.notifyAll();
				}
			}
			while (!flags[barrierChecker]) {
				synchronized (ctrl) {
					ctrl.wait();
				}
			}
			bar();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws InterruptedException {

		long startTime = System.currentTimeMillis();
		
		int qdadeThreads = 10;
		AtomicInteger indexGenerator = new AtomicInteger(0);
		Object crtl = new Object();
		boolean flags[] = new boolean[qdadeThreads];
		Thread[] threads = new Thread[qdadeThreads];
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < qdadeThreads; i++) {
			flags[i] = false;
			threads[i] = new Thread(new ArrayOrderedWithSignalsBased(i, flags, crtl, indexGenerator, buffer));
		}

		for (int i = 0; i < qdadeThreads; i++) {
			threads[i].start();
		}
		
		for (int i = 0; i < qdadeThreads; i++) {
			threads[i].join();
		}
		
		long endTime = System.currentTimeMillis();
		System.err.println("ss" + buffer.toString());
		System.err.println(endTime - startTime);
		
	}
}
