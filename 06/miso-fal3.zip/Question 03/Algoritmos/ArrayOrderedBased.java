import java.util.concurrent.atomic.AtomicInteger;


public class ArrayOrderedBased implements Runnable {

	private final int id;
	private volatile boolean[] flags;
	private AtomicInteger indexGenerator;

	public ArrayOrderedBased(int id, boolean[] flags, AtomicInteger index) {
		this.id = id;
		this.flags = flags;
		this.indexGenerator = index;
	}

	public void foo() {
		//System.err.println("THREAD ID #" + id + " foo");
	}

	public void bar() {
		//System.err.println("THREAD ID #" + id + " bar");
	}

	public void run() {
		int barrierChecker = flags.length-1;
		foo();
		int index = indexGenerator.getAndIncrement();
		int previusID = index-1;
		if (index != 0) {
			while (!flags[previusID]);
		} 
		//System.err.println("THREAD ID #" + id + " go");
		flags[index] = true;
		while (!flags[barrierChecker]);
		bar();
	}

	public static void main(String[] args) throws InterruptedException {

		long startTime = System.currentTimeMillis();
		
		int qdadeThreads = 10;
		AtomicInteger index = new AtomicInteger(0);
		boolean flags[] = new boolean[qdadeThreads];
		Thread[] threads = new Thread[qdadeThreads];
		for (int i = 0; i < qdadeThreads; i++) {
			flags[i] = false;
			threads[i] = new Thread(new ArrayOrderedBased(i, flags, index));
		}

		for (int i = 0; i < qdadeThreads; i++) {
			threads[i].start();
		}
		
		for (int i = 0; i < qdadeThreads; i++) {
			threads[i].join();
		}
		
		long endTime = System.currentTimeMillis();
		System.err.println(endTime - startTime);
	}
}
