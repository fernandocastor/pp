import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;



public class DeadLockDetection {
	Map<String,String> deadLockMap	= new HashMap<String,String>();	

	void test() {
		//			final ReentrantLock lock1 = new ReentrantLock();
		//			final ReentrantLock lock2 = new ReentrantLock();

		final TTASLockDeadLock lock1 = new TTASLockDeadLock("lock1",deadLockMap);
		final TTASLockDeadLock lock2 = new TTASLockDeadLock("lock2",deadLockMap);


		Thread thread1 = new Thread(new Runnable() {
			@Override public void run() {
				try {
					lock1.lock("Thread1");
					System.out.println("Thread1 acquired lock1");
					try {
						TimeUnit.MILLISECONDS.sleep(50);
					} catch (InterruptedException ignore) {}
					lock2.lock("Thread1");
					System.out.println("Thread1 acquired lock2");
				}
				finally {
					lock2.unlock();
					lock1.unlock();
				}
			}
		});
		thread1.start();

		Thread thread2 = new Thread(new Runnable() {
			@Override public void run() {
				try {
					lock2.lock("Thread2");
					System.out.println("Thread2 acquired lock2");
					try {
						TimeUnit.MILLISECONDS.sleep(50);
					} catch (InterruptedException ignore) {}
					lock1.lock("Thread2");
					System.out.println("Thread2 acquired lock1");
				}
				finally {
					lock1.unlock();
					lock2.unlock();
				}
			}
		});
		thread2.start();

		// Wait a little for threads to deadlock.
		try {
			TimeUnit.MILLISECONDS.sleep(100);
		} catch (InterruptedException ignore) {}
	}

	public static void main(String[] args) {
		(new DeadLockDetection()).test();
	}
}




class TTASLockDeadLock implements Lock {

	private AtomicBoolean state 			= new AtomicBoolean(false);
	private long backoff 					= 1;
	private static final long BACKOFF_LIMIT = Short.MAX_VALUE;

	//for deadlock detection purposes
	String lockId								= "";
	Lock lockDeadLockDetection					= new ReentrantLock();
	Map<String,String> deadLockMap				= new HashMap<String,String>();	


	public TTASLockDeadLock(String lockId, Map<String,String> deadLockMap){
		this.lockId = lockId;
		this.deadLockMap = deadLockMap;
	}

	public void lock() {
		while(true) {
			while (state.get()) {}
			if (!state.getAndSet(true)) {
				return;
			} 
			else {
				long delay = backoff;
				backoff = Math.min(BACKOFF_LIMIT, backoff + 1);
				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
	}

	public void lock(String threadId) {
		try {
			while(true) {
				this.lockIntentition(threadId);
				checkDeadlock(threadId);
				while (state.get()) {}
				if (!state.getAndSet(true)) {
					aquireLock(threadId);
					return;
				} 
				else {
					long delay = backoff;
					backoff = Math.min(BACKOFF_LIMIT, backoff + 1);
					try {
						Thread.sleep(delay);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (IllegalAccessException e) {
			System.out.println(e.getMessage());
		}
	}

	public void unlock() {
		state.set(false);
		this.removeLock();

	}

	void checkDeadlock(String threadId) throws IllegalAccessException{
		this.lockDeadLockDetection.lock();
		try{
			/* 	deadlock:
			 * 	l2 l1 t1 t2
			 *	t1 t2 l1 l2
			 */
			String lockOwnerThreadId = this.deadLockMap.get(this.lockId);
			String lockWantedByThreadId = this.deadLockMap.get(lockOwnerThreadId);
			String otherThreadId = this.deadLockMap.get(lockWantedByThreadId);
			if(threadId.equals(otherThreadId)){
				throw new IllegalAccessException("Deadlock detected.");
			} else {
				return;
			}
		}finally {
			this.lockDeadLockDetection.unlock();
		}
	}

	void aquireLock(String threadId){
		this.lockDeadLockDetection.lock();
		try{
			//threadId is owner of my lock
			this.deadLockMap.remove(threadId);
			this.deadLockMap.put(this.lockId, threadId);
		}finally {
			this.lockDeadLockDetection.unlock();
		}
	}

	void lockIntentition(String threadId){
		this.lockDeadLockDetection.lock();
		try{
			//threadId wants my lock
			this.deadLockMap.put(threadId, this.lockId);
		}finally {
			this.lockDeadLockDetection.unlock();
		}
	}

	void removeLock(){
		this.lockDeadLockDetection.lock();
		try{
			//my lock doesn't belong to any thread
			this.deadLockMap.remove(this.lockId);
		}finally {
			this.lockDeadLockDetection.unlock();
		}
	}

	public void lockInterruptibly() throws InterruptedException {
	}

	public Condition newCondition() {
		return null;
	}

	public boolean tryLock() {
		return false;
	}

	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		return false;
	}
}



