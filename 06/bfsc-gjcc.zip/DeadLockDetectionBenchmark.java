package trabalhos;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DeadLockDetectionBenchmark {
	static Map<String,String> deadLockMap	= new HashMap<String,String>();	
	static final int THREADS_QTY = 100;
	static final int COUNTERS_QTY = 10;
	static Counter[] counters = new Counter[COUNTERS_QTY];
	static {
		for (int i = 0; i < counters.length; i++) {
			counters[i] = new Counter();
		}
	}

	private static class IncrementerThread extends Thread {
		private String tid;
		private Random random = new Random();
		private long incrementedTimes = 0;
		public IncrementerThread(int tid) {
			this.tid = "Thread"+tid;
		}
		public void run() {
			while (incrementedTimes < 1000) {
				int counter = random.nextInt(COUNTERS_QTY);
				counters[counter].increment();
				incrementedTimes++;
			}
		}
		public long getIncrementedTimes() {
			return incrementedTimes;
		}
		public String getTid() {
			return tid;
		}
	}

	private static class Counter {
		private Lock lock = new TTasExponentialBackoffLock(); 
		//private Lock lock = new TTASLockDeadLock("lock1",deadLockMap); 
		private long count = 0;
		public void increment() {
			lock.lock();
			count++;
			lock.unlock();
		}
		public long getCount() {
			return count;
		}
	}

	public static void main(String[] args) {
		IncrementerThread[] threads = new IncrementerThread[THREADS_QTY];
		long begin = System.currentTimeMillis();
		for (int i = 0; i < THREADS_QTY; i++) {
			threads[i] = new IncrementerThread(i);
			threads[i].start();
		}
		for (IncrementerThread thread : threads) {
			try {
				thread.join();
				//System.out.println(thread.getTid() + " incremented " + thread.getIncrementedTimes() + " times.");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		long end = System.currentTimeMillis();
		System.out.println(end - begin);

	}

}




class TTASLockDeadLock implements Lock {

	private AtomicBoolean state 			= new AtomicBoolean(false);
	private long backoff 					= 1;
	private static final long BACKOFF_LIMIT = Short.MAX_VALUE;

	//for deadlock detection purposes
	String lockId								= "";
	Lock lockDeadLockDetection					= new ReentrantLock();
	Map<String,String> deadLockMap				= new HashMap<String,String>();	


	public TTASLockDeadLock(String lockId, Map<String,String> deadLockMap){
		this.lockId = lockId;
		this.deadLockMap = deadLockMap;
	}

	public void lock() {
		while(true) {
			while (state.get()) {}
			if (!state.getAndSet(true)) {
				return;
			} 
			else {
				long delay = backoff;
				backoff = Math.min(BACKOFF_LIMIT, backoff << 1);
				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
	}

	public void lock(String threadId) {
		try {
			while(true) {
				this.lockIntentition(threadId);
				checkDeadlock(threadId);
				while (state.get()) {}
				if (!state.getAndSet(true)) {
					aquireLock(threadId);
					return;
				} 
				else {
					long delay = backoff;
					backoff = Math.min(BACKOFF_LIMIT, backoff + 1);
					try {
						Thread.sleep(delay);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (IllegalAccessException e) {
			System.out.println(e.getMessage());
		}
	}

	public void unlock() {
		state.set(false);
		this.removeLock();

	}

	void checkDeadlock(String threadId) throws IllegalAccessException{
		this.lockDeadLockDetection.lock();
		try{
			/* 	deadlock:
			 * 	l2 l1 t1 t2
			 *	t1 t2 l1 l2
			 */
			String lockOwnerThreadId = this.deadLockMap.get(this.lockId);
			String lockWantedByThreadId = this.deadLockMap.get(lockOwnerThreadId);
			String otherThreadId = this.deadLockMap.get(lockWantedByThreadId);
			if(threadId.equals(otherThreadId)){
				throw new IllegalAccessException("Deadlock detected.");
			} else {
				return;
			}
		}finally {
			this.lockDeadLockDetection.unlock();
		}
	}

	void aquireLock(String threadId){
		this.lockDeadLockDetection.lock();
		try{
			//threadId is owner of my lock
			this.deadLockMap.remove(threadId);
			this.deadLockMap.put(this.lockId, threadId);
		}finally {
			this.lockDeadLockDetection.unlock();
		}
	}

	void lockIntentition(String threadId){
		this.lockDeadLockDetection.lock();
		try{
			//threadId wants my lock
			this.deadLockMap.put(threadId, this.lockId);
		}finally {
			this.lockDeadLockDetection.unlock();
		}
	}

	void removeLock(){
		this.lockDeadLockDetection.lock();
		try{
			//my lock doesn't belong to any thread
			this.deadLockMap.remove(this.lockId);
		}finally {
			this.lockDeadLockDetection.unlock();
		}
	}

	public void lockInterruptibly() throws InterruptedException {
	}

	public Condition newCondition() {
		return null;
	}

	public boolean tryLock() {
		return false;
	}

	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		return false;
	}
}



