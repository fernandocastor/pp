import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.lang.ThreadLocal;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@SuppressWarnings("unused")
public class CLHQueueLock implements Lock {
	AtomicReference<QNode> tail;
	ThreadLocal<QNode> myNode, myPred;

	public CLHQueueLock() {
		tail = new AtomicReference<QNode>(new QNode());
		myNode = new ThreadLocal<QNode>() {
			protected QNode initialValue() {
				return new QNode();
			}
		};
		myPred = new ThreadLocal<QNode>() {
			protected QNode initialValue() {
				return null;
			}
		};
	}

	public void lock() {
		QNode qnode = myNode.get();
		qnode.locked = true;
		QNode pred = tail.getAndSet(qnode);
		myPred.set(pred);
		while (pred.locked) {
		}
	}

	public void unlock() {
		QNode qnode = myNode.get();
		qnode.locked = false;
		myNode.set(myPred.get());
	}

	public Condition newCondition() {
		throw new java.lang.UnsupportedOperationException();
	}

	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		throw new java.lang.UnsupportedOperationException();
	}

	public boolean tryLock() {
		throw new java.lang.UnsupportedOperationException();
	}

	public void lockInterruptibly() throws InterruptedException {
		throw new java.lang.UnsupportedOperationException();
	}

	static class QNode {
		public boolean locked = false;
	}

	
	

	// ======================== TEST CODE

	private static final int THREADS_QTY 		= 200;
	private static final int COUNTERS_QTY 		= 10;
	private static final long THREADS_DURATION 	= 120000;

	private static Counter[] counters = new Counter[COUNTERS_QTY];

	static {
		for (int i = 0; i < counters.length; i++) {
			counters[i] = new Counter();
		}
	}

	public static void main(String[] args) {
		IncrementerThread[] threads = new IncrementerThread[THREADS_QTY];

		long begin = System.currentTimeMillis();

		for (int i = 0; i < THREADS_QTY; i++) {
			threads[i] = new IncrementerThread(i);
			threads[i].start();
		}

		for (IncrementerThread thread : threads) {
			try {
				thread.join();
				//System.out.println("TID " + thread.getTid() + " incremented " + thread.getIncrementedTimes() + " times.");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println(System.currentTimeMillis() - begin);
	}

	private static class IncrementerThread extends Thread {
		private int tid;
		private Random random = new Random();
		private long incrementedTimes = 0;

		public IncrementerThread(int tid) {
			this.tid = tid;
		}

		public void run() {

			while (incrementedTimes < 1000) {
				int counter = random.nextInt(COUNTERS_QTY);
				counters[counter].increment();
				incrementedTimes++;
			}
			
		}

		public long getIncrementedTimes() {
			return incrementedTimes;
		}

		public int getTid() {
			return tid;
		}

	}

	private static class Counter {
		private Lock lock = new ReentrantLock(); 
		private long count = 0;

		public void increment() {
			lock.lock();
			count++;
			lock.unlock();
		}

		public long getCount() {
			return count;
		}
	}
}
