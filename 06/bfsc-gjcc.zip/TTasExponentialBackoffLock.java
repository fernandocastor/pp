import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

@SuppressWarnings("unused")
public class TTasExponentialBackoffLock implements Lock {

	private AtomicBoolean state 			= new AtomicBoolean(false);
	private long backoff 					= 1;
	private static final long BACKOFF_LIMIT = Short.MAX_VALUE;

	public void lock() {
		while(true) {
			while (state.get()) {}
			if (!state.getAndSet(true)) {
				return;
			} 
			else {
				long delay = backoff;
				backoff = Math.min(BACKOFF_LIMIT, backoff + 1);
				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}
	}

	public void unlock() {
		state.set(false);
	}

	public void lockInterruptibly() throws InterruptedException {

	}

	public Condition newCondition() {
		return null;
	}

	public boolean tryLock() {
		return false;
	}

	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		return false;
	}


	// ======================== TEST CODE

	private static final int THREADS_QTY = 10;
	private static final int COUNTERS_QTY = 10;
	private static final long THREADS_DURATION = 120000;

	private static Counter[] counters = new Counter[COUNTERS_QTY];

	static {
		for (int i = 0; i < counters.length; i++) {
			counters[i] = new Counter();
		}
	}

	public static void main(String[] args) {
		IncrementerThread[] threads = new IncrementerThread[THREADS_QTY];
		for (int i = 0; i < THREADS_QTY; i++) {
			threads[i] = new IncrementerThread(i);
			threads[i].start();
		}
		for (IncrementerThread thread : threads) {
			try {
				thread.join();
				System.out.println("TID " + thread.getTid() + " incremented " + thread.getIncrementedTimes() + " times.");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private static class IncrementerThread extends Thread {
		private int tid;
		private Random random = new Random();
		private long incrementedTimes = 0;

		public IncrementerThread(int tid) {
			this.tid = tid;
		}

		public void run() {
			long begin = System.currentTimeMillis();

			while ((System.currentTimeMillis() - begin) <= THREADS_DURATION) {
				int counter = random.nextInt(COUNTERS_QTY);
				counters[counter].increment();
				incrementedTimes++;
			}
		}

		public long getIncrementedTimes() {
			return incrementedTimes;
		}

		public int getTid() {
			return tid;
		}

	}

	private static class Counter {
		private Lock lock = new TTasExponentialBackoffLock(); 
		private long count = 0;
		public void increment() {
			lock.lock();
			count++;
			lock.unlock();
		}

		public long getCount() {
			return count;
		}

	}

}
