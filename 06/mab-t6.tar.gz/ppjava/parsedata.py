#!/usr/bin/env python2

import csv, sys

def main():
    print "nthreads,locktype,incdata"
    with open(sys.argv[1]) as csvfile:
        reader = csv.DictReader(csvfile)

        for row in reader:
            nthreads = row['nthreads']
            locktype = row['type']
            incdata = row['incdata']
            
            for s in incdata.split("-"):
                print "{},{},{}".format(nthreads,locktype,s)

main()
