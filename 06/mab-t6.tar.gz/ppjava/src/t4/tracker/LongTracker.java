package t4.tracker;

public class LongTracker extends Tracker {

	long value = 0;
	
	@Override
	public void increment() {
		value++;
	}

	@Override
	public Number get() {
		return value;
	}
}
