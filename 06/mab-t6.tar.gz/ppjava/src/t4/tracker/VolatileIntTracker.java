package t4.tracker;

public class VolatileIntTracker extends Tracker {
	
	volatile int value = 0;
	
	@Override
	public void increment() {
		value++;
	}

	@Override
	public Number get() {
		return value;
	}

}
