package t4.tracker;

public abstract class Tracker {
	
	public abstract void increment();
	
	public abstract Number get();
}