package t4.tracker;

public class IntTracker extends Tracker {

	int value = 0;
	
	@Override
	public void increment() {
		value++;
	}

	@Override
	public Number get() {
		return value;
	}
}
