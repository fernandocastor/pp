package t4;

import t4.tracker.AtomicIntegerTracker;
import t4.tracker.AtomicLongTracker;
import t4.tracker.DoubleTracker;
import t4.tracker.FloatTracker;
import t4.tracker.IntTracker;
import t4.tracker.LongTracker;
import t4.tracker.Tracker;
import t4.tracker.VolatileIntTracker;
import t4.tracker.VolatileLongTracker;

enum FieldType {
	INT, FLOAT, DOUBLE, LONG, V_INT, V_LONG, ATOMIC_LONG, ATOMIC_INT
}

public class StatisticalCounting {

	protected static volatile boolean shouldRun = true;

	static class Counter extends Thread {
		Tracker tracker;

		Counter(Tracker tracker) {
			this.tracker = tracker;
		}

		public void run() {
			while (shouldRun) {
				tracker.increment();
			}
		}
	}

	static volatile long end = 0;

	public static void main(String[] args) {
		int nthreads = Integer.parseInt(args[0]);
		final long max = Long.parseLong(args[1]);
		final FieldType type = FieldType.valueOf(args[2]);
		final int sleep = Integer.parseInt(args[3]); // 0 for no sleep
		final Counter[] threads = new Counter[nthreads];

		for (int i = 0; i < 10; i++) {
			end = 0;
			shouldRun = true;
			long start = System.nanoTime();
			try {
				for (int j = 0; j < nthreads; j++) {
					Counter c = new Counter(getTracker(type));
					threads[j] = c;
				}
				runExperiment(max, sleep, threads);
			} catch (InterruptedException e) {
				System.err.println("Thread interrupted...");
			}

			double time = (end - start) / 1000000000.0;
			System.out
					.println(type + "," + nthreads + "," + sleep + "," + time);
		}
	}

	public static void runExperiment(final long max, final int sleep,
			final Counter[] threads) throws InterruptedException {
		Thread aggregator = new Thread(new Runnable() {
			@Override
			public void run() {
				while (shouldRun) {
					long aggregate = 0;
					for (Counter c : threads) {
						aggregate = aggregate + c.tracker.get().longValue();
					}
					if (aggregate >= max) {
						shouldRun = false;
						end = System.nanoTime();
					} else if (sleep > 0) {
						try {
							Thread.sleep(sleep);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		});
		for (Counter c : threads) {
			c.start();
		}
		aggregator.start();

		for (Counter c : threads) {
			c.join();
		}
		aggregator.join();
	}

	private static Tracker getTracker(FieldType type) {
		switch (type) {
		case INT:
			return new IntTracker();
		case LONG:
			return new LongTracker();
		case FLOAT:
			return new FloatTracker();
		case DOUBLE:
			return new DoubleTracker();
		case V_INT:
			return new VolatileIntTracker();
		case V_LONG:
			return new VolatileLongTracker();
		case ATOMIC_INT:
			return new AtomicIntegerTracker();
		case ATOMIC_LONG:
			return new AtomicLongTracker();
		default:
			throw new RuntimeException("Not implemented yet");
		}
	}
}
