package t5;

import java.util.Deque;

public class DequeTest {

	static final int TIME_LIMIT = 10;
	static volatile boolean shouldStop = false;

	public void test(Deque<Integer> deq) throws InterruptedException {
		Writer left1 = getWriter(true, deq);
		Writer left2 = getWriter(true, deq);
		Writer right1 = getWriter(false, deq);
		Writer right2 = getWriter(false, deq);

		Reader remleft1 = getRemover(true, deq);
		Reader remleft2 = getRemover(true, deq);
		Reader remright1 = getRemover(false, deq);
		Reader remright2 = getRemover(false, deq);

		long start = System.nanoTime();
		left1.start();
		right1.start();
		remleft1.start();
		remright1.start();
		left2.start();
		right2.start();
		remleft2.start();
		remright2.start();

		while ((System.nanoTime() - start) / 1000000000.0 < TIME_LIMIT) {
			Thread.sleep(50);
		}
		shouldStop = true;
		left1.join();
		right1.join();
		remleft1.join();
		remright1.join();
		left2.join();
		right2.join();
		remleft2.join();
		remright2.join();

		System.out.println("Total operations: "
				+ (left1.ops + right1.ops + remleft1.ops + remright1.ops
						+left2.ops + right2.ops + remleft2.ops + remright2.ops));
	}

	private Reader getRemover(final boolean removeLeft, final Deque<Integer> deq) {
		return new Reader(removeLeft, deq);
	}

	static class Reader extends Thread {
		int ops = 0;
		boolean removeLeft = false;
		Deque<Integer> deq;

		public Reader(boolean removeLeft, Deque<Integer> deq) {
			super();
			this.removeLeft = removeLeft;
			this.deq = deq;
		}

		@Override
		public void run() {
			while (!shouldStop) {

				if (removeLeft) {
					Integer i = deq.removeFirst();
					if (i == null) {
						try {
							Thread.sleep(1);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				} else {
					Integer i = deq.removeLast();
					if (i == null) {
						try {
							Thread.sleep(1);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}
	}

	static class Writer extends Thread {
		int ops = 0;
		boolean addLeft = false;
		Deque<Integer> deq;

		public Writer(int ops, boolean addLeft, Deque<Integer> deq) {
			super();
			this.ops = ops;
			this.addLeft = addLeft;
			this.deq = deq;
		}

		public void run() {
			while (!shouldStop) {
				if (addLeft) {
					deq.addFirst(0);
				} else {
					deq.addLast(0);
				}
				ops++;
			}
		}
	}

	private static Writer getWriter(final boolean addLeft,
			final Deque<Integer> deq) {
		return new Writer(0, addLeft, deq);
	}

	public static void main(String[] args) throws Exception {
		boolean doublelock = Boolean.parseBoolean(args[0]);
		int nbuckets = Integer.parseInt(args[1]);
		Deque<Integer> deq;
		if (doublelock) {
			deq = new ConcurrentHashDeque<Integer>(nbuckets);
		} else {
			deq = new ConcurrentHashDequeSingleLock<Integer>(nbuckets);
		}

		new DequeTest().test(deq);
	}
}
