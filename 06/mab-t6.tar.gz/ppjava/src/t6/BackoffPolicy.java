package t6;

public enum BackoffPolicy {
	EXPONENTIAL,ADDITIVE,NO_BACKOFF
}
