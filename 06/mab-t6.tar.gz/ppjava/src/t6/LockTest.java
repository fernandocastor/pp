package t6;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

enum LockType {
	TAS_EXPONENTIAL, TAS_INCREMENTAL, REENTRANT, CLH
}

public class LockTest {

	static volatile boolean stop = false;
	List<Foo> fooRegister;
	List<Runner> runnerRegister;

	static class Foo {
		Lock lock;
		int dummy;

		public Foo(Lock lock) {
			this.lock = lock;
			dummy = 0;
		}

		public void increment() {
			lock.lock();
			try {
				dummy++;
			} finally {
				lock.unlock();
			}
		}

	}

	class Runner extends Thread {
		int increment;
		Random random;
		boolean stopWithAThousand;

		Runner(boolean stopWithAThousand) {
			random = new Random();
			increment = 0;
			this.stopWithAThousand = stopWithAThousand;
		}

		@Override
		public void run() {
			int size = fooRegister.size();
			while (!stop) {
				Foo f = fooRegister.get(random.nextInt(size));
				f.increment();
				increment++;

				if (stopWithAThousand && increment >= 1000) {
					break;
				}
			}
		}
	}

	// timelimit in s.
	public void runExperiment(int nThreads, int nObjects, LockType type,
			int timelimit, boolean thousand) {

		setup(nThreads, nObjects, type, thousand);
		long start = System.nanoTime();
		runAndWait(timelimit, thousand);
		long end = System.nanoTime();
		double time = (end - start) / 1000000000.0;

		System.out.println("nthreads,nobjects,type,timelimit,thousand,time,incdata");

		StringBuffer sb = new StringBuffer();
		for (Runner r : runnerRegister) {
			sb.append(r.increment);
			sb.append("-");
		}
		System.out.printf("%d,%d,%s,%d,%s,%f,%s", nThreads, nObjects,
				type.toString(), timelimit, thousand ? "TRUE" : "FALSE",
				time, sb.toString());
	}

	public void runAndWait(int timelimit, boolean thousand) {
		long start = System.nanoTime();

		for (Runner r : runnerRegister) {
			r.start();
		}

		if (!thousand) {
			while ((System.nanoTime() - start) / 1000000000.0 < timelimit) {
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			LockTest.stop = true;
		}

		for (Runner r : runnerRegister) {
			try {
				r.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public void setup(int nThreads, int nObjects, LockType type,
			boolean thousand) {
		fooRegister = new ArrayList<LockTest.Foo>(nObjects);
		for (int i = 0; i < nObjects; i++) {
			Lock lock = getLock(type);
			Foo f = new Foo(lock);
			fooRegister.add(f);
		}

		runnerRegister = new ArrayList<LockTest.Runner>(nThreads);
		for (int i = 0; i < nThreads; i++) {
			Runner r = new Runner(thousand);
			runnerRegister.add(r);
		}
	}

	private Lock getLock(LockType type) {
		switch (type) {
		case REENTRANT:
			return new ReentrantLock();
		case TAS_EXPONENTIAL:
			return new TASLock(BackoffPolicy.EXPONENTIAL);
		case TAS_INCREMENTAL:
			return new TASLock(BackoffPolicy.ADDITIVE);
		case CLH:
			return new CLHQueueLock();
		default:
			throw new RuntimeException("wat");
		}
	}
	
	public static void main(String[] args) {
		int nthreads = Integer.parseInt(args[0]);
		int nobj = Integer.parseInt(args[1]);
		LockType type = LockType.valueOf(args[2]);
		int timelimit = Integer.parseInt(args[3]);
		boolean thousand = Boolean.parseBoolean(args[4]);
		new LockTest().runExperiment(nthreads, nobj, type, timelimit, thousand);
	}
}
