package t6;

import java.util.Random;

public class Backoff {

	final int minDelay, maxDelay;
	int limit;
	final Random random;
	final boolean isExponential;

	public Backoff(int min, int max, boolean isExponential) {
		minDelay = min;
		maxDelay = max;
		this.isExponential = isExponential;
		limit = minDelay;
		random = new Random();
	}

	public void backoff() throws InterruptedException {
		int delay = random.nextInt(limit) + 1;
		if (isExponential) {
			limit = Math.min(maxDelay, 2 * delay);
		} else {
			limit = Math.min(maxDelay, limit + delay);
		}
		Thread.sleep(delay);
	}

}
