package t6;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class TASLock implements Lock {

	public static final int MIN_DELAY = 1;
	public static final int MAX_DELAY = 16;

	AtomicBoolean state;
	Backoff backoff;
	BackoffPolicy bp;

	public TASLock(BackoffPolicy bp) {
		this.bp = bp;
		this.state = new AtomicBoolean(false);
		if (bp == BackoffPolicy.NO_BACKOFF) {
			this.backoff = null;
		} else {
			this.backoff = new Backoff(MIN_DELAY, MAX_DELAY,
					bp == BackoffPolicy.EXPONENTIAL);
		}
	}

	@Override
	public void lock() {
		while (state.getAndSet(true)) {
			switch (bp) {
			case NO_BACKOFF:
				break;
			default:
				try {
					backoff.backoff();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				break;
			}
		}
	}

	@Override
	public void unlock() {
		state.set(false);
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
		throw new RuntimeException("not implemented");
	}

	@Override
	public boolean tryLock() {
		throw new RuntimeException("not implemented");
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		throw new RuntimeException("not implemented");
	}

	@Override
	public Condition newCondition() {
		throw new RuntimeException("not implemented");
	}

}
