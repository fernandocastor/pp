#!/bin/bash

for i in {1..10}
do
	for nt in "10" "50" "100" "200"
	do
		for lock in "REENTRANT" "TAS_EXPONENTIAL" "TAS_INCREMENTAL" "CLH"
		do
			for fixed in "false" "true"
			do
				java -cp bin/ t6.LockTest "$nt" 10 "$lock" 120 "$fixed" >> logt6
			done
		done
	done
done
