import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.ArrayList;
import java.util.Random;
import java.util.RandomAccess;

public class TASExpBackoff implements Lock {

	private AtomicBoolean state = new AtomicBoolean(false);
	final int MAX;
	int limit;
	final Random random;

	public TASExpBackoff(int max) {

		MAX = max;
		limit = 1;
		random = new Random();
	}

	public void backoff() throws InterruptedException {
		int delay = random.nextInt(limit);
		limit = Math.min(MAX, 2 *  limit);
		Thread.sleep(delay);
	}

	public void lock() {
		TASExpBackoff backoff = new TASExpBackoff(MAX);
		while (true) {
			while (state.get()) {};
			if (!state.getAndSet(true)) {
				return;
			} else {
				try {
					backoff.backoff();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
	}

  @Override
  public void lockInterruptibly() throws InterruptedException {  
  }

  @Override
  public boolean tryLock() {
    return false;
  }

  @Override
  public boolean tryLock(long time, TimeUnit unit)
      throws InterruptedException {
    return false;
  }

  @Override
  public void unlock() {
	  state.set(false);

  }

  @Override
  public Condition newCondition() {
    return null;
  }

  private static class Counter {
  
    private Lock lock = new TASExpBackoff(Short.MAX_VALUE);
    private int count = 0;
    public void increment() {
      this.lock.lock();
    	try {
    		this.count++;
    	} finally {
    		this.lock.unlock();
    	}
    }
  }

  private static class IncThread extends Thread {

	  AtomicBoolean end = new AtomicBoolean(false);
	  int count_inc = 0;
    int id;
	  final Random rand = new Random();

    public IncThread(int index) {
      id = index;
    }
	  public void run() {
		  do {
			  count_inc++;
			  int i = rand.nextInt(10);
			  counter[i].increment();
		  } while (!end.get());
	  }
  }

  private static Counter[] counter = new Counter[10];
  
  public static void main(String[] args) {

    int nThreads;
    int timeDuration = 120000;

    if (args.length == 0) {
      nThreads = 10;
    } else {
      nThreads = Integer.parseInt(args[0]);
    }

    IncThread[] incT = new IncThread[nThreads];

    for (int i = 0; i < 10; i++)
      counter[i] = new Counter();

    long startTime = System.currentTimeMillis();
    for (int i = 0; i < nThreads; i++) {
      incT[i] = new IncThread(i);
      incT[i].start();
    }

    while ((System.currentTimeMillis() - startTime) <= timeDuration ){}
    for (int i = 0; i < incT.length; i++)
    	incT[i].end.set(true);
    
    for (int i = 0; i < incT.length; i++)
    	System.out.println("Thread "+ i +" incremented "+incT[i].count_inc);
  }

}
