import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.ArrayList;
import java.util.Random;
import java.util.RandomAccess;

public class TOLock implements Lock {

	private AtomicReference<CLHNode> tail = new AtomicReference<CLHNode>(new CLHNode());
	
	private ThreadLocal<CLHNode> myNode = new ThreadLocal<CLHNode>() {
		protected CLHNode initialValue() {
			return new CLHNode();
		}
	};
	
	private ThreadLocal<CLHNode> myPredecessor = new ThreadLocal<CLHNode>() {
		protected CLHNode initialValue() {
			return null;
		}
	};

	@Override
	public void lock() {
		CLHNode node = this.myNode.get();
		node.wait = true;
		
		CLHNode predecessor = this.tail.getAndSet(node);
		this.myPredecessor.set(predecessor);
		
		while(predecessor.wait) {}
	}

	@Override
	public void unlock() {
		CLHNode node = this.myNode.get();
		node.wait = false;
		this.myNode.set(this.myPredecessor.get());
	}
	
	class CLHNode {
		volatile boolean wait = false;
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {}

	@Override
	public boolean tryLock() {
		return false;
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		return false;
	}

	@Override
	public Condition newCondition() {
		return null;
	}

  private static class Counter {
  
    private Lock lock = new TOLock();
    private int count = 0;
    public void increment() {
      this.lock.lock();
    	try {
    		this.count++;
    	} finally {
    		this.lock.unlock();
    	}
    }
  }

  private static class IncThread extends Thread {

	  AtomicBoolean end = new AtomicBoolean(false);
	  int index;
	  int count_inc = 0;
	  final Random rand = new Random();

	  public IncThread(int t_length) {
		  index = t_length;
	  }
	  public void run() {
		  do {
			  count_inc++;
			  int i = rand.nextInt(index);
			  counter[i].increment();
		  } while (!end.get());
	  }
  }

  private static Counter[] counter = new Counter[10];
  
  public static void main(String[] args) {

    int nThreads;
    int timeDuration = 120000;

    if (args.length == 0) {
      nThreads = 10;
    } else {
      nThreads = Integer.parseInt(args[0]);
    }

    IncThread[] incT = new IncThread[nThreads];

    for (int i = 0; i < 10; i++)
      counter[i] = new Counter();

    long startTime = System.currentTimeMillis();
    for (int i = 0; i < nThreads; i++) {
      incT[i] = new IncThread(10);
      incT[i].start();
    }

    while ((System.currentTimeMillis() - startTime) <= timeDuration ){}
    for (int i = 0; i < incT.length; i++)
    	incT[i].end.set(true);
    
    for (int i = 0; i < incT.length; i++)
    	System.out.println("Thread "+ i +" incremented "+incT[i].count_inc);
  }

}

