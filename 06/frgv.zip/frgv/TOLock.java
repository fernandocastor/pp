import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.ArrayList;
import java.util.Random;
import java.util.RandomAccess;



public class TOLock implements Lock {

	static QNode AVAILABLE = new QNode();
	AtomicReference<QNode> tail;
	ThreadLocal<QNode> myNode;

	public TOLock() {
		tail = new AtomicReference<QNode>(null);
		myNode = new ThreadLocal<QNode>() {
			protected QNode initialValue() {
				return new QNode();
			}
		};
	}

	public void lock() {
		QNode qnode = myNode.get();
		QNode pred = tail.getAndSet(qnode);
		if (pred != null) {
			qnode.locked = true;
			pred.next = qnode;
			while (qnode.locked) {}
		}
	}

	public void lockInterruptibly() throws InterruptedException {  
	}

  @Override  
  public boolean tryLock() {
    return false;
  }

  public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
	  long startTime = System.currentTimeMillis();
	  long patience = TimeUnit.MILLISECONDS.convert(time, unit);
	  QNode qnode = new QNode();
	  myNode.set(qnode);
	  qnode.pred = null;
	  QNode myPred = tail.getAndSet(qnode);
	  if (myPred == null || myPred.pred == AVAILABLE) {
		  return true;
	  }
	  while (System.currentTimeMillis() - startTime < patience) {
		  QNode predPred = myPred.pred;
		  if (predPred == AVAILABLE) {
			  return true;
		  } else if (predPred != null) {
			  myPred = predPred;
		  }
	  }
	  if (!tail.compareAndSet(qnode, myPred))
		  qnode.pred = myPred;
	return false;
  }

  public void unlock() {
	  QNode qnode = myNode.get();
	  if (!tail.compareAndSet(qnode, null))
		  qnode.pred = AVAILABLE;
  }
  
  static class QNode {
		public QNode next;
		public boolean locked;
		public QNode pred = null;
	}

  public Condition newCondition() {
    return null;
  }

  private static class Counter {
  
    private Lock lock = new TOLock();
    private int count = 0;
    public void increment() {
    	try {
    		this.lock.lock();
    		this.count++;
    	} finally {
    		this.lock.unlock();
    	}
    }
  }

  private static class IncThread extends Thread {

	  AtomicBoolean end = new AtomicBoolean(false);
	  int index;
	  int count_inc = 0;
	  final Random rand = new Random();

	  public IncThread(int t_length) {
		  index = t_length;
	  }
	  public void run() {
		  do {
			  count_inc++;
			  int i = rand.nextInt(index);
			  counter[i].increment();
		  } while (!end.get());
	  }
  }

  private static Counter[] counter = new Counter[10];
  
  public static void main(String[] args) {

    int nThreads;
    int timeDuration = 120000;

    if (args.length == 0) {
      nThreads = 10;
    } else {
      nThreads = Integer.parseInt(args[0]);
    }

    IncThread[] incT = new IncThread[nThreads];

    for (int i = 0; i < nThreads; i++)
      counter[i] = new Counter();

    long startTime = System.currentTimeMillis();
    for (int i = 0; i < counter.length; i++) {
      incT[i] = new IncThread(nThreads);
      incT[i].start();
    }

    while ((System.currentTimeMillis() - startTime) <= timeDuration ){}
    for (int i = 0; i < incT.length; i++)
    	incT[i].end.set(true);
    
    for (int i = 0; i < incT.length; i++)
    	System.out.println("Thread "+ i +" incremented "+incT[i].count_inc);
  }

}
