import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.ArrayList;
import java.util.Random;
import java.util.RandomAccess;

public class TestDeadLock implements Lock {

	int idThread = -1;
	private AtomicBoolean state = new AtomicBoolean(false);
	final int MAX;
	int limit;
	final Random random;

	public TestDeadLock() {

		MAX = Short.MAX_VALUE;
		limit = 1;
		random = new Random();
	}

	public void backoff() throws InterruptedException {
		int delay = random.nextInt(limit);
		limit = Math.min(MAX, 2 *  limit);
		Thread.sleep(delay);
	}

	public void newLock(int index) throws IllegalAccessException {

		if (state.compareAndSet(true, false) && index != idThread) {
			throw new IllegalAccessException("DEADLOCK DETECTED");
		} else {
			return;
		}
	}

	public void lock() {
		TestDeadLock backoff = new TestDeadLock();
		while (true) {
			while (state.get()) {};
			if (!state.getAndSet(true)) {
				return;
			} else {
				try {
					backoff.backoff();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
		}
	}

  @Override
  public void lockInterruptibly() throws InterruptedException {  
  }

  @Override
  public boolean tryLock() {
    return false;
  }

  @Override
  public boolean tryLock(long time, TimeUnit unit)
      throws InterruptedException {
    return false;
  }

  @Override
  public void unlock() {
    idThread = -1;
	  state.set(false);

  }

  @Override
  public Condition newCondition() {
    return null;
  }

  private static class Counter {
  
    private TestDeadLock lock = new TestDeadLock();
    private TestDeadLock lock2 = new TestDeadLock();
    private int count = 0;

    public void increment(int index) throws IllegalAccessException {

      this.lock.newLock(index);
      this.lock.lock();
    	try {
    		this.lock2.lock();
    		this.count++;
        //System.out.println(count);
    	} finally {
    		this.lock2.unlock();
    		this.lock.unlock();
    	}
    }
  }

  private static class IncThread extends Thread {

	  AtomicBoolean end = new AtomicBoolean(false);
	  int count_inc = 0;
    int countDeadLock = 0;
    int id;
	  final Random rand = new Random();

    public IncThread(int index) {
      id = index;
    }
	  public void run() {
		  do {
			  count_inc++;
			  int i = rand.nextInt(2);
			  try {
				counter[i].increment(id);
			} catch (IllegalAccessException e) {
        countDeadLock++;
				//System.out.println(e.getMessage());
				//e.printStackTrace();
			}
		  } while (!end.get());
	  }
  }

  private static Counter[] counter = new Counter[2];
  
  public static void main(String[] args) {

    int nThreads;
    int timeDuration = 120000;

    if (args.length == 0) {
      nThreads = 2;
    } else {
      nThreads = Integer.parseInt(args[0]);
    }

    IncThread[] incT = new IncThread[nThreads];

    for (int i = 0; i < 2; i++)
      counter[i] = new Counter();

    long startTime = System.currentTimeMillis();
    for (int i = 0; i < nThreads; i++) {
      incT[i] = new IncThread(i);
      incT[i].start();
    }

    while ((System.currentTimeMillis() - startTime) <= timeDuration ){}
    for (int i = 0; i < incT.length; i++)
    	incT[i].end.set(true);
    
    for (int i = 0; i < incT.length; i++)
    	System.out.println("Thread "+ i +" incremented "+incT[i].count_inc);
  }

}
