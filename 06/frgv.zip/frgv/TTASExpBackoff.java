import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.ArrayList;
import java.util.Random;
import java.util.RandomAccess;
import java.util.concurrent.locks.ReentrantLock;

public class TTASExpBackoff implements Lock {

  private AtomicBoolean state = new AtomicBoolean(false);

  private static final long BACKOFF_LIMIT = Short.MAX_VALUE;
  private long backoff = 1;

  @Override
  public void lock() {
    while (true) {
      while (state.get()) {}
      if (!state.getAndSet(true)) {
        return;
      } else {
        long delay = backoff;
        backoff = Math.min(BACKOFF_LIMIT, backoff *2);
        try {
          Thread.sleep(delay);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
      }      
    }
  }

  @Override
  public void lockInterruptibly() throws InterruptedException {
    // TODO Auto-generated method stub    
  }

  @Override
  public boolean tryLock() {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public boolean tryLock(long time, TimeUnit unit)
      throws InterruptedException {
    // TODO Auto-generated method stub
    return false;
  }

  @Override
  public void unlock() {
    // TODO Auto-generated method stub
  }

  @Override
  public Condition newCondition() {
    // TODO Auto-generated method stub
    return null;
  }

  private static class Counter {
  
    private Lock lock = new ReentrantLock();
    private int count = 0;
    public void increment() {
    	try {
    		this.lock.lock();
    		this.count++;
    	} finally {
    		this.lock.unlock();
    	}
    }
  }

  private static class IncThread extends Thread {

	  AtomicBoolean end = new AtomicBoolean(false);
	  int count_inc = 0;
	  final Random rand = new Random();

	  public void run() {
		  do {
			  count_inc++;
			  int i = rand.nextInt(10);
			  counter[i].increment();
		  } while (!end.get());
	  }
  }

  private static Counter[] counter = new Counter[10];
  
  public static void main(String[] args) {

    int nThreads;
    int timeDuration = 120000;

    if (args.length == 0) {
      nThreads = 10;
    } else {
      nThreads = Integer.parseInt(args[0]);
    }

    IncThread[] incT = new IncThread[nThreads];

    for (int i = 0; i < 10; i++)
      counter[i] = new Counter();

    long startTime = System.currentTimeMillis();
    for (int i = 0; i < nThreads; i++) {
      incT[i] = new IncThread();
      incT[i].start();
    }

    while ((System.currentTimeMillis() - startTime) <= timeDuration ){}
    for (int i = 0; i < incT.length; i++)
    	incT[i].end.set(true);
    
    for (int i = 0; i < incT.length; i++)
    	System.out.println("Thread "+ i +" incremented "+incT[i].count_inc);
  }

}
