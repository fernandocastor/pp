package backoff;

public enum BackoffType {
	EXPONENTIAL, ADDITIVE;
}
