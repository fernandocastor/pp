package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

public class SimpleReadWriteLock implements ReadWriteLock {
	private int readers;
	private boolean writer;
	
	private Object monitor;
	private Lock readLock, writeLock;
	
	public SimpleReadWriteLock() {
		this.writer = false;
		this.readers = 0;
		
		this.monitor = new Object();
		this.readLock = new ReadLock();
		this.writeLock = new WriteLock();
	}

	@Override
	public Lock readLock() {
		return this.readLock;
	}

	@Override
	public Lock writeLock() {
		return this.writeLock;
	}
	
	private class ReadLock implements Lock {
		
		@Override
		public void lock() {
			synchronized(monitor) {
				while(writer) {
					try {
						monitor.wait();
					} catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				readers++;
			}
		}

		@Override
		public void unlock() {
			synchronized(monitor) {
				readers--;
				
				if(readers==0)
					monitor.notifyAll();
			}
		}

		@Override
		public void lockInterruptibly() throws InterruptedException {
			throw new UnsupportedOperationException();
		}

		@Override
		public Condition newCondition() {
			throw new UnsupportedOperationException();
		}

		@Override
		public boolean tryLock() {
			throw new UnsupportedOperationException();
		}

		@Override
		public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
			throw new UnsupportedOperationException();
		}
		
	}
	
	private class WriteLock implements Lock {

		@Override
		public void lock() {
			synchronized(monitor) {
				while(readers>0) {
					try {
						monitor.wait();
					} catch(InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				writer = true;
			}
		}

		@Override
		public void unlock() {
			writer = false;
			monitor.notifyAll();
		}

		@Override
		public void lockInterruptibly() throws InterruptedException {
			throw new UnsupportedOperationException();
		}

		@Override
		public Condition newCondition() {
			throw new UnsupportedOperationException();
		}

		@Override
		public boolean tryLock() {
			throw new UnsupportedOperationException();
		}

		@Override
		public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
			throw new UnsupportedOperationException();
		}
		
	}

}
