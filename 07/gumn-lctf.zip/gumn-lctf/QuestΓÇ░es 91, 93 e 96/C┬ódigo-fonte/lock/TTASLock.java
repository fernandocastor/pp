package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class TTASLock implements Lock {
	private AtomicBoolean state = new AtomicBoolean(false);

	@Override
	public void lock() {
		while(true) {
			while(this.state.get()) {}
			
			if(!this.state.getAndSet(true))
				return;
		}
	}

	@Override
	public void unlock() {
		this.state.set(false);
	}
	
	public boolean isLocked() {
		return this.state.get();
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean tryLock() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public Condition newCondition() {
		throw new UnsupportedOperationException();
	}
}
