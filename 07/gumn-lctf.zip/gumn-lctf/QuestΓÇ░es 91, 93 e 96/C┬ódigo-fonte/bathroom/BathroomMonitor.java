package bathroom;

public class BathroomMonitor {
	public Object maleMonitor;
	public Object femaleMonitor;
	
	public BathroomMonitor() {
		this.maleMonitor = new Object();
		this.femaleMonitor = new Object();
	}
}
