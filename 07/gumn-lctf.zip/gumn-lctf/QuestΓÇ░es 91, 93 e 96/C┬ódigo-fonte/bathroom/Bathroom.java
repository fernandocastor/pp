package bathroom;

public interface Bathroom {
	public void enterMale();
	public void leaveMale();
	public void enterFemale();
	public void leaveFemale();
}
