package bathroom;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BathroomLockCondition implements Bathroom {
	private int maleWaiting, maleUsing;
	private int femaleWaiting, femaleUsing;
	private int free;
	private Lock lock;
	private Condition maleCondition, femaleCondition;
	
	public BathroomLockCondition() {
		this(1);
	}
	
	public BathroomLockCondition(int capacity) {
		this.maleWaiting = this.maleUsing = 0;
		this.femaleWaiting = this.femaleUsing = 0;
		this.free = capacity;
		this.lock = new ReentrantLock();
		this.maleCondition = this.lock.newCondition();
		this.femaleCondition = this.lock.newCondition();
	}

	@Override
	public void enterMale() {
		this.lock.lock();
		
		try {
			int femaleWaitingOnEnter = this.femaleWaiting;
			
			while(this.free==0 || (femaleWaitingOnEnter - this.femaleWaiting)>0 || this.femaleUsing>0) {
				try {
					this.maleWaiting++;
					this.maleCondition.await();
					this.maleWaiting--;
				} catch(InterruptedException e) {}
			}
			
			this.maleUsing++;
			this.free--;
		} finally {
			this.lock.unlock();
		}
	}

	@Override
	public void leaveMale() {
		this.lock.lock();
		
		try {
			this.maleUsing--;
			this.free++;
			
			if(this.maleUsing==0 && this.femaleWaiting>0)
				this.femaleCondition.signalAll();
		} finally {
			this.lock.unlock();
		}
	}

	@Override
	public void enterFemale() {
		this.lock.lock();
		
		try {
			int maleWaitingOnEnter = this.maleWaiting;
			
			while(this.free==0 || (maleWaitingOnEnter - this.maleWaiting)>0 || this.maleUsing>0) {
				try {
					this.femaleWaiting++;
					this.femaleCondition.await();
					this.femaleWaiting--;
				} catch(InterruptedException e) {}
			}
			
			this.femaleUsing++;
			this.free--;
		} finally {
			this.lock.unlock();
		}
	}

	@Override
	public void leaveFemale() {
		this.lock.lock();
		
		try {
			this.femaleUsing--;
			this.free++;
			
			if(this.femaleUsing==0 && this.maleWaiting>0)
				this.maleCondition.signalAll();
		} finally {
			this.lock.unlock();
		}
	}
}
