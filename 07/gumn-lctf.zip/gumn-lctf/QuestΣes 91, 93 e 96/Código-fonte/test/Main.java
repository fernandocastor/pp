package test;

import bathroom.Bathroom;
import bathroom.BathroomSychronizedWaitNotify;

public class Main {
	private static final int BATHROOM_CAPACITY = 5;
	private static final int NUMBER_OF_THREADS = 10;
	private static Bathroom banheiro = new BathroomSychronizedWaitNotify(BATHROOM_CAPACITY);
	
	public static void main(String[] args) {
		Thread[] tmale = new Thread[NUMBER_OF_THREADS];
		for(int i=0; i<NUMBER_OF_THREADS; i++) {
			tmale[i] = new Thread(new Runnable() {
				@Override
				public void run() {
					banheiro.enterMale();
					System.out.println("Homem");
					banheiro.leaveMale();
				}
			});
		}
		
		Thread[] tfemale = new Thread[NUMBER_OF_THREADS];
		for(int i=0; i<NUMBER_OF_THREADS; i++) {
			tfemale[i] = new Thread(new Runnable() {
				@Override
				public void run() {
					banheiro.enterFemale();
					System.out.println("Mulher");
					banheiro.leaveFemale();
				}
			});
		}
		
		for(int i=0; i<NUMBER_OF_THREADS; i++) {
			tmale[i].start();
			tfemale[i].start();
		}
	}
}
