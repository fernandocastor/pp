package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class ArrayQueueLock implements Lock {
	private ThreadLocal<Integer> myIndex = new ThreadLocal<Integer>() {
		protected Integer initialValue() {
			return 0;
		}
	};
	
	private AtomicInteger tail;
	private boolean[] flag;
	private int size;
	
	public ArrayQueueLock(int size) {
		this.size = size;
		this.flag = new boolean[size];
		this.flag[0] = true;
		this.tail = new AtomicInteger(0);
	}

	@Override
	public void lock() {
		int index = this.tail.getAndIncrement() % this.size;
		this.myIndex.set(index);
		
		while(!this.flag[index]) {}
	}

	@Override
	public void unlock() {
		int index = myIndex.get();
		this.flag[index] = false;
		this.flag[(index + 1) % this.size] = true;
	}
	
	public boolean isLocked() {
		int index = this.tail.get() % this.size;
		return this.flag[index];
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean tryLock() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public Condition newCondition() {
		throw new UnsupportedOperationException();
	}
}
