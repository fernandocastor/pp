package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class TOQueueLock implements Lock {
	private static QNode AVAILABLE = new QNode();
	private AtomicReference<QNode> tail = new AtomicReference<QNode>(null);
	
	private ThreadLocal<QNode> myself = new ThreadLocal<QNode>() {
		protected QNode initialValue() {
			return new QNode();
		}
	};

	@Override
	public boolean tryLock() {
		try {
			return this.tryLock(5, TimeUnit.MILLISECONDS);
		} catch(InterruptedException e) {
			return false;
		}
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		long t1 = System.currentTimeMillis();
		long delay = TimeUnit.MILLISECONDS.convert(time, unit);
		
		QNode myself = new QNode();
		this.myself.set(myself);
		myself.predecessor = null;
		
		QNode predecessor = this.tail.getAndSet(myself);
		if(predecessor==null || predecessor.predecessor==AVAILABLE)
			return true;
		
		while(System.currentTimeMillis() - t1 <= delay) {
			QNode predecessorOfPredecessor = predecessor.predecessor;
			
			if(predecessorOfPredecessor==AVAILABLE)
				return true;
			else if(predecessorOfPredecessor!=null)
				predecessor = predecessorOfPredecessor;
		}
		
		if(!this.tail.compareAndSet(myself, predecessor))
			myself.predecessor = predecessor;
		
		return false;
	}

	@Override
	public void unlock() {
		QNode myself = this.myself.get();
		
		if(!this.tail.compareAndSet(myself, null))
			myself.predecessor = AVAILABLE;
	}
	
	public boolean isLocked() {
		QNode tail = this.tail.get();
		return tail!=null && tail!=AVAILABLE;
	}
	
	private static class QNode {
		private volatile QNode predecessor = null;
	}

	@Override
	public void lock() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public Condition newCondition() {
		throw new UnsupportedOperationException();
	}
}
