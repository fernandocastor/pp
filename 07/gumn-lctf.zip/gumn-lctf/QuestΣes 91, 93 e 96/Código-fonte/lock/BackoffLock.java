package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

import backoff.Backoff;
import backoff.AdditiveBackoff;
import backoff.BackoffType;
import backoff.ExponentialBackoff;

public class BackoffLock implements Lock {
	private static final int MIN_DELAY = 1;
	private static final int MAX_DELAY = 50;
	
	private AtomicBoolean state = new AtomicBoolean(false);
	private BackoffType backoffType;
	
	public BackoffLock(BackoffType backoffType) {
		this.backoffType = backoffType;
	}

	public void lock() {
		Backoff backoff = null;
		
		if(this.backoffType==BackoffType.ADDITIVE) {
			backoff = new AdditiveBackoff(MIN_DELAY, MAX_DELAY);
		} else {
			backoff = new ExponentialBackoff(MIN_DELAY, MAX_DELAY);
		}
		
		while(true) {
			while(this.state.get()) {}
			
			if(!this.state.getAndSet(true)) {
				return;
			} else {
				try {
					backoff.backoff();
				} catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void unlock() {
		this.state.set(false);
	}
	
	public boolean isLocked() {
		return this.state.get();
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean tryLock() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public Condition newCondition() {
		throw new UnsupportedOperationException();
	}
}
