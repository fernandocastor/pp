package lock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class CLHQueueLock implements Lock {
	private AtomicReference<QNode> tail = new AtomicReference<QNode>(new QNode());
	
	private ThreadLocal<QNode> myself = new ThreadLocal<QNode>() {
		protected QNode initialValue() {
			return new QNode();
		}
	};
	
	private ThreadLocal<QNode> predecessor = new ThreadLocal<QNode>() {
		protected QNode initialValue() {
			return null;
		}
	};

	@Override
	public void lock() {
		QNode myself = this.myself.get();
		myself.wait = true;
		
		QNode predecessor = this.tail.getAndSet(myself);
		this.predecessor.set(predecessor);
		
		while(predecessor.wait) {}
	}

	@Override
	public void unlock() {
		QNode myself = this.myself.get();
		myself.wait = false;
		this.myself.set(this.predecessor.get());
	}
	
	public boolean isLocked() {
		return this.tail.get().wait;
	}
	
	class QNode {
		private volatile boolean wait = false;
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean tryLock() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	@Override
	public Condition newCondition() {
		throw new UnsupportedOperationException();
	}
}
