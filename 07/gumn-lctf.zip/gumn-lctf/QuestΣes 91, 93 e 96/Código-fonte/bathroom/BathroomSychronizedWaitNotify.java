package bathroom;

public class BathroomSychronizedWaitNotify implements Bathroom {
	private int maleWaiting, maleUsing;
	private int femaleWaiting, femaleUsing;
	private int free;
	private Object maleMonitor, femaleMonitor;
	
	public BathroomSychronizedWaitNotify() {
		this(1);
	}
	
	public BathroomSychronizedWaitNotify(int capacity) {
		this.maleWaiting = this.maleUsing = 0;
		this.femaleWaiting = this.femaleUsing = 0;
		this.free = capacity;
		this.maleMonitor = new Object();
		this.femaleMonitor = new Object();
	}
	
	@Override
	public void enterMale() {
		synchronized(this.maleMonitor) {
			int femaleWaitingOnEnter = this.femaleWaiting;
			
			while(this.free==0 || (femaleWaitingOnEnter - this.femaleWaiting)>0 || this.femaleUsing>0) {
				try {
					this.maleWaiting++;
					this.maleMonitor.wait();
					this.maleWaiting--;
				} catch(InterruptedException e) {}
			}
			
			this.maleUsing++;
			this.free--;
		}
	}
	
	@Override
	public void leaveMale() {
		synchronized(this.femaleMonitor) {
			this.maleUsing--;
			this.free++;
			
			if(this.maleUsing==0 && this.femaleWaiting>0)
				this.femaleMonitor.notifyAll();
		}
	}
	
	@Override
	public void enterFemale() {
		synchronized(this.femaleMonitor) {
			int maleWaitingOnEnter = this.maleWaiting;
			
			while(this.free==0 || (maleWaitingOnEnter - this.maleWaiting)>0 || this.maleUsing>0) {
				try {
					this.femaleWaiting++;
					this.femaleMonitor.wait();
					this.femaleWaiting--;
				} catch(InterruptedException e) {}
			}
			
			this.femaleUsing++;
			this.free--;
		}
	}
	
	@Override
	public void leaveFemale() {
		synchronized(this.maleMonitor) {
			this.femaleUsing--;
			this.free++;
			
			if(this.femaleUsing==0 && this.maleWaiting>0)
				this.maleMonitor.notifyAll();
		}
	}
}
