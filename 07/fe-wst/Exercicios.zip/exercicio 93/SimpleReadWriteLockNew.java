package trabalho07.ex93;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class SimpleReadWriteLockNew implements ReadWriteLock {

	private int readers;
	private boolean writer;
	private Lock readLock;
	private Lock writeLock;
	private Object weslleySafadao;

	public SimpleReadWriteLockNew() {
		writer = false;
		readers = 0;
		readLock = new ReadLock();
		writeLock = new WriteLock();
		weslleySafadao = new Object();
	}

	@Override
	public Lock readLock() {
		return readLock;
	}

	@Override
	public Lock writeLock() {
		return writeLock;
	}

	class ReadLock implements Lock {

		@Override
		public void lock() {
			synchronized (weslleySafadao)
			{
				
					while (writer)
					{
						try
						{
						weslleySafadao.wait();
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
					}
					readers++;
				}
			
		}

		@Override
		public void unlock() {
			synchronized (weslleySafadao)
			{
				readers--;
				if (readers == 0)
				{
					weslleySafadao.notifyAll();
				}
			}
		}

		@Override
		public void lockInterruptibly() throws InterruptedException {
		}

		@Override
		public boolean tryLock() {
			return false;
		}

		@Override
		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			return false;
		}

		@Override
		public Condition newCondition() {
			return null;
		}
	}

	protected class WriteLock implements Lock {

		@Override
		public void lock() {
			synchronized (weslleySafadao)
			{
					while (readers > 0 || writer)
					{
						try
						{
						weslleySafadao.wait();
						}
						catch (InterruptedException e)
						{
							e.printStackTrace();
						}
					writer = true;
				}
			}
		}

		@Override
		public void unlock() {
			writer = false;
			weslleySafadao.notifyAll();
		}

		@Override
		public void lockInterruptibly() throws InterruptedException {
		}

		@Override
		public boolean tryLock() {
			return false;
		}

		@Override
		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			return false;
		}

		@Override
		public Condition newCondition() {
			return null;
		}
	}

}
