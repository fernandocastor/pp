package trabalho07.ex98;

import java.util.concurrent.CountDownLatch;

public class CountDown {
	
	public static void main(String[] args) {
		int n = 5;
		
		CountDownLatch doneSignal =new CountDownLatch(n);

		
		for(int i=0;i<n ; ++i) {// start threads
			new Thread(new ThreadAtiva(doneSignal)).start();
		}
		
		for(int i=0;i<n ; ++i) {// start threads
			new Thread(new ThreadPassiva(doneSignal)).start();
		}
		
		
	}
	
	static class ThreadAtiva implements Runnable {
		private final CountDownLatch terminou;
		ThreadAtiva(CountDownLatch terminou) {
			this.terminou = terminou;
		}
		public void run() {
			doWork();
			terminou.countDown();// notify driver we�re done
		}
		
		public void doWork(){
			int h = 0;
			for (int i = 0; i < 1; i++)
			{

				for (int j = 0; j < Integer.MAX_VALUE; j++)
				{
					h = j;
				}
				
				System.out.println("ativ + " + h);
			}
		}

	}
	
	static class ThreadPassiva implements Runnable {
		private final CountDownLatch espera;
		ThreadPassiva(CountDownLatch espera) {
			this.espera = espera;
		}
		public void run() {
			try
			{
				espera.await();
				doWork2();
			}
			catch (InterruptedException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			doWork2();
		}
		
		public void doWork2(){
			for (int i = 0; i < 1; i++)
			{
				System.out.println("pass");
			}
		}

	}
}
