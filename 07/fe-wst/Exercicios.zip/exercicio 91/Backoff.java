package trabalho07.ex91;

import java.util.Random;

public class Backoff {

	private final int minDelay, maxDelay;
	private int limit;

	private final Random random;

	public Backoff(int min, int max) {
		this.minDelay = min;
		this.maxDelay = max;
		this.limit = minDelay;
		random = new Random();
	}

	public void exponentialBackoff() throws InterruptedException {
		int delay = this.random.nextInt(this.limit);
		this.limit = Math.min(this.maxDelay, 2 * this.limit);
		Thread.sleep(delay);
	}

	public void additiveBackoff() throws InterruptedException {
		int delay = this.random.nextInt(this.limit);
		this.limit = Math.min(this.maxDelay, 10 + this.limit);
		Thread.sleep(delay);
	}
}
