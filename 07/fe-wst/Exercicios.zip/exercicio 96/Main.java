package trabalho07.ex96;

public class Main {

	public static void main(String[] args) {
		
		final BathroomJava banheiro = new BathroomJava();
		
		Thread t1 = new Thread(){
			@Override
			public void run() {
				banheiro.enterMale();
				System.out.println("ok");
				banheiro.leaveMale();
			}
		};
		
		Thread t2 = new Thread(){
			@Override
			public void run() {
				banheiro.enterFemale();
				System.out.println("ok 2");
				banheiro.leaveFemale();
			}
		};
		
		Thread t3 = new Thread(){
			@Override
			public void run() {
				banheiro.enterMale();
				System.out.println("ok 3");
				banheiro.leaveMale();
			}
		};
		
		Thread t4 = new Thread(){
			@Override
			public void run() {
				banheiro.enterFemale();
				System.out.println("ok 4");
				banheiro.leaveFemale();
			}
		};
		
		t1.start();
		t3.start();
		t2.start();
		t4.start();
		

	}

}
