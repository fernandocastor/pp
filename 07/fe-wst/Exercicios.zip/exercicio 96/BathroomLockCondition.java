package trabalho07.ex96;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class BathroomLockCondition {

	private volatile int banheiro = 0; // 0 - vazio, 1 - homem , 2 - mulher
	private volatile int contadorDentroBanheiro = 0;
	private volatile int filaEsperaHomem = 0;
	private volatile int filaEsperaMulher = 0;
	private Lock lock;
	private Condition conditionHomem, conditionMulher;

	public BathroomLockCondition() {
		lock = new ReentrantLock();
		conditionHomem = lock.newCondition();
		conditionMulher = lock.newCondition();
	}

	public void enterMale() {
		lock.lock();
		try
		{
			filaEsperaHomem++;
			if (banheiro == 2 || filaEsperaMulher > 0)
			{
				conditionHomem.await();
			}
			contadorDentroBanheiro++;
			filaEsperaHomem--;
			banheiro = 1;
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		finally
		{
			lock.unlock();
		}
	}

	public void enterFemale() {
		lock.lock();
		try
		{
			filaEsperaMulher++;
			if (banheiro == 1 || filaEsperaHomem > 0)
			{
				conditionMulher.await();
			}
			contadorDentroBanheiro++;
			filaEsperaMulher--;
			banheiro = 2;
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		finally
		{
			lock.unlock();
		}
	}

	public void leaveMale() {
		lock.lock();
		try
		{
			contadorDentroBanheiro--;
			if (contadorDentroBanheiro == 0)
			{
				banheiro = 0;
				conditionMulher.signalAll();
			}
		}
		finally
		{
			lock.unlock();
		}
	}

	public void leaveFemale() {
		lock.lock();
		try
		{
			contadorDentroBanheiro--;
			if (contadorDentroBanheiro == 0)
			{
				banheiro = 0;
				conditionHomem.signalAll();
			}
		}
		finally
		{
			lock.unlock();
		}
	}
}
