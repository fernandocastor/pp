package trabalho07.ex96;

public class BathroomJava {

	private volatile int banheiro = 0; // 0 - vazio, 1 - homem , 2 - mulher
	private volatile int contadorDentroBanheiro = 0;
	private volatile int filaEsperaHomem = 0;
	private volatile int filaEsperaMulher = 0;
	private volatile int proximoAcordar = 0;

	// private Object conditionHomem, conditionMulher;

	public BathroomJava() {
		// conditionHomem = new Object();
		// conditionMulher = new Object();
	}

	public void enterMale() {
		synchronized (this)
		{
			try
			{
				filaEsperaHomem++;
				while (homemEspera())
				{
					this.wait();
				}
				contadorDentroBanheiro++;
				filaEsperaHomem--;
				banheiro = 1;
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}

	public boolean homemEspera() {
		synchronized (this)
		{

			if (banheiro == 2)
			{
				return true;
			}
			if (banheiro == 1 && filaEsperaMulher > 0)
			{
				return true;
			}

			if (filaEsperaMulher > 0 && proximoAcordar == 2)
			{
				return true;
			}

			return false;
		}
	}

	public boolean mulherEspera() {
		synchronized (this)
		{
			if (banheiro == 1)
			{
				return true;
			}
			if (banheiro == 2 && filaEsperaHomem > 0)
			{
				return true;
			}

			if (filaEsperaHomem > 0 && proximoAcordar == 1)
			{
				return true;
			}

			return false;
		}
	}

	public void enterFemale() {
		synchronized (this)
		{
			try
			{
				filaEsperaMulher++;
				if (mulherEspera())
				{
					this.wait();
				}
				contadorDentroBanheiro++;
				filaEsperaMulher--;
				banheiro = 2;
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}

	public void leaveMale() {
		synchronized (this)
		{
			contadorDentroBanheiro--;
			if (contadorDentroBanheiro == 0)
			{
				banheiro = 0;
				proximoAcordar = 2;

				this.notifyAll();

			}
		}
	}

	public void leaveFemale() {
		synchronized (this)
		{
			contadorDentroBanheiro--;
			if (contadorDentroBanheiro == 0)
			{
				banheiro = 0;
				proximoAcordar = 1;

				this.notifyAll();

			}
		}
	}
}
