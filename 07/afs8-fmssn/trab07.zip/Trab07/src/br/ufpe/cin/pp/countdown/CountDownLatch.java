package br.ufpe.cin.pp.countdown;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CountDownLatch {

	Lock lock;
	Condition condition;

	int n;

	public CountDownLatch(int n) {
		if (n < 0) {
			throw new IllegalArgumentException();
		}
		this.lock = new ReentrantLock();
		this.condition = this.lock.newCondition();
		this.n = n;
	}

	public void countDown() {

		lock.lock();

		try {
			this.n--;
			if (n == 0) {
				condition.signalAll();
			}
		} finally {
			lock.unlock();
		}
	}

	public void await() {

		lock.lock();

		try {
			while (n != 0) {
				try {
					condition.await();
				} catch (InterruptedException e) {
					// do nothing
				}
			}
		} finally {
			lock.unlock();
		}
	}

}
