package br.ufpe.cin.pp.locks;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

import br.ufpe.cin.pp.locks.backoff.Backoff;

public class BackoffLock implements Lock {

	private AtomicBoolean state = new AtomicBoolean(false);
	private static final int MIN_DELAY = 1000;
	private static final int MAX_DELAY = 10000;

	@Override
	public void lock() {
		Backoff backoff = new Backoff(MIN_DELAY, MAX_DELAY);
		while (true) {
			while (state.get()) {
			}
			;
			if (!state.getAndSet(true)) {
				return;
			} else {
				try {
					backoff.backoff();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public boolean isLocked() {
		return state.get();
	}

	@Override
	public void unlock() {
		state.set(false);
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
	}

	@Override
	public Condition newCondition() {
		return null;
	}

	@Override
	public boolean tryLock() {
		return false;
	}

	@Override
	public boolean tryLock(long arg0, TimeUnit arg1)
			throws InterruptedException {
		return false;
	}

}
