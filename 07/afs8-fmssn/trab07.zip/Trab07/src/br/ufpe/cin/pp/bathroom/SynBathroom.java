package br.ufpe.cin.pp.bathroom;

public class SynBathroom {

	private final static int NONE = 0;
	private final static int MEN = 1;
	private final static int WOMEN = 2;

	private volatile int bathOwners = NONE;
	private volatile int wcOccupants = 0;
	private volatile int maleLineSize = 0;
	private volatile int femaleLineSize = 0;

	private volatile boolean goMale = false;
	private volatile boolean goFemale = false;

	public void enterMale() {

		synchronized (this) {
			try {
				maleLineSize++;
				if (bathOwners == WOMEN || femaleLineSize > 0) {
					this.wait();
					if (!goMale) {
						this.wait();
					}
				}
				wcOccupants++;
				bathOwners = MEN;
				maleLineSize--;
			} catch (InterruptedException e) {
				// do nothing
			}
		}
	}

	public void enterFemale() {
		synchronized (this) {
			try {
				femaleLineSize++;
				if (bathOwners == MEN || maleLineSize > 0) {
					this.wait();
					if (!this.goFemale) {
						this.wait();
					}
				}
				wcOccupants++;
				bathOwners = WOMEN;
				femaleLineSize--;
			} catch (InterruptedException e) {
				// do nothing
			}
		}
	}

	public void leaveMale() {
		synchronized (this) {
			wcOccupants--;
			if (wcOccupants == 0) {
				bathOwners = NONE;
				this.goMale = false;
				this.goFemale = true;
				this.notifyAll();
			}
		}
	}

	public void leaveFemale() {
		synchronized (this) {
			wcOccupants--;
			if (wcOccupants == 0) {
				bathOwners = NONE;
				this.goMale = true;
				this.goFemale = false;
				this.notifyAll();
			}
		}
	}
}
