package br.ufpe.cin.pp.locks;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class FifoReadWriteLock {

	int readAcquires, readReleases;

	boolean writer;

	Lock lock;

	Condition condition;

	Lock readLock, writeLock;

	public FifoReadWriteLock() {
		this.readAcquires = this.readReleases = 0;
		this.writer = false;
		this.lock = new ReentrantLock();
		this.condition = lock.newCondition();
		this.readLock = new ReadLock();
		this.writeLock = new WriteLock();
	}

	private class ReadLock implements Lock {

		public void lock() {
			lock.lock();
			try {
				while (writer) {
					try {
						condition.await();
					} catch (InterruptedException e) {
						// do nothing
					}
				}
				readAcquires++;
			} finally {
				lock.unlock();
			}
		}

		public void unlock() {
			lock.lock();
			try {
				readReleases++;
				if (readAcquires == readReleases) {
					condition.signalAll();
				}
			} finally {
				lock.unlock();
			}

		}

		@Override
		public void lockInterruptibly() throws InterruptedException {
			// TODO Auto-generated method stub
			
		}

		@Override
		public Condition newCondition() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean tryLock() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			// TODO Auto-generated method stub
			return false;
		}

	}

	private class WriteLock implements Lock {

		public void lock() {
			lock.lock();
			try {
				while (writer) {
					try {
						condition.await();
					} catch (InterruptedException e) {
						// do nothing
					}
				}
				writer = true;
				while (readAcquires != readReleases) {
					try {
						condition.await();
					} catch (InterruptedException e) {
						// do nothing
					}
				}
			} finally {
				lock.unlock();
			}
		}

		public void unlock() {
			writer = false;
			condition.signalAll();
		}

		@Override
		public void lockInterruptibly() throws InterruptedException {
			// TODO Auto-generated method stub
			
		}

		@Override
		public Condition newCondition() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean tryLock() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			// TODO Auto-generated method stub
			return false;
		}
	}

}
