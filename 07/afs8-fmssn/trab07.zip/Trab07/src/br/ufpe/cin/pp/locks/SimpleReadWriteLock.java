package br.ufpe.cin.pp.locks;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class SimpleReadWriteLock {

	int readers;
	boolean writer;

	Lock readLock, writeLock;

	private SimpleReadWriteLock rwmonitor;

	public SimpleReadWriteLock() {
		writer = false;
		readers = 0;
		readLock = new ReadLock();

		this.rwmonitor = this;
	}

	public Lock readLock() {
		return this.readLock;
	}

	class ReadLock implements Lock {

		@Override
		public void lock() {
			synchronized (rwmonitor) {

				while (writer) {
					try {
						rwmonitor.wait();
					} catch (InterruptedException e) {
						// do nothing
					}
				}
				readers++;

			}
		}

		@Override
		public void lockInterruptibly() throws InterruptedException {
			// TODO Auto-generated method stub

		}

		@Override
		public Condition newCondition() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean tryLock() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean tryLock(long arg0, TimeUnit arg1)
				throws InterruptedException {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void unlock() {
			synchronized (rwmonitor) {

				readers--;
				if (readers == 0) {
					rwmonitor.notifyAll();
				}

			}
		}
	}

	protected class WriteLock implements Lock {

		@Override
		public void lock() {
			synchronized (rwmonitor) {
				while (readers > 0 || writer) {
					try {
						rwmonitor.wait();
					} catch (InterruptedException e) {
						// do nothing
					}
				}

				writer = true;
			}
		}

		@Override
		public void lockInterruptibly() throws InterruptedException {
			// TODO Auto-generated method stub

		}

		@Override
		public Condition newCondition() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public boolean tryLock() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void unlock() {
			writer = false;
			rwmonitor.notifyAll();
		}

	}
}
