package br.ufpe.cin.pp.locks.backoff;


public enum BackoffStrategy {

	ADDITIVE, EXPONENTIAL, NOBACKOFF

}
