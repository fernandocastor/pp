package br.ufpe.cin.pp.bathroom;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LBathroom {

	private final static int NONE = 0;
	private final static int MEN = 1;
	private final static int WOMEN = 2;

	private volatile int bathOwners = NONE;
	private volatile int wcOccupants = 0;
	private volatile int maleLineSize = 0;
	private volatile int femaleLineSize = 0;
	private Lock lock;
	private Condition maleGo, femaleGo;

	public LBathroom() {
		this.lock = new ReentrantLock();
		maleGo = lock.newCondition();
		femaleGo = lock.newCondition();
	}

	public void enterMale() {
		lock.lock();
		try {
			maleLineSize++;
			if (bathOwners == WOMEN || femaleLineSize > 0) {
				maleGo.await();
			}
			wcOccupants++;
			bathOwners = MEN;
			maleLineSize--;
		} catch (InterruptedException e) {
			// do nothing
		} finally {
			lock.unlock();
		}
	}

	public void enterFemale() {
		lock.lock();
		try {
			femaleLineSize++;
			if (bathOwners == MEN || maleLineSize > 0) {
				femaleGo.await();
			}
			wcOccupants++;
			bathOwners = WOMEN;
			femaleLineSize--;
		} catch (InterruptedException e) {
			// do nothing
		} finally {
			lock.unlock();
		}
	}

	public void leaveMale() {
		lock.lock();
		try {
			wcOccupants--;
			if (wcOccupants == 0) {
				bathOwners = NONE;
				femaleGo.signalAll();
			}
		} finally {
			lock.unlock();
		}
	}

	public void leaveFemale() {
		lock.lock();
		try {
			wcOccupants--;
			if (wcOccupants == 0) {
				bathOwners = NONE;
				maleGo.signalAll();
			}
		} finally {
			lock.unlock();
		}
	}
}
