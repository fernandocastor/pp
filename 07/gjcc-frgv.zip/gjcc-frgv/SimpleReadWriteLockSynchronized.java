package trabalho07;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;

public class SimpleReadWriteLockSynchronized implements ReadWriteLock {

	int readers;
	boolean writer;
	Object lock;
	Lock readLock;
	Lock writeLock;

	public SimpleReadWriteLockSynchronized() {
		writer = false;
		readers = 0;
		lock = new Object();
		readLock = new ReadLock();
		writeLock = new WriteLock();
	}

	public Lock readLock() {
		return readLock;
	}

	public Lock writeLock() {
		return writeLock;
	}

	class ReadLock implements Lock {
		public void lock() {
			synchronized (lock) {
				while (writer) {
					try {
						lock.wait();
					} catch (InterruptedException e) {
					}
				}
				readers++;
			}
		}

		public void unlock() {
			synchronized (lock) {
				readers--;
				if (readers == 0)
					lock.notifyAll();
			}
		}

		public void lockInterruptibly() throws InterruptedException {
			throw new UnsupportedOperationException();
		}

		public boolean tryLock() {
			throw new UnsupportedOperationException();
		}

		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			throw new UnsupportedOperationException();
		}

		public Condition newCondition() {
			throw new UnsupportedOperationException();
		}
	}

	protected class WriteLock implements Lock {
		public void lock() {
			synchronized (lock) {
				while (readers > 0) {
					try {
						lock.wait();
					} catch (InterruptedException e) {
					}
				}
				writer = true;
			}
		}

		public void unlock() {
			synchronized (lock) {
				writer = false;
				lock.notifyAll();
			}
		}

		public void lockInterruptibly() throws InterruptedException {
			throw new UnsupportedOperationException();
		}

		public boolean tryLock() {
			throw new UnsupportedOperationException();
		}

		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			throw new UnsupportedOperationException();
		}

		public Condition newCondition() {
			throw new UnsupportedOperationException();
		}
	}

	public void lockInterruptibly() throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	public boolean tryLock() {
		throw new UnsupportedOperationException();
	}

	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		throw new UnsupportedOperationException();
	}

	public Condition newCondition() {
		throw new UnsupportedOperationException();
	}



	//==================  TESTE CODE ==================== //

	static Book newBook;
	public static class Author implements Runnable {
		int threadId;
		long t;
		public Author(int id, long time) {
			threadId = id;
			t = time;
		}
		public void run() {
			while ((System.currentTimeMillis() - t) <= 10000) {
				newBook.writeBook(threadId);
			}
		}
	}

	public static class Reader implements Runnable {
		int threadId;
		long t;
		public Reader(int id, long time) {
			threadId = id;
			t = time;
		}
		public void run() {
			while ((System.currentTimeMillis() - t) <= 10000) {
				newBook.readBook(threadId);
			}
		}
	}

	public static void main(String[] args) {
		newBook = new Book();
		final long startTime = System.currentTimeMillis();
		for (int thw = 0; thw < 2; thw++) {
			Author a = new Author(thw, startTime);
			new Thread(a).start();
		}
		for (int thr = 2; thr < 5; thr++) {
			Reader r = new Reader(thr, startTime);
			new Thread(r).start();
		}
	}
}


class Book {
	SimpleReadWriteLockSynchronized lock = new SimpleReadWriteLockSynchronized();
	int countBook = 0;
	int lines = 0;

	public void writeBook(int authorId) {
		lock.writeLock().lock();
		try {
			while (countBook < 3) {
				while (lines < 150) {
					lines++;
				}
				countBook++;
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("Author: " + authorId + " writing book "	+ countBook);
			}
		} finally {
			lock.writeLock().unlock();
		}
	}

	public void readBook(int readerId) {
		lock.readLock().lock();
		try {
			while (countBook < 3) {
				System.out.println("Reader: " + readerId + " reding book " 	+ countBook);
			}
		} finally {
			lock.readLock().unlock();
		}
	}
}