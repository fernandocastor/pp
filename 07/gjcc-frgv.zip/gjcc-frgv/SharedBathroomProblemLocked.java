package trabalho07;

import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SharedBathroomProblemLocked {

	Bathroom bath 		= new Bathroom();
	Lock lock 			= new ReentrantLock();
	Condition condition = lock.newCondition();

	public void enterMale() {
		lock.lock();
		try {
			while (bath.OCCUPIED) {
				try {
					System.out.println("Male" + Thread.currentThread().getId()	+ " is trying to enter in the bathroom");
					condition.await();
				} catch (InterruptedException e) {
				}
			}
			bath.OCCUPIED = true;
			System.out.println("Male" + Thread.currentThread().getId() + " entered in the bathroom");
		} finally {
			lock.unlock();
		}
	}

	public void enterFemale() {
		lock.lock();
		try {
			while (bath.OCCUPIED) {
				try {
					System.out.println("Fmeale" + Thread.currentThread().getId()	+ " is trying to enter in the bathroom");
					condition.await();
				} catch (InterruptedException e) {
				}
			}
			bath.OCCUPIED = true;
			System.out.println("Female" + Thread.currentThread().getId() + " entered in the bathroom");
		} finally {
			lock.unlock();
		}
	}

	public void leaveMale() {
		lock.lock();
		System.out.println("Male" + Thread.currentThread().getId() + " left the bathroom");
		bath.OCCUPIED = false;
		condition.signalAll();
		lock.unlock();

	}

	public void leaveFemale() {
		lock.lock();
		System.out.println("Female" + Thread.currentThread().getId()+ " left the bathroom");
		bath.OCCUPIED = false;
		condition.signalAll();
		lock.unlock();
	}

	public void doSomething() {
		try {
			Thread.sleep(new Random().nextInt((3000 - 1000) + 1) + 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// THE SHARED BATHROOM
	static class Bathroom {
		public boolean OCCUPIED = false;
	}

	// THE MAN
	class Male extends Thread {
		public void run() {
			enterMale();
			doSomething();
			leaveMale();
		}
	}

	// THE WOMAN
	class Female extends Thread {
		public void run() {
			enterFemale();
			doSomething();
			leaveFemale();
		}
	}

	public void test() {
		try{
			int THREADS = 5;
			System.out.println("TESTING...");
			Thread[] myThreads = new Thread[2 * THREADS];
			for (int i = 0; i < THREADS; i++) {
				myThreads[i] 			= new Male();
				myThreads[i + THREADS] 	= new Female();
			}
			for (int i = 0; i < 2 * THREADS; i++) {
				myThreads[i].start();
			}
			for (int i = 0; i < 2 * THREADS; i++) {
				myThreads[i].join();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) throws Exception {
		new SharedBathroomProblemLocked().test();
	}
}