package trabalho07;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class TASLock implements Lock {

	AtomicBoolean state = new AtomicBoolean(false);

	public void lock() {
		if (!isLocked()) {
			while (state.getAndSet(true)) {}
		}
	}

	@Override
	public void lockInterruptibly() throws InterruptedException {
		// TODO Auto-generated method stub
	}

	@Override
	public boolean tryLock() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void unlock() {
		state.set(false);
	}

	@Override
	public Condition newCondition() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isLocked() {
		return state.get();
	}

	private static class Counter {

	    private Lock lock = new TASLock();
	    private int count = 0;
	    public void increment() {
	    	this.lock.lock();
	    	try {
	    		this.count++;
	    	} finally {
	    		this.lock.unlock();
	    	}
	    }
	  }

	  private static class IncThread extends Thread {

		  AtomicBoolean end = new AtomicBoolean(false);
		  int index;
		  int count_inc = 0;
		  final Random rand = new Random();

		  public IncThread(int t_length) {
			  index = t_length;
		  }
		  public void run() {
			  do {
				  count_inc++;
				  int i = rand.nextInt(index);
				  counter[i].increment();
			  } while (!end.get());
		  }
	  }

	  private static Counter[] counter = new Counter[2];

	  public static void main(String[] args) {

	    int nThreads;
	    int timeDuration = 10;//120000;

	    if (args.length == 0) {
	      nThreads = 2;
	    } else {
	      nThreads = Integer.parseInt(args[0]);
	    }

	    IncThread[] incT = new IncThread[nThreads];

	    for (int i = 0; i < 2; i++)
	      counter[i] = new Counter();

	    long startTime = System.currentTimeMillis();
	    for (int i = 0; i < counter.length; i++) {
	      incT[i] = new IncThread(nThreads);
	      incT[i].start();
	    }

	    while ((System.currentTimeMillis() - startTime) <= timeDuration ){}
	    for (int i = 0; i < incT.length; i++)
	    	incT[i].end.set(true);

	    for (int i = 0; i < incT.length; i++)
	    	System.out.println("Thread "+ i +" incremented "+incT[i].count_inc);
	  }
}
