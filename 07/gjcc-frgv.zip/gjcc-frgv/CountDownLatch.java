package trabalho07;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CountDownLatch {
	int counter;
	Lock lock;
	Condition condition;

	public CountDownLatch(int count) {
		if (count < 0)
			throw new IllegalArgumentException("count < 0");
		counter = count;
		lock = new ReentrantLock();
		condition = lock.newCondition();
	}

	public void await() throws InterruptedException {
		lock.lock();
		try {
			while (counter > 0)
				condition.await();
		} finally {
			lock.unlock();
		}
	}

	public void countDown() {
		lock.lock();
		try {
			counter--;
			if (counter == 0) {
				condition.signalAll();
			}
		} finally {
			lock.unlock();
		}
	}

	public static void main(String[] args) throws InterruptedException {
		CountDownLatch countDownLatch = new CountDownLatch(3);

		Passive passive = new Passive(countDownLatch);
		
		Active active1 	= new Active(countDownLatch);
		Active active2 	= new Active(countDownLatch);
		Active active3 	= new Active(countDownLatch);

		new Thread(passive).start();
		
		new Thread(active1).start();
		new Thread(active2).start();
		new Thread(active3).start();
	}
}

class Passive implements Runnable {
	CountDownLatch latch = null;

	public Passive(CountDownLatch latch) {
		this.latch = latch;
	}

	public void run() {
		try {
			latch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Actives released");
	}
}

class Active implements Runnable {
	CountDownLatch latch = null;

	public Active(CountDownLatch latch) {
		this.latch = latch;
	}

	public void run() {
		try {
			this.doSomething();
			this.latch.countDown();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void doSomething() throws InterruptedException{
		Thread.sleep(2000);
	}
}