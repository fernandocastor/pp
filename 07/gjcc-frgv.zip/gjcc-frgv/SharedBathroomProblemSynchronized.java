package trabalho07;

import java.util.Random;

public class SharedBathroomProblemSynchronized {

	Bathroom bath 		= new Bathroom();

	public void enterMale() {
		synchronized (bath) {
			while (bath.OCCUPIED) {
				try {
					System.out.println("Male" + Thread.currentThread().getId()	+ " is trying to enter in the bathroom");
					bath.wait();
				} catch (InterruptedException e) {
				}
			}
			bath.OCCUPIED = true;
			System.out.println("Male" + Thread.currentThread().getId() + " entered in the bathroom");
		}
	}

	public void enterFemale() {
		synchronized (bath) {
			while (bath.OCCUPIED) {
				try {
					System.out.println("Female" + Thread.currentThread().getId()	+ " is trying to enter in the bathroom");
					bath.wait();
				} catch (InterruptedException e) {
				}
			}
			bath.OCCUPIED = true;
			System.out.println("Female" + Thread.currentThread().getId() + " entered in the bathroom");
		}
	}

	public void leaveMale() {
		synchronized (bath) {
			System.out.println("Male" + Thread.currentThread().getId() + " left the bathroom");
			bath.OCCUPIED = false;
			bath.notifyAll();
		}
	}

	public void leaveFemale() {
		synchronized (bath) {
			System.out.println("Female" + Thread.currentThread().getId() + " left the bathroom");
			bath.OCCUPIED = false;
			bath.notifyAll();
		}
	}

	public void doSomething() {
		try {
			Thread.sleep(new Random().nextInt((3000 - 1000) + 1) + 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// THE SHARED BATHROOM
	static class Bathroom {
		public boolean OCCUPIED = false;
	}

	// THE MAN
	class Male extends Thread {
		public void run() {
			enterMale();
			doSomething();
			leaveMale();
		}
	}

	// THE WOMAN
	class Female extends Thread {
		public void run() {
			enterFemale();
			doSomething();
			leaveFemale();
		}
	}
	
	public void test() {
		try{
			int THREADS = 5;
			System.out.println("TESTING...");
			Thread[] myThreads = new Thread[2 * THREADS];
			for (int i = 0; i < THREADS; i++) {
				myThreads[i] 			= new Male();
				myThreads[i + THREADS] 	= new Female();
			}
			for (int i = 0; i < 2 * THREADS; i++) {
				myThreads[i].start();
			}
			for (int i = 0; i < 2 * THREADS; i++) {
				myThreads[i].join();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws Exception {
		new SharedBathroomProblemSynchronized().test();
	}
}