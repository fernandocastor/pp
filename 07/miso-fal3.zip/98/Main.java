package Question98;

import java.util.concurrent.CountDownLatch;

public class Main {
	
	public static void main(String[] args) {
		int NUMBER_OF_THREADS = 100;
		OurCountDownLatch countDown = new OurCountDownLatch(NUMBER_OF_THREADS);
		Thread[] activeThreads = new Thread[NUMBER_OF_THREADS];
		Thread[] passiveThreads = new Thread[NUMBER_OF_THREADS];
		
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {
			passiveThreads[i] = new Thread(new Passive(i, countDown));
			activeThreads[i] = new Thread(new Active(i, countDown));
		}
		
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {
			passiveThreads[i].start();
		}
		
		for (int i = 0; i < NUMBER_OF_THREADS; i++) {
			activeThreads[i].start();
		}
	}
}


class Passive implements Runnable {
	private OurCountDownLatch countDown;
	private int id;

	public Passive(int id, OurCountDownLatch countDown) {
		this.id = id;
		this.countDown = countDown;
	}

	public void run() {
		try {
			System.err.println("PASSIVE #"+id+":\tWaiting");
			this.countDown.awaitZero();
			System.err.println("PASSIVE #"+id+":\tIt's the final countdown...");
		} catch (InterruptedException e) {
		}
	}
}


class Active implements Runnable {
	private OurCountDownLatch countDown;
	private int id;

	public Active(int id, OurCountDownLatch countDown) {
		this.id = id;
		this.countDown = countDown;
	}

	public void run() {
		
		System.err.println("ACTIVE #"+id+":We're leaving together, "
				+ "But still it's farewell "
				+ "And maybe we'll come back, "
				+ "To earth, who can tell ? "
				+ "I guess there is no one to blame "
				+ "We're leaving ground "
				+ "Will things ever be the same again?" );
		
		countDown.countDown();
		
	}
}

class OurCountDownLatch {
	private final Object mutex = new Object();
	private volatile int count;
	
	public OurCountDownLatch(int numberOfThreads) {
		synchronized (mutex) {
			this.count = numberOfThreads;
	    }
	  }
	  public void awaitZero() throws InterruptedException {
	    synchronized (mutex) {
	      while (count > 0) {
	        mutex.wait();
	      }
	    }
	  }
	  public void countDown() {
	    synchronized (mutex) {
	      if (--count <= 0) {
	        mutex.notifyAll();
	      }
	    }
	  }
}
