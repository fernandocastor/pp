package Exercise_87;

public class Main {
	static Counter[] counters;
	static Thread[] threads;
	static ThreadIncrement[] threadsIncrement;
	private static final int N_OBJECTS = 1;
	private static int N_THREADS = 2;
	private static final int Min = 0;
	private static final int Max = 0;

	public static void main(String[] args) {
		counters = new Counter[N_OBJECTS];
		for(int i = 0; i < N_OBJECTS; i++) {
			counters[i] = new Counter(i);
		}

		if(args.length == 0) {
			threadsIncrement = new ThreadIncrement[N_THREADS];
		} else {
			N_THREADS = Integer.parseInt(args[0]);
			threadsIncrement = new ThreadIncrement[N_THREADS];
		}

		threads = new Thread[N_THREADS];

		long timeBefore = System.currentTimeMillis();
		for(int j = 0; j < N_THREADS; j++) {
			threadsIncrement[j] = new ThreadIncrement(counters[Min + (int)(Math.random() * ((Max - Min) + 1))], j);
			threads[j] = new Thread(threadsIncrement[j]);
			threads[j].start();
		}

		for(int j = 0; j < N_THREADS; j++) {
			try {
				threads[j].join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		long timeAfter = System.currentTimeMillis();
		long elapsed = timeAfter - timeBefore;
		long somaTotalCounters = 0;
		for(int i = 0; i < N_OBJECTS; i++) {
			System.out.println("Objeto <"+i+"> foi incrementado: "+counters[i].getCounter()+" vezes");
			somaTotalCounters += counters[i].getCounter();

		}
		System.out.println("Soma total: "+somaTotalCounters+"\n");

		long somaTotalThreads = 0;
		for(int i = 0; i < N_THREADS; i++) {
			System.out.println("Thread <"+threads[i].getId()+"> recebeu o objeto <"+threadsIncrement[i].getCounterId()+"> e foi executada: "+threadsIncrement[i].getExecutions()+" vezes");
			somaTotalThreads += threadsIncrement[i].getExecutions();

		}
		System.out.println("Soma total: "+somaTotalThreads+"");
		System.out.println("M�dia de execu��es por thread: "+somaTotalThreads/N_THREADS+"");


		System.out.println("A execu��o das threads increment demorou: "+elapsed+" milisegundos\n\n");

	}

}
