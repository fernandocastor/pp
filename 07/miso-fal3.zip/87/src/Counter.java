package Exercise_87;

import java.util.concurrent.TimeUnit;

public class Counter {
	private int id;
	private long i;
	CompositeFastPathLock lock = new CompositeFastPathLock();
	
	public Counter(int id) {
		this.id = id;
		this.i = 0;
	}
	
	public void increment() throws InterruptedException {
		this.lock.tryLock(10, TimeUnit.MILLISECONDS);
		this.i++;
		this.lock.unlock();
	}
	
	public int getId() {
		return this.id;
	}
	
	public long getCounter() {
		return this.i;
	}

}
