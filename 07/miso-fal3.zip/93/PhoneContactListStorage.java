package Exercise_93;

import java.util.HashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class PhoneContactListStorage {

	private final SimpleReadWriteLock readWriteLock = 
			new SimpleReadWriteLock();

	private final Lock read  = readWriteLock.readLock();

	private final Lock write = readWriteLock.writeLock();

	private HashMap<String, String> contactList = new HashMap<String, String>();

	public void set(String key, String value) {
		if(write.tryLock()){
			System.out.println("trava para writer adquirida");
			try {
				contactList.put(key, value);
			} finally {
				write.unlock();
			}
		}else{
			System.out.println("n�o � poss�vel adquirir a trava para o writer");
		}
	}

	public String get(String key) {
		if(read.tryLock()){
			System.out.println("trava para reader adquirida - get(String key) ");
			try{
				return contactList.get(key);
			} finally {
				read.unlock();
			}
		}else{
			System.out.println("n�o foi poss�vel adquirir a trava para o reader - get(String key)");
			return null;
		}
	}

	public String[] getKeys(){
		if(read.tryLock()){
			System.out.println("trava para reader adquirida - String[] getKeys()");
			try{
				String keys[] = new String[contactList.size()];
				return contactList.keySet().toArray(keys);
			} finally {
				read.unlock();
			}
		}else{
			System.out.println("N�o � poss�vel adquirir a trava para o reader - String[] getKeys()");
			return null;
		}
	}
}
