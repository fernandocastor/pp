package Exercise_93;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SimpleReadWriteLock implements ReadWriteLock {
	int readers;
	boolean writer;
	Lock lock;
	Lock readLock, writeLock;
	private Object mySync;
	public SimpleReadWriteLock() {
		writer = false;
		readers = 0;
		lock = new ReentrantLock();
		readLock = new ReadLock();
		writeLock = new WriteLock();
		mySync = new Object();
	}

	public Lock readLock() {
		return this.readLock;
	}
	public Lock writeLock() {
		return this.writeLock;
	}

	private class ReadLock implements Lock {
		public void lock() {
			synchronized (mySync) {
				try {
					while (writer) {
						mySync.wait();
					}
					readers++;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		public void unlock() {
			synchronized (mySync) {

				readers--;
				if (readers == 0)
					mySync.notifyAll();

			}
		}
		@Override
		public void lockInterruptibly() throws InterruptedException {
			// TODO Auto-generated method stub

		}
		@Override
		public java.util.concurrent.locks.Condition newCondition() {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public synchronized boolean tryLock() {
			this.lock();
			if(readers > 0)
				return true;
			return false;
		}
		@Override
		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			// TODO Auto-generated method stub
			return false;
		}
	}
	private class WriteLock implements Lock {
		public void lock() {
			synchronized (mySync) {
				try {
					while (readers > 0) {
						mySync.wait();
					}
					writer = true;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		public void unlock() {
			synchronized (mySync) {
				writer = false;
				mySync.notifyAll();
			}
		}
		@Override
		public void lockInterruptibly() throws InterruptedException {
			// TODO Auto-generated method stub

		}
		@Override
		public Condition newCondition() {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public boolean tryLock() {
			this.lock();
			if(writer)
				return true;
			return false;
		}
		@Override
		public boolean tryLock(long time, TimeUnit unit)
				throws InterruptedException {
			// TODO Auto-generated method stub
			return false;
		}
	}

}