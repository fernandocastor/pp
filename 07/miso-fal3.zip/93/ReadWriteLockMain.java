package Exercise_93;

class ReadWriteLockMain{
   public static void main(String[] args) {
       PhoneContactListStorage contactListStorage = new PhoneContactListStorage();
       contactListStorage.set("8299920023",  "Felipe");
       contactListStorage.set("8299920023",  "Felipe2");
       contactListStorage.set("8299920023",  "Felipe3");
       contactListStorage.set("8796003849", "Marcelo");
       contactListStorage.set("8796003849", "Marcelo2");
       contactListStorage.set("8796003849", "Marcelo3");
     Writer writer  = new Writer(contactListStorage, "Writer");
     Reader reader1 = new Reader(contactListStorage ,"Reader 1");
     Reader reader2 = new Reader(contactListStorage ,"Reader 2");
     Reader reader3 = new Reader(contactListStorage ,"Reader 3");
     writer.start();
     reader1.start();
     reader2.start();
     reader3.start();
   }
 
 }
