package Exercise_93;

import java.util.Date;
import java.util.concurrent.TimeUnit;

public interface Condition {
	void await() throws InterruptedException;
	boolean await(long time, TimeUnit unit)
			throws InterruptedException;
	boolean awaitUntil(Date deadline)
			throws InterruptedException;
	long awaitNanos(long nanosTimeout)
			throws InterruptedException;
	void awaitUninterruptibly();
	void signal();
	void signalAll();
}