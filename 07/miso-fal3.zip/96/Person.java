package Exercise_96;

public class Person implements Runnable {

	protected BathroomSynchronized bathroom;
	private boolean isMale;

	// Tempo ocioso antes de entrar na fila
	private int idleTime = 100;

	// Tempo gasto no banheiro
	private int bathroomTime = 100;

	// In�cio do tempo de espera
	private long startWaitTime;

	public Person(BathroomSynchronized bathroom, boolean isMale) {
		this.bathroom = bathroom;
		this.isMale = isMale;
	}

	public long getWaitingTime() {
		return System.currentTimeMillis() - startWaitTime;
	}

	public boolean isMale() {
		return isMale;
	}

	public void run() {
		while(true){
			// Constantly loop
			// Espera randomicamente antes de enfileirar algu�m para usar o banheiro
			try {
				Thread.sleep((int) (idleTime + (10 - idleTime)
						* Math.random()));
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
			// Enfileira uma pessoa
			try {
				startWaitTime = System.currentTimeMillis();
				bathroom.enqueuePerson(this);
			}
			catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			// Ap�s a espera na fila, a pessoa entra no banheiro
			try {

				// Usando o banheiro
				Thread.sleep((int) (bathroomTime + (10 - bathroomTime)
						* Math.random()));
			}
			catch (InterruptedException e) {
				e.printStackTrace();
			}
			// Ao acabar de usar o banheiro, informa e oferece a entrada.
			bathroom.offerEntry(this);
		}
	}
}