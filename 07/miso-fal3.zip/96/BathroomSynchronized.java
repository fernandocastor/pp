package Exercise_96;

import java.util.Iterator;
import java.util.LinkedList;

public class BathroomSynchronized {

    private LinkedList queueToBathroom = new LinkedList();
    private LinkedList bathroomOccupants = new LinkedList();

    private int bathroomCapacity = 5;

    private int females = 0;
    private long femaleQueueTimeTotal = 0;
    private int males = 0;
    private long maleQueueTimeTotal = 0;

    public void enqueuePerson(Person person) throws InterruptedException {
        Person nextToEntry;
        // Adiciona a pessoa na fila e ent�o verifica se esta pessoa j� � a pr�xima a entrar no banheiro.
        // Trava o objeto para previnir que o contexto permita que outra pessoa entre na fila primeiro.
        synchronized (this) {
            queueToBathroom.add(person);
            nextToEntry = offerEntry(null);
        }
        // Se ela n�o for a pr�xima, espera
        if (person != nextToEntry) {
            synchronized (person) {
                person.wait();
            }
        }
    }

    public synchronized Person offerEntry(Person remove) {

        // A pessoa que oferece sai do banheiro
        if (remove != null) {
            removePersonFromQueueOrBathroom(remove, bathroomOccupants);
        }
        Person in = null;
        // Se n�o houver ninguem na fila ou se o banheiro estiver cheio, retorna null
        if (queueToBathroom.size() == 0 || bathroomOccupants.size() >= bathroomCapacity) {
            in = null;
        } else {
            // Caso haja algu�m, encontra a pr�xima pessoa a entrar na fila (homem ou mulher)
            Person occupiersGender = (Person) bathroomOccupants.peek();
            Person nextPerson = (Person) queueToBathroom.peek();
            boolean maleInsideBathroom; // = false;

            // Se houver algu�m no banheiro, verifica se � do sexo masculino
            if (occupiersGender != null) {
                maleInsideBathroom = occupiersGender.isMale();
            }
            // Se n�o houver ningu�m no banheiro, o controle passa a ser do g�nero da pr�xima pessoa na fila (maleInsideBathroom = false || true)
            else {
                maleInsideBathroom = nextPerson.isMale();
            }
            // Se existir algu�m na fila
            if (nextPerson != null) {
                // Se a pr�xima pessoa for do sexo masculino, e houver homens dentro do banheiro, ou o banheiro estiver vazio
                if (nextPerson.isMale() && (maleInsideBathroom || bathroomOccupants.size() == 0)) {
                    in = nextPerson;
                }
                // Caso seja mulher, e houverem mulheres dentro do banheiro, ou o banheiro estiver vazio
                else if (!nextPerson.isMale() && (!maleInsideBathroom || bathroomOccupants.size() == 0)) {
                    maleInsideBathroom = false;
                    in = nextPerson;
                }
                // Sen�o, a pr�xma pessoa da fila n�o pode entrar no banheiro
                else {
                    in = null;
                }
            }
        }

        // Se uma pessoa foi escolhida para entrar no banheiro
        if (in != null) {
            // Ela sai da fila, e adiciona ao n�mero de pessoas do g�nero
            if (in.isMale()) {
                removePersonFromQueueOrBathroom(in, queueToBathroom);
                maleQueueTimeTotal += in.getWaitingTime();
                males++;
            } else {
                removePersonFromQueueOrBathroom(in, queueToBathroom);
                femaleQueueTimeTotal += in.getWaitingTime();
                females++;
            }
            // Adiciona a pessoa ao banheiro
            bathroomOccupants.add(in);
            // Notifica para acordar a pessoa
            synchronized (in) {
                in.notify();
            }
        }
        // Retorna a pessoa
        return in;
    }

    private void removePersonFromQueueOrBathroom(Person person, LinkedList list) {
        Iterator i = list.iterator();
        while (i.hasNext()) {
            if (i.next() == person) {
                i.remove();
            }
        }
    }
}