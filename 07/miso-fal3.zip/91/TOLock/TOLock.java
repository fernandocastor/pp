package Exercise_91.TOLock;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class TOLock implements Lock{
	static QNode AVAILABLE = new QNode();
	AtomicReference<QNode> tail;
	AtomicBoolean isLocked = new AtomicBoolean(false);
	ThreadLocal<QNode> myNode;
	public TOLock() {
		tail = new AtomicReference<QNode>(null);
		myNode = new ThreadLocal<QNode>() {
			protected QNode initialValue() {
				return new QNode();
			}
		};
	}

	static class QNode {
		public QNode pred = null;
	}
	@Override
	public void lock() {
		final int MIN_DELAY = 10;
		try {
			this.tryLock(MIN_DELAY, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	@Override
	public void lockInterruptibly() throws InterruptedException {
		// TODO Auto-generated method stub

	}
	@Override
	public Condition newCondition() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean tryLock() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean tryLock(long time, TimeUnit unit)
			throws InterruptedException {
		long startTime = System.currentTimeMillis();
		long patience = TimeUnit.MILLISECONDS.convert(time, unit);
		QNode qnode = new QNode();
		myNode.set(qnode);
		qnode.pred = null;
		QNode myPred = tail.getAndSet(qnode);
		if (myPred == null || myPred.pred == AVAILABLE) {
			return true;
		}
		while (System.currentTimeMillis() - startTime < patience) {
			QNode predPred = myPred.pred;
			if (predPred == AVAILABLE) {
				return true;
			} else if (predPred != null) {
				myPred = predPred;
			}
		}
		if (!tail.compareAndSet(qnode, myPred))
			qnode.pred = myPred;
		return false;
	}
	@Override
	public void unlock() {
		QNode qnode = myNode.get();
		if (!tail.compareAndSet(qnode, null))
			qnode.pred = AVAILABLE;

	}

	public boolean isLocked() {
		QNode myPred = myNode.get().pred;
		QNode predPred = myPred.pred;
		if (predPred == AVAILABLE) {
			this.isLocked.set(true);
			return true;
		}
		this.isLocked.set(false);
		return false;
	}

}