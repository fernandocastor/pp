package counter.per.thread;

import java.util.Arrays;

import counter.atomic.Main;


public class Contador {
	
    private static final ThreadLocal<Integer> value = new ThreadLocal<Integer>();
	private long finalcount;
	private static Long[] conterPerThread = new Long[Main.QUANT_THREADS];
	
	private static int unregisterThreads = 0;
	
	public void increment(){
		value.set(value.get()+1);
	}
	
	public synchronized long read(){
		
		long sum = finalcount;
		for (Long long1 : conterPerThread) {
			if(long1 != null)
				sum += long1;
		}
		return sum;
	}
	
	public void countRegistrerThread(){
		int threadId = Integer.valueOf(Thread.currentThread().getName());
		value.set(0);
		synchronized (conterPerThread) {
			conterPerThread[threadId] = value.get().longValue();
		}
	}
	
	public void countUnregisterThread(){
		int threadId = Integer.valueOf(Thread.currentThread().getName());
		synchronized (conterPerThread) {
			printValues();
			finalcount += value.get();
			conterPerThread[threadId] = null;
			unregisterThreads++;
//			System.out.println("[ThreadId = "+threadId+", value = "+finalcount+"]");
		}
	}
	
	public static int getUnregisterThreads() {
		return unregisterThreads;
	}
	
	public void printValues(){
		System.out.println(Arrays.toString(conterPerThread));
		
	}

}
