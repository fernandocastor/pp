package counter.atomic;

import java.util.concurrent.atomic.AtomicLong;


public class Contador {
	
	private AtomicLong value = new AtomicLong(0);
	private int unregisterThreads;
	
	public void increment(){
		value.incrementAndGet();
	}
	
	public long read(){
		return value.get();
	}
	
	
	public synchronized void countUnregisterThread(){
		unregisterThreads++;

	}
	
	public synchronized int getUnregisterThreads() {
		return unregisterThreads;
	}

}
