package counter.atomic;


public class Incrementador implements Runnable{
	
	private Contador contador;
	private int limit;
	
	public Incrementador(Contador contador, int limit) {
		this.contador = contador;
		this.limit = limit;
	}

	@Override
	public void run() {
		for (int i = 0; i < limit; i++) {
			contador.increment();
			
		}
		contador.countUnregisterThread();
	}

}
