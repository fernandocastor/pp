package counter.atomic;

public class Main {
	
	//Resultado final deveria ser 
	//0
	//
	public static final int QUANT_THREADS = 10;
	
	
	public static void main(String[] args) {
		long inicio = System.currentTimeMillis();
		Contador contador = new Contador();
		for (int i = 0; i < QUANT_THREADS; i++) {
			new Thread(new Incrementador(contador, Integer.MAX_VALUE),String.valueOf(i)).start();
		}
		
		while(contador.getUnregisterThreads() < QUANT_THREADS){
			try {
				Thread.sleep(100l);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Valor Final  : "+ contador.read());
		System.out.println("Valor Correto: "+ (QUANT_THREADS * new Long(Integer.MAX_VALUE)));
		System.out.println(System.currentTimeMillis() - inicio);
	}

}
