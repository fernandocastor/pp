package statistical;

import java.util.concurrent.atomic.AtomicLong;

public class Counter implements Runnable {

	private  AtomicLong myCounter = new AtomicLong(0);
	private boolean onEdge;

	@Override
	public void run() {
		while (!onEdge) {
			add();
		}
		//System.out.println("Final Thread" + Thread.currentThread().getName());
	}

	public long getMyCounter() {
		return myCounter.get();
	}

	private void add() {
		this.myCounter.getAndIncrement();
	}

	public void setOnEdge(boolean onEdge) {
		this.onEdge = onEdge;
	}

	public void setMyCounter(int myCounter) {
		this.myCounter.set(myCounter);
	}

}
