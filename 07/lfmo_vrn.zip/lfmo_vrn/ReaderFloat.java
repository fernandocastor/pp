package statistical;

import java.util.LinkedList;
import java.util.List;

public class Reader {

	private List<Counter> counters = new LinkedList<Counter>();
	private float globalCounter;

	public Reader(List<Counter> counters) {
		this.counters = counters;
	}

	public float getGlobalCounter() {
		
		globalCounter = 0;
		for (Counter c : counters) {
			globalCounter += c.getMyCounter();
			//c.setMyCounter(0);
		}

		return globalCounter;
	}

}
