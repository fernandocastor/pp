package statistical;

import java.security.InvalidParameterException;
import java.util.LinkedList;
import java.util.List;

/**
 * Quick Quiz 5.2: Network-packet counting problem. Suppose that you need to
 * collect statistics on the number of networking packets (or total number of
 * bytes) transmitted and/or received. Packets might be transmitted or received
 * by any CPU on the system. Suppose further that this large machine is capable
 * of handling a million packets per second, and that there is a
 * systems-monitoring package that reads out the count every five seconds. How
 * would you implement this statistical counter?
 * 
 * @author Leonardo
 * @param <T>
 *
 */
public class MyStatisticalCounting {
	
	private static List<Counter> counters = new LinkedList<Counter>();
	private static long globalCounter;

	/**
	 * args[0] = number of threads
	 * args[1] = max limit to counting
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		if (args==null || args.length < 2) {
			throw new InvalidParameterException(
					"Numero de parametros invalido! Forneca o numero de Threads Contadoras e numero limite maximo!");
		}
		int numberOfThreads = Integer.parseInt(args[0]);
		long limit = Long.parseLong(args[1]);		
		long initialTime = System.currentTimeMillis();
		addAndStartCounters(numberOfThreads, limit);
		startReader(limit);
		long finalTime = System.currentTimeMillis();
		
		System.out.println("Number of Threads: " + numberOfThreads);
		System.out.println("Limit: " + limit);
		System.out.println(finalTime + " --- " + initialTime);
		System.out.printf("Tempo de Execucao: %.5f segundos.\n" , ((double)(finalTime - initialTime)/1000));
		System.out.println("Atingiu limite: " + globalCounter);
	}
	
	private static void startReader(long limit) throws InterruptedException {		
		Reader r = new Reader(counters);
		while(globalCounter<limit){
			globalCounter = r.getGlobalCounter();
		}
		/*for (Counter c : counters) {
			c.setOnEdge(true);
		}*/	
	}

	private static void addAndStartCounters(int numOfCounters, long limit){		
		for (int i = 0; i < numOfCounters; i++) {			
			counters.add(new Counter());						
		}
		
		for (Counter thread : counters) {
			new Thread(thread).start();
			thread.setCounterMax((int)(limit/numOfCounters));
		}
	}	
}
