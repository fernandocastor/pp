package statistical;


public class Counter implements Runnable {

	private  float myCounter;
	private boolean onEdge;

	@Override
	public void run() {
		while (!onEdge) {
			add();
		}
		//System.out.println("Final Thread" + Thread.currentThread().getName());
	}

	public float getMyCounter() {
		return myCounter;
	}

	private void add() {
		this.myCounter++;
	}

	public void setOnEdge(boolean onEdge) {
		this.onEdge = onEdge;
	}

	public void setMyCounter(float myCounter) {
		this.myCounter = myCounter;
	}

}
