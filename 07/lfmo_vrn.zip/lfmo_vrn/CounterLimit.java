package statistical;

public class Counter implements Runnable {

	private  int myCounter;
	private boolean onEdge;
	private int counterMax;

	@Override
	public void run() {
		while (myCounter < counterMax) {
			add();
		}
		//System.out.println("Final Thread" + Thread.currentThread().getName());
	}

	public int getMyCounter() {
		return myCounter;
	}

	private void add() {
		this.myCounter++;
	}

	public void setOnEdge(boolean onEdge) {
		this.onEdge = onEdge;
	}

	public void setMyCounter(int myCounter) {
		this.myCounter = myCounter;
	}

	public int getCounterMax() {
		return counterMax;
	}

	public void setCounterMax(int counterMax) {
		this.counterMax = counterMax;
	}
	
	

}
